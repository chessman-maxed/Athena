import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { resolve } from "path";

/**
 * Athena – Vite build configuration.
 *
 * Two build modes:
 *
 *  default ("popup")
 *    Builds index.html (React popup) + background.js (service worker).
 *    All output filenames are fixed – no content hashes.
 *    Empties dist/ first.
 *
 *  --mode content
 *    Builds content.js as a single self-contained IIFE.
 *    Does NOT empty dist/ so the popup artefacts are preserved.
 *    Runs second in `npm run build`.
 *
 * Resulting dist/ layout (all at root, no hashes):
 *   dist/
 *     manifest.json        ← copied from public/
 *     index.html           ← popup shell
 *     background.js        ← service worker (ESM)
 *     content.js           ← content script (IIFE, single file)
 *     assets/
 *       popup.js           ← React app bundle
 *       popup.css          ← Tailwind stylesheet
 */
export default defineConfig(({ mode }) => {
  const isContent = mode === "content";

  // ── Content-script build (IIFE, single file, no hash) ──────────────────
  // react() is needed for TSX compilation (WarningBanner, shadow-host).
  // tailwindcss() is needed so CSS ?inline imports are processed by Tailwind
  // and returned as plain strings to inject into the Shadow DOM <style> tag.
  if (isContent) {
    return {
      define: {
        "process.env.NODE_ENV": JSON.stringify("production"),
      },
      plugins: [react(), tailwindcss()],
      build: {
        emptyOutDir: false,           // keep popup + background artefacts
        outDir: "dist",
        lib: {
          entry: resolve(import.meta.dirname, "src/content/content.ts"),
          formats: ["iife"],
          name: "AthenaContent",
          fileName: () => "content.js", // always "content.js", never hashed
        },
      },
    };
  }

  // ── Popup + background build ────────────────────────────────────────────
  return {
    plugins: [react(), tailwindcss()],
    build: {
      emptyOutDir: true,              // wipe dist/ before this step
      outDir: "dist",
      rollupOptions: {
        input: {
          popup: resolve(import.meta.dirname, "index.html"),
          background: resolve(import.meta.dirname, "src/background/background.ts"),
        },
        output: {
          // Fixed filenames – no hashes anywhere
          entryFileNames: (chunk) => {
            if (chunk.name === "background") return "background.js";
            return "assets/[name].js"; // popup → assets/popup.js
          },
          chunkFileNames: "assets/[name].js",
          assetFileNames: "assets/[name].[ext]", // popup.css
        },
      },
    },
  };
});