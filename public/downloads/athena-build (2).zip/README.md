# Athena

> **Your GitHub. Protected before you click.**

Athena is a proactive browser security layer for GitHub. It detects risky developer actions and pull request conditions, then warns or intercepts before a user proceeds. Its primary protections use deterministic rules in the browser; optional LLM analysis supports selected explanation and repair workflows, but is not required for the rule engine or secret scanner.

Athena is a user-side aid. It does not replace GitHub permissions, branch protection, code review, or server-side secret scanning.

## 1. Problem

Routine GitHub work can put important code and repository state at risk. A repository can be deleted, a branch can be removed, a pull request can be merged with failing checks, or a credential can be pasted into a comment. These actions are easy to take quickly and difficult to undo.

## 2. Solution

Athena adds contextual checks to GitHub pages in Chrome. It reads the page and, for selected features, GitHub API data. Deterministic rules classify risk and show a warning or intercept a supported action before it continues. Users can configure policies globally or for a repository.

## 3. Key Features

- **GitHub repository protection:** warnings before repository deletion, archiving, ownership transfer, branch deletion, and pull request closure.
- **Pull request guardrails:** merge readiness checks for CI, review state, and conflicts; configurable warnings for merging to `main` or `master` and for checks that have not passed.
- **Branch drift detection:** Conflict Radar identifies conflicts, stale branches, and branches that are far behind their base branch.
- **Workflow and deployment context:** Workflow Radar examines changed paths and repository workflow files to identify workflows likely to run and deployment-related changes.
- **Secret detection:** local scans of supported GitHub text fields, plus an authenticated pull request scanner for secrets on added lines.
- **Security policy configuration:** global defaults and repository-specific policies, with per-pattern secret detector toggles.
- **Activity monitoring:** concise security activity entries are available in the extension popup.
- **Contextual warnings:** warnings are placed near supported GitHub controls and pull request context.
- **Optional AI analysis:** an OpenAI-compatible endpoint can explain selected text or assist with a failing CI check or a conflict hunk. AI is optional; deterministic protections remain the primary mechanism.
- **Reviewed repair pull requests:** supported CI, secret, and conflict flows show a diff before creating a branch and pull request. Athena does not merge these pull requests.

## 4. Architecture

```text
GitHub page
    ↓
Content Script
    ↓
GitHub Context Detection
    ↓
Athena Rule Engine (deterministic)
    ↓
Risk Classification
    ↓
Guardrail
    ↓
Warning / Intercept / User Allow
    ↓
Activity Log

                 ┌── Secret Scanner (local text scan)
Rule Engine ─────┼── PR Radar and Workflow Radar
                 ├── Merge Guardrails
                 └── Optional LLM request → Background Service Worker → Configured Endpoint

Content Script ── optional GitHub API reads ──→ GitHub API
Service Worker ── authenticated repair and PR operations ──→ GitHub API
```

The content script observes GitHub page context and renders Athena’s UI. Some read-only radar enrichment requests are made by content-script modules. The Manifest V3 background service worker handles AI requests and API-backed repair and pull request operations that use credentials. The rule engine and scanner continue to work without an LLM endpoint.

## 5. Technology Stack

- Chrome Extension Manifest V3
- TypeScript and React
- Vite for popup, background service worker, and content-script builds
- Tailwind CSS utilities and scoped Shadow DOM styles
- Vitest for unit tests
- `node-diff3` for three-way conflict merging
- Chrome Storage API for session data, credentials, and persistent policy settings

## 6. How the Extension Works

1. Chrome loads `content.js` on `https://github.com/*` pages.
2. Athena detects the current GitHub context and starts the applicable page observers and rule checks.
3. Deterministic rules evaluate supported actions and pull request state. Secret text-field scans run locally in the browser.
4. Athena adds a contextual warning, intercepts a supported control, or displays pull request telemetry. A user can proceed through the warning where the control supports an override.
5. When a feature needs GitHub API access or optional AI, the extension uses the relevant API path and reports the result in the UI. Repair flows require review of a diff before creating a pull request.

## 7. Security & Privacy

- **Deterministic by default:** repository-action guardrails, secret scanning, policy evaluation, and pull request status checks do not depend on an LLM.
- **Local secret scanning:** supported GitHub input fields are scanned in the browser. The scanner uses known token patterns and a high-entropy heuristic; it can miss unfamiliar formats or report false positives.
- **Pull request secret scan:** this feature reads changed file patches from GitHub and scans added lines. The UI displays masked values and activity entries contain the finding type and path, not the credential value.
- **GitHub token:** the optional GitHub PAT is kept in `chrome.storage.session` and is sent only to `api.github.com`. API-backed scans and repair operations require a token with the access those operations need.
- **LLM settings:** endpoint URL, model, and API key are stored in `chrome.storage.local`. The API key is sent to the endpoint configured by the user. Athena requests host permission for that endpoint.
- **LLM consent:** general LLM analysis is controlled by a browser-session setting. CI repair and conflict-hunk suggestions also show their relevant context-sharing consent before sending data. CI log and fetched files, or conflict snippets and surrounding lines, are scanned for secrets first in their respective flows.
- **AI context:** when a user invokes an AI feature, the requested text or collected context is sent to the configured endpoint. The endpoint provider’s own privacy and retention terms apply. Review the context and provider before enabling this feature.
- **Storage:** activity logs and dismissed-warning state use session storage. Global and repository-specific policies use local storage and survive extension reloads. Policy objects contain policy flags, not credentials.
- **Repair actions:** Athena creates a new branch and opens a pull request for supported repairs. It does not merge the created pull request or push directly to the user’s PR branch.

## 8. Installation

Use a local source checkout and install the project dependencies:

```bash
npm install
```

Build the extension package before loading it in Chrome:

```bash
npm run build
```

## 9. Development

Run the Vite development server for popup development:

```bash
npm run dev
```

The Vite server is for popup development. To exercise extension behavior, build the package and load `dist/` as an unpacked extension. The project’s unit tests are located alongside the source modules.

## 10. Build

```bash
npm run build
```

The build runs the TypeScript project check and produces the popup, background service worker, and content script under `dist/`. Static files from `public/`, including the manifest and local icons, are copied into the output directory.

## 11. Chrome Installation

1. Run the build command from the project root.
2. Open `chrome://extensions` in Chrome.
3. Enable **Developer mode**.
4. Select **Load unpacked** and choose this project’s `dist/` directory.
5. Optionally pin Athena from Chrome’s Extensions menu and open the popup from its toolbar icon.
6. After rebuilding, return to `chrome://extensions` and reload Athena to load the updated package.

Athena’s content script currently matches `https://github.com/*`; GitHub Enterprise hosts are not included in the manifest matches.

## 12. Configuration

Open Athena’s toolbar popup and select **Settings**:

- **GitHub PAT:** optional for unauthenticated page context, but required by API-backed secret scans and repair flows. Use a least-privilege token with the relevant repository, Actions, Contents, and pull request permissions. The required permissions vary by feature.
- **LLM endpoint:** optional OpenAI-compatible base URL, model name, and API key. Athena requires host permission for the endpoint. The default model is `gpt-4o-mini` when no model is entered.
- **Enable LLM analysis:** enables optional general chat and explain requests for the current browser session.
- **Rule toggles:** enable or disable individual guardrails for the current browser session in the popup.

On GitHub, open **Athena Policies** to configure the global policy or a repository-specific policy. Policies are stored locally and persist across extension reloads.

## 13. Policy System

Athena has two policy scopes:

- **Default / Global:** fallback policy for repositories without an override.
- **Repository-specific:** an override keyed by `owner/repo`. It can configure blocking direct merges to `main` or `master`, requiring passing CI checks, and individual secret detector patterns.

Saving a repository policy does not overwrite the global policy. Resetting a repository policy uses the current global policy as its starting values. The popup’s general rule-enable switches are separate session-level controls.

Merge guardrails run in the browser and intercept supported GitHub merge controls. They are not server-side branch protection and can be overridden in the warning UI. Use GitHub rulesets or branch protection when enforcement is required.

## 14. Secret Detection

The deterministic scanner recognizes supported formats for AWS access key IDs, GitHub tokens, PEM private keys, Slack tokens, Google API keys, OpenAI keys, Stripe keys, and high-entropy strings. Detector patterns can be toggled in the policy settings.

Athena can also scan added lines in pull request file patches (up to 200 files) when GitHub API access is configured. Binary files and files without a text patch are skipped. Findings include the path, line number, type, and a masked preview. The automated secret-fix flow is rule-based and previews its proposed changes; rotating or revoking an exposed credential is still necessary.

## 15. Screenshots

Screenshots of the popup, policy settings, and GitHub warning surfaces are not currently included in the repository. Add current product screenshots here when approved captures are available.

## 16. Project Structure

```text
public/
  icons/                 Extension icons at 16, 32, 48, and 128 pixels
  manifest.json          Manifest V3 configuration
src/
  background/            Service worker, GitHub fixer, CI, secret, and conflict flows
  content/               GitHub content script, radars, warnings, panel, and settings UI
  rules/                 Deterministic secret scanning rules
  storage/               Settings, policies, activity, and session storage helpers
  ui/                    Shared icons, theme tokens, and motion utilities
  App.tsx                Extension popup
  main.tsx               Popup entry point
vite.config.ts            Popup, service worker, and content-script build configuration
```

## 17. Roadmap

Potential future work, subject to project priorities:

- Add approved screenshots and a short visual walkthrough.
- Expand test coverage for end-to-end extension behavior and GitHub API failure cases.
- Improve GitHub page-selector resilience as GitHub’s interface changes.
- Evaluate support for additional GitHub Enterprise hosts and installation policies.

## 18. Limitations

- Athena runs in the browser and depends on the GitHub page structure. A GitHub UI change can affect detection or control interception.
- DOM-derived CI, review, and conflict states are best-effort page observations. Confirm important states in GitHub before acting.
- The secret scanner is heuristic and cannot guarantee detection of every credential.
- GitHub API access depends on a valid token, token permissions, repository access, and API rate limits.
- Automated repair flows do not support pushing to fork branches. They create reviewable pull requests and never merge them.
- CI repair context is limited to a failing check’s log excerpt and up to three files. Conflict resolution is bounded and may direct complex cases to manual Git commands.
- Optional LLM output can be incorrect. Review suggestions and diffs before using them.
- Athena is currently configured for `github.com`, not arbitrary GitHub Enterprise domains.

## 19. Contributing

Contributions are welcome. Before opening a pull request:

- Keep deterministic security checks independent of optional AI services.
- Avoid logging or persisting secret values, credentials, or unnecessary page content.
- Include focused tests for rule, storage, and API-flow changes where practical.
- Run `npm run build` and describe any remaining limitations in the pull request.
- Keep changes scoped and explain user-visible behavior and privacy implications.

## 20. License

No `LICENSE` file is currently included in this repository. The project’s reuse and redistribution terms have not been specified; add a license before distributing the source under an open-source license.
