/**
 * Athena – Workflow & Deploy Radar (PR Impact Scanner).
 *
 * Responsibilities:
 *  1. Scrape PR details (owner, repo, prNumber) on GitHub PR pages.
 *  2. Fetch changed file list via GitHub REST API (using PAT if set, unauthenticated otherwise).
 *  3. Fetch and parse `.github/workflows/*.yml` from the target repository.
 *  4. Match changed file paths against workflow triggers (`on.push.paths`, `on.pull_request.paths`, `paths-ignore`).
 *  5. Detect deploy-related jobs and deployment configuration files.
 *  6. Display an inline Shadow DOM panel listing:
 *     - "These workflows will run" (with [Deploy Job] badges)
 *     - "These changed files touch deployment config"
 *  7. Cache results per PR in session storage.
 *  8. Handle errors and rate limits with visible user-facing messages (never silent fails).
 */

import {
  getGitHubAuthHeaders,
  isRuleEnabled,
  isWarningDismissedSync,
  dismissWarning,
  loadWorkflowCache,
  saveWorkflowCache,
  type WorkflowRadarCache,
} from "../storage/session";
import { primerTokenStyles } from "../ui/tokens";
import { createOcticon } from "../ui/icons";
import { announceAthenaWarning, fadeOutAthenaHost } from "../ui/motion";

// ── Types ─────────────────────────────────────────────────────────────────────

export interface WorkflowInfo {
  filename: string;
  name: string;
  paths?: string[];
  pathsIgnore?: string[];
  isDeploy: boolean;
  triggersPr: boolean;
}

export interface ImpactAnalysis {
  runningWorkflows: Array<{ name: string; filename: string; isDeploy: boolean }>;
  deployFiles: string[];
}

// ── Glob & Path Matcher ───────────────────────────────────────────────────────

export function globToRegex(glob: string): RegExp {
  let g = glob.trim();
  if (g.startsWith("/")) g = g.slice(1);

  let regexStr = "";
  let i = 0;
  while (i < g.length) {
    const c = g[i];
    if (c === "*") {
      if (g[i + 1] === "*") {
        if (g[i + 2] === "/") {
          regexStr += "(?:.*/)?";
          i += 3;
          continue;
        } else {
          regexStr += ".*";
          i += 2;
          continue;
        }
      } else {
        regexStr += "[^/]*";
        i++;
        continue;
      }
    } else if (c === "?") {
      regexStr += "[^/]";
      i++;
      continue;
    } else if ("[].+^$(){}|\\".includes(c)) {
      regexStr += "\\" + c;
      i++;
    } else {
      regexStr += c;
      i++;
    }
  }

  if (!regexStr.startsWith("^")) {
    regexStr = "^" + regexStr;
  }
  if (!regexStr.endsWith("$")) {
    regexStr = regexStr + "$";
  }

  return new RegExp(regexStr);
}

export function matchesPathPattern(filePath: string, pattern: string): boolean {
  const normPath = filePath.replace(/^\//, "");
  const normPattern = pattern.replace(/^\//, "");

  if (!normPattern.includes("/")) {
    const fileName = normPath.split("/").pop() ?? normPath;
    try {
      return (
        globToRegex(normPattern).test(fileName) ||
        globToRegex(`**/${normPattern}`).test(normPath)
      );
    } catch {
      return false;
    }
  }

  try {
    return globToRegex(normPattern).test(normPath);
  } catch {
    return false;
  }
}

// ── Workflow Yaml Parser ──────────────────────────────────────────────────────

export function parseWorkflowYaml(filename: string, content: string): WorkflowInfo {
  // Workflow name
  const nameMatch = content.match(/^name:\s*['"]?([^'"\n\r]+)['"]?/m);
  const name = nameMatch ? nameMatch[1].trim() : filename;

  // Deploy detection keywords
  const deployKeywords = /\b(deploy|deployment|prod|production|release|publish|aws|helm|kubernetes|k8s|terraform|docker|cd|stage|staging|fly\.io|vercel|netlify)\b/i;
  const isDeploy = deployKeywords.test(name) || deployKeywords.test(content);

  // PR / Push trigger check
  const triggersPr =
    /pull_request/i.test(content) ||
    /on:\s*\[?[^\]\n]*pull_request/i.test(content) ||
    /on:\s*(push|workflow_dispatch|\*)/i.test(content);

  const paths: string[] = [];
  const pathsIgnore: string[] = [];

  const lines = content.split(/\r?\n/);
  let currentSection: "none" | "paths" | "paths-ignore" = "none";

  for (const line of lines) {
    const trimmed = line.trim();
    if (/^paths\s*:/i.test(trimmed)) {
      currentSection = "paths";
      continue;
    }
    if (/^paths-ignore\s*:/i.test(trimmed)) {
      currentSection = "paths-ignore";
      continue;
    }
    if (/^[a-zA-Z0-9_-]+\s*:/i.test(trimmed) && !trimmed.startsWith("-")) {
      currentSection = "none";
    }

    if (trimmed.startsWith("-") && currentSection !== "none") {
      const p = trimmed
        .replace(/^-\s*/, "")
        .replace(/^['"]|['"]$/g, "")
        .trim();
      if (p) {
        if (currentSection === "paths") paths.push(p);
        if (currentSection === "paths-ignore") pathsIgnore.push(p);
      }
    }
  }

  return {
    filename,
    name,
    paths: paths.length > 0 ? paths : undefined,
    pathsIgnore: pathsIgnore.length > 0 ? pathsIgnore : undefined,
    isDeploy,
    triggersPr,
  };
}

// ── Deploy Config File Detector ───────────────────────────────────────────────

const DEPLOY_FILE_PATTERNS = [
  /^\.github\/workflows\//i,
  /^Dockerfile/i,
  /^docker-compose/i,
  /\.tf$/i,
  /\.tfvars$/i,
  /^helm\//i,
  /^k8s\//i,
  /^kubernetes\//i,
  /^serverless\.yml$/i,
  /^fly\.toml$/i,
  /^render\.yaml$/i,
  /^vercel\.json$/i,
  /^netlify\.toml$/i,
  /^deploy\//i,
  /^deployment\//i,
  /^\.env/i,
];

export function isDeploymentConfigFile(filePath: string): boolean {
  return DEPLOY_FILE_PATTERNS.some((pattern) => pattern.test(filePath));
}

// ── Impact Logic ──────────────────────────────────────────────────────────────

export function analyzeImpact(
  changedFiles: string[],
  workflows: WorkflowInfo[]
): ImpactAnalysis {
  const runningWorkflows: Array<{ name: string; filename: string; isDeploy: boolean }> = [];
  const deployFileSet = new Set<string>();

  // Mark files matching explicit deploy config patterns
  for (const f of changedFiles) {
    if (isDeploymentConfigFile(f)) {
      deployFileSet.add(f);
    }
  }

  for (const wf of workflows) {
    if (!wf.triggersPr) continue;

    let matches = false;

    if (!wf.paths && !wf.pathsIgnore) {
      // No path filter defined → runs on all changes
      matches = true;
    } else {
      // Check paths filter if defined
      if (wf.paths && wf.paths.length > 0) {
        matches = changedFiles.some((f) =>
          wf.paths!.some((pattern) => matchesPathPattern(f, pattern))
        );
      } else {
        // If no paths filter specified but pathsIgnore is specified
        matches = true;
      }

      // Check pathsIgnore filter
      if (matches && wf.pathsIgnore && wf.pathsIgnore.length > 0) {
        const allIgnored = changedFiles.every((f) =>
          wf.pathsIgnore!.some((pattern) => matchesPathPattern(f, pattern))
        );
        if (allIgnored) {
          matches = false;
        }
      }
    }

    if (matches) {
      runningWorkflows.push({
        name: wf.name,
        filename: wf.filename,
        isDeploy: wf.isDeploy,
      });

      // If workflow is deploy-related, any file that matched it is also a deploy impact
      if (wf.isDeploy) {
        for (const f of changedFiles) {
          if (
            !wf.paths ||
            wf.paths.some((pattern) => matchesPathPattern(f, pattern))
          ) {
            deployFileSet.add(f);
          }
        }
      }
    }
  }

  return {
    runningWorkflows,
    deployFiles: Array.from(deployFileSet),
  };
}

// ── GitHub API Fetchers ────────────────────────────────────────────────────────

class ApiRateLimitError extends Error {
  constructor(message?: string) {
    super(
      message ??
        "GitHub API rate limit exceeded. Add a GitHub PAT in Athena Settings for 5,000 requests/hr."
    );
    this.name = "ApiRateLimitError";
  }
}

async function fetchPrChangedFiles(
  owner: string,
  repo: string,
  prNumber: number
): Promise<string[]> {
  const url = `https://api.github.com/repos/${owner}/${repo}/pulls/${prNumber}/files?per_page=100`;
  const authHeaders = await getGitHubAuthHeaders(url);
  const res = await fetch(url, {
    headers: { Accept: "application/vnd.github+json", ...authHeaders },
  });

  if (res.status === 403 || res.status === 429) {
    throw new ApiRateLimitError();
  }
  if (!res.ok) {
    throw new Error(`GitHub API error ${res.status}: ${res.statusText}`);
  }

  const data = (await res.json()) as Array<{ filename: string }>;
  return data.map((d) => d.filename);
}

async function fetchRepoWorkflows(
  owner: string,
  repo: string
): Promise<WorkflowInfo[]> {
  const listUrl = `https://api.github.com/repos/${owner}/${repo}/contents/.github/workflows`;
  const authHeaders = await getGitHubAuthHeaders(listUrl);
  const res = await fetch(listUrl, {
    headers: { Accept: "application/vnd.github+json", ...authHeaders },
  });

  if (res.status === 404) {
    return []; // No workflows directory in repo
  }
  if (res.status === 403 || res.status === 429) {
    throw new ApiRateLimitError();
  }
  if (!res.ok) {
    throw new Error(`GitHub API error ${res.status}: ${res.statusText}`);
  }

  const files = (await res.json()) as Array<{
    name: string;
    download_url?: string;
    type: string;
  }>;

  const yamlFiles = files.filter(
    (f) =>
      f.type === "file" &&
      (f.name.endsWith(".yml") || f.name.endsWith(".yaml"))
  );

  const workflows: WorkflowInfo[] = [];

  for (const file of yamlFiles) {
    if (!file.download_url) continue;
    try {
      const fileAuthHeaders = await getGitHubAuthHeaders(file.download_url);
      const contentRes = await fetch(file.download_url, {
        headers: fileAuthHeaders,
      });
      if (!contentRes.ok) continue;
      const text = await contentRes.text();
      workflows.push(parseWorkflowYaml(file.name, text));
    } catch {
      // Continue parsing remaining workflows if one fails
    }
  }

  return workflows;
}

// ── Shadow DOM Panel UI ───────────────────────────────────────────────────────

const RADAR_PANEL_CSS = `
  :host {
    display: block;
    margin-bottom: 14px;
    font-family: Inter, Geist, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  }

  .wf-card {
    background: var(--bg-subtle);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid var(--accent-subtle);
    border-radius: 12px;
    padding: 14px 18px;
    color: var(--fg-muted);
    box-shadow: 0 8px 20px -12px var(--bg-inset);
  }

  .wf-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    margin-bottom: 12px;
    border-bottom: 1px solid var(--border-soft);
    padding-bottom: 10px;
  }

  .wf-title-wrap {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .wf-icon { display: inline-flex; width: 16px; height: 16px; }
  .wf-icon svg { width: 100%; height: 100%; }

  .wf-title {
    font-size: 13px;
    font-weight: 700;
    color: var(--fg);
    letter-spacing: -0.01em;
  }

  .wf-badge {
    font-size: 9.5px;
    font-weight: 700;
    padding: 2px 7px;
    border-radius: 999px;
    background: var(--accent-subtle);
    border: 1px solid var(--accent-subtle);
    color: var(--accent);
    letter-spacing: 0.06em;
    text-transform: uppercase;
  }

  .wf-dismiss-btn {
    background: var(--border-soft);
    border: 1px solid var(--border-soft);
    color: var(--fg-muted);
    font-size: 13px;
    cursor: pointer;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 6px;
  }

  .wf-dismiss-btn:hover {
    color: var(--fg);
    background: var(--border-soft);
    border-color: var(--border-soft);
  }

  .wf-dismiss-btn:focus-visible {
    outline: 2px solid var(--accent);
    outline-offset: 2px;
  }

  .wf-section {
    margin-top: 10px;
  }

  .wf-section-title {
    font-size: 11px;
    font-weight: 700;
    color: var(--fg-muted);
    text-transform: uppercase;
    letter-spacing: 0.06em;
    margin-bottom: 8px;
    display: flex;
    align-items: center;
    gap: 6px;
  }

  .wf-list {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .wf-item {
    font-size: 12px;
    background: var(--bg-subtle);
    border: 1px solid var(--border-soft);
    border-radius: 8px;
    padding: 8px 12px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }

  .wf-item:hover {
    border-color: var(--accent-subtle);
  }

  .wf-item-name {
    font-weight: 600;
    color: var(--accent);
  }

  .wf-item-file {
    font-size: 10.5px;
    color: var(--fg-muted);
    font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
  }

  .deploy-tag {
    font-size: 9px;
    font-weight: 700;
    background: var(--attention-subtle);
    color: var(--attention);
    border: 1px solid var(--attention-subtle);
    padding: 2px 6px;
    border-radius: 4px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }

  .wf-empty {
    font-size: 11.5px;
    color: var(--fg-subtle);
    font-style: italic;
    padding: 4px 0;
  }

  /* Alert / Rate Limit Box */
  .wf-alert {
    background: var(--danger-subtle);
    border: 1px solid var(--danger-subtle);
    border-radius: 8px;
    padding: 12px 14px;
    margin-top: 8px;
    color: var(--danger);
    font-size: 12px;
    line-height: 1.5;
  }

  .wf-alert-title {
    font-weight: 700;
    margin-bottom: 4px;
    color: var(--danger);
  }
`;

function createWorkflowPanelHost(
  cache: WorkflowRadarCache,
  onDismiss: () => void
): HTMLDivElement {
  const host = document.createElement("div");
  host.dataset.athenaWorkflowPanel = "1";
  host.dataset.athenaThemeHost = "";

  const shadow = host.attachShadow({ mode: "open" });

  const style = document.createElement("style");
  style.textContent = `${primerTokenStyles}\n${RADAR_PANEL_CSS}`;
  shadow.appendChild(style);

  const card = document.createElement("div");
  card.className = "wf-card";

  // Header
  const header = document.createElement("div");
  header.className = "wf-header";

  const titleWrap = document.createElement("div");
  titleWrap.className = "wf-title-wrap";

  const icon = document.createElement("span");
  icon.className = "wf-icon";
  icon.appendChild(createOcticon("branch", 16));

  const title = document.createElement("span");
  title.className = "wf-title";
  title.textContent = "PR Workflow & Deploy Radar";

  const badge = document.createElement("span");
  badge.className = "wf-badge";
  badge.textContent = "ATHENA";

  titleWrap.appendChild(icon);
  titleWrap.appendChild(title);
  titleWrap.appendChild(badge);

  const dismissBtn = document.createElement("button");
  dismissBtn.className = "wf-dismiss-btn";
  dismissBtn.textContent = "✕";
  dismissBtn.setAttribute("aria-label", "Dismiss workflow panel");
  dismissBtn.addEventListener("click", () => fadeOutAthenaHost(host, onDismiss));

  header.appendChild(titleWrap);
  header.appendChild(dismissBtn);
  card.appendChild(header);

  // If Error or Rate Limit
  if (cache.isRateLimited || cache.errorMessage) {
    const alert = document.createElement("div");
    alert.className = cache.isRateLimited ? "wf-alert wf-alert-warning" : "wf-alert";

    const alertTitle = document.createElement("div");
    alertTitle.className = "wf-alert-title";
    alertTitle.appendChild(createOcticon(cache.isRateLimited ? "warning" : "alert", 14));
    alertTitle.appendChild(document.createTextNode(cache.isRateLimited
      ? "GitHub API Rate Limit Exceeded"
      : "Error Scanning Workflows"));

    const alertMsg = document.createElement("div");
    alertMsg.textContent = cache.errorMessage ??
      "Unauthenticated requests are limited to 60/hr. Open Athena Settings in the extension popup and paste a GitHub Personal Access Token for 5,000 req/hr.";

    alert.appendChild(alertTitle);
    alert.appendChild(alertMsg);
    card.appendChild(alert);
    announceAthenaWarning();

    shadow.appendChild(card);
    return host;
  }

  // Section 1: Running Workflows
  const sec1 = document.createElement("div");
  sec1.className = "wf-section";

  const sec1Title = document.createElement("div");
  sec1Title.className = "wf-section-title";
  sec1Title.appendChild(createOcticon("branch", 14));
  sec1Title.appendChild(document.createTextNode(`Workflows that will run (${cache.runningWorkflows.length})`));
  sec1.appendChild(sec1Title);

  if (cache.runningWorkflows.length === 0) {
    const empty = document.createElement("div");
    empty.className = "wf-empty";
    empty.textContent = "No matching workflows triggered by these changes.";
    sec1.appendChild(empty);
  } else {
    const list = document.createElement("ul");
    list.className = "wf-list";
    for (const wf of cache.runningWorkflows) {
      const item = document.createElement("li");
      item.className = "wf-item";

      const nameSpan = document.createElement("span");
      nameSpan.className = "wf-item-name";
      nameSpan.textContent = wf.name;

      const rightWrap = document.createElement("div");
      rightWrap.style.display = "flex";
      rightWrap.style.alignItems = "center";
      rightWrap.style.gap = "6px";

      if (wf.isDeploy) {
        const tag = document.createElement("span");
        tag.className = "deploy-tag";
        tag.textContent = "Deploy Job";
        rightWrap.appendChild(tag);
      }

      const fileSpan = document.createElement("span");
      fileSpan.className = "wf-item-file";
      fileSpan.textContent = wf.filename;
      rightWrap.appendChild(fileSpan);

      item.appendChild(nameSpan);
      item.appendChild(rightWrap);
      list.appendChild(item);
    }
    sec1.appendChild(list);
  }
  card.appendChild(sec1);

  // Section 2: Deployment Config Changed Files
  const sec2 = document.createElement("div");
  sec2.className = "wf-section";

  const sec2Title = document.createElement("div");
  sec2Title.className = "wf-section-title";
  sec2Title.textContent = `🚀 Changed files touching deployment config (${cache.deployFiles.length})`;
  sec2.appendChild(sec2Title);

  if (cache.deployFiles.length === 0) {
    const empty = document.createElement("div");
    empty.className = "wf-empty";
    empty.textContent = "No changed files touch deployment configuration.";
    sec2.appendChild(empty);
  } else {
    const list = document.createElement("ul");
    list.className = "wf-list";
    for (const file of cache.deployFiles) {
      const item = document.createElement("li");
      item.className = "wf-item";

      const fileSpan = document.createElement("span");
      fileSpan.className = "wf-item-file";
      fileSpan.style.color = "var(--attention)";
      fileSpan.textContent = file;

      item.appendChild(fileSpan);
      list.appendChild(item);
    }
    sec2.appendChild(list);
  }
  card.appendChild(sec2);

  shadow.appendChild(card);
  return host;
}

// ── Main Runner ───────────────────────────────────────────────────────────────

const PANEL_DONE_ATTR = "data-athena-wf-panel-done";

function parsePrUrl(
  url: string
): { owner: string; repo: string; prNumber: number } | null {
  const m = url.match(/github\.com\/([^/]+)\/([^/]+)\/pull\/(\d+)/);
  if (!m) return null;
  return { owner: m[1], repo: m[2], prNumber: parseInt(m[3], 10) };
}

export async function runWorkflowRadar(): Promise<void> {
  if (!isRuleEnabled("passive_workflow-radar")) return;

  const currentUrl = window.location.href;
  const parsed = parsePrUrl(currentUrl);
  if (!parsed) return;

  if (isWarningDismissedSync("passive_workflow-radar", currentUrl)) return;

  // Injection anchor
  const anchor = document.querySelector(
    ".discussion-timeline-actions, .merge-pr-section, #partial-pull-merging, #discussion_bucket"
  );
  if (!anchor) return;
  if (anchor.getAttribute(PANEL_DONE_ATTR) !== null) return;
  anchor.setAttribute(PANEL_DONE_ATTR, "1");

  const prKey = `${parsed.owner}_${parsed.repo}_${parsed.prNumber}`;

  let cache = await loadWorkflowCache(prKey);

  if (!cache) {
    try {
      const [changedFiles, workflows] = await Promise.all([
        fetchPrChangedFiles(parsed.owner, parsed.repo, parsed.prNumber),
        fetchRepoWorkflows(parsed.owner, parsed.repo),
      ]);

      const analysis = analyzeImpact(changedFiles, workflows);

      cache = {
        prKey,
        timestamp: Date.now(),
        changedFiles,
        runningWorkflows: analysis.runningWorkflows,
        deployFiles: analysis.deployFiles,
      };

      await saveWorkflowCache(cache);
    } catch (err) {
      const isRateLimit = err instanceof ApiRateLimitError;
      const errMsg = err instanceof Error ? err.message : String(err);

      cache = {
        prKey,
        timestamp: Date.now(),
        changedFiles: [],
        runningWorkflows: [],
        deployFiles: [],
        errorMessage: errMsg,
        isRateLimited: isRateLimit,
      };

      // Store error cache so we don't spam failed API calls on every mutation
      await saveWorkflowCache(cache);
    }
  }

  const panel = createWorkflowPanelHost(cache, async () => {
    await dismissWarning("passive_workflow-radar", currentUrl);
  });

  anchor.insertBefore(panel, anchor.firstChild);
}
