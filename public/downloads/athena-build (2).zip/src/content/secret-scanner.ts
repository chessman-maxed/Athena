/**
 * Athena – Advanced Tier: Secret scanner.
 *
 * Monitors <textarea> and [contenteditable] elements (comment boxes,
 * PR descriptions, commit messages) for patterns that look like leaked
 * secrets / API keys. Detection is fully deterministic regex — no network calls.
 *
 * When a match is found, an inline Shadow DOM warning banner is injected
 * BELOW the textarea. The warning disappears if the user removes the secret.
 */

import { primerTokenStyles } from "../ui/tokens";
import { createOcticon } from "../ui/icons";
import { announceAthenaWarning, fadeOutAthenaHost } from "../ui/motion";

// ── Secret pattern definitions ────────────────────────────────────────────────
interface SecretPattern {
  id: string;
  name: string;
  pattern: RegExp;
  severity: "critical" | "danger";
}

export const SECRET_PATTERNS: SecretPattern[] = [
  {
    id: "aws-access-key",
    name: "AWS Access Key ID",
    pattern: /\bAKIA[0-9A-Z]{16}\b/,
    severity: "critical",
  },
  {
    id: "aws-secret-key",
    name: "AWS Secret Access Key",
    // 40-char base64-ish string following common label patterns
    pattern: /(?:aws[_\-\s]?secret[_\-\s]?(?:access[_\-\s]?)?key|AWS_SECRET)[^\w]?["']?[:=]\s*["']?([A-Za-z0-9/+=]{40})/i,
    severity: "critical",
  },
  {
    id: "github-pat",
    name: "GitHub Personal Access Token",
    pattern: /\bghp_[A-Za-z0-9]{36}\b|\bgho_[A-Za-z0-9]{36}\b|\bghu_[A-Za-z0-9]{36}\b|\bghs_[A-Za-z0-9]{36}\b|\bghr_[A-Za-z0-9]{36}\b/,
    severity: "critical",
  },
  {
    id: "openai-key",
    name: "OpenAI API Key",
    pattern: /\bsk-[A-Za-z0-9]{20,}T3BlbkFJ[A-Za-z0-9]{20,}\b|\bsk-proj-[A-Za-z0-9_-]{40,}\b/,
    severity: "critical",
  },
  {
    id: "stripe-secret",
    name: "Stripe Secret Key",
    pattern: /\bsk_live_[0-9a-zA-Z]{24,}\b/,
    severity: "critical",
  },
  {
    id: "stripe-publishable",
    name: "Stripe Publishable Key",
    pattern: /\bpk_live_[0-9a-zA-Z]{24,}\b/,
    severity: "danger",
  },
  {
    id: "google-api-key",
    name: "Google API Key",
    pattern: /\bAIza[0-9A-Za-z_-]{35}\b/,
    severity: "critical",
  },
  {
    id: "slack-token",
    name: "Slack Token",
    pattern: /\bxox[baprs]-[0-9A-Za-z-]{10,}\b/,
    severity: "critical",
  },
  {
    id: "private-key-block",
    name: "Private Key",
    pattern: /-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY/,
    severity: "critical",
  },
  {
    id: "generic-secret",
    name: "Possible API Secret",
    // Matches things like: secret="abc123...", api_key: 'abc...'
    pattern: /(?:secret|api[_\-]?key|access[_\-]?token|auth[_\-]?token|private[_\-]?key)\s*[:=]\s*["']?([A-Za-z0-9_/+=\-]{20,})/i,
    severity: "danger",
  },
];

// ── Warning banner CSS (inside Shadow DOM) ────────────────────────────────────
const SCANNER_CSS = `
  :host {
    display: block;
    margin-top: 6px;
  }

  .secret-banner {
    border-radius: 8px;
    padding: 10px 14px;
    border: 1.5px solid var(--danger);
    background: var(--bg-subtle);
    display: flex;
    align-items: flex-start;
    gap: 10px;
  }

  .secret-icon {
    display: inline-flex;
    width: 18px;
    height: 18px;
    flex-shrink: 0;
    margin-top: 1px;
    color: var(--danger);
  }

  .secret-icon svg { width: 100%; height: 100%; }

  .secret-content { flex: 1; min-width: 0; }

  .secret-header {
    display: flex;
    align-items: center;
    gap: 7px;
    margin-bottom: 3px;
  }

  .secret-title {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
    font-size: 12px;
    font-weight: 700;
    color: var(--danger);
    letter-spacing: 0.04em;
    text-transform: uppercase;
  }

  .secret-badge {
    font-size: 9px;
    font-weight: 700;
    padding: 1px 6px;
    border-radius: 999px;
    background: var(--danger-emphasis);
    color: var(--fg);
    letter-spacing: 0.06em;
    text-transform: uppercase;
  }

  .secret-body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
    font-size: 11px;
    color: var(--fg-muted);
    line-height: 1.5;
  }

  strong { color: var(--danger); font-weight: 600; }

  .secret-dismiss {
    font-size: 10px;
    font-weight: 600;
    padding: 3px 8px;
    border-radius: 5px;
    border: 1px solid var(--danger-emphasis);
    background: transparent;
    color: var(--fg-muted);
    cursor: pointer;
    margin-top: 7px;
    display: inline-block;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
  }

  .secret-dismiss:hover { background: var(--bg-subtle); }
`;

function createSecretBannerHost(
  matchedName: string,
  onDismiss: () => void
): HTMLDivElement {
  const host = document.createElement("div");
  host.dataset.athenaSecretBanner = "1";
  host.dataset.athenaThemeHost = "";

  const shadow = host.attachShadow({ mode: "open" });

  const style = document.createElement("style");
  style.textContent = `${primerTokenStyles}\n${SCANNER_CSS}`;
  shadow.appendChild(style);

  const banner = document.createElement("div");
  banner.className = "secret-banner";

  const icon = document.createElement("span");
  icon.className = "secret-icon";
  icon.appendChild(createOcticon("key", 18));

  const content = document.createElement("div");
  content.className = "secret-content";

  const header = document.createElement("div");
  header.className = "secret-header";

  const title = document.createElement("span");
  title.className = "secret-title";
  title.textContent = "Athena – Secret Detected";

  const badge = document.createElement("span");
  badge.className = "secret-badge";
  badge.textContent = "CRITICAL";

  header.appendChild(title);
  header.appendChild(badge);

  const body = document.createElement("div");
  body.className = "secret-body";
  body.innerHTML = `Possible <strong>${matchedName}</strong> found in your text. Remove it before submitting — secrets posted to GitHub are public and can be exploited within seconds.`;

  const dismissBtn = document.createElement("button");
  dismissBtn.className = "secret-dismiss";
  dismissBtn.type = "button";
  dismissBtn.textContent = "Dismiss warning";
  dismissBtn.addEventListener("click", onDismiss);

  content.appendChild(header);
  content.appendChild(body);
  content.appendChild(dismissBtn);

  banner.appendChild(icon);
  banner.appendChild(content);
  shadow.appendChild(banner);
  announceAthenaWarning();

  return host;
}

// ── Per-textarea state ────────────────────────────────────────────────────────
const SCANNER_ATTR = "data-athena-scanner";

function getTextValue(el: Element): string {
  if (el instanceof HTMLTextAreaElement) return el.value;
  if (el instanceof HTMLInputElement) return el.value;
  return el.textContent ?? "";
}

function scanText(text: string): SecretPattern | null {
  for (const sp of SECRET_PATTERNS) {
    if (sp.pattern.test(text)) return sp;
  }
  return null;
}

export function attachSecretScanner(el: Element): void {
  if (el.getAttribute(SCANNER_ATTR) !== null) return;
  el.setAttribute(SCANNER_ATTR, "1");

  let currentBanner: HTMLElement | null = null;
  let dismissed = false;

  const removeBanner = () => {
    if (currentBanner) {
      fadeOutAthenaHost(currentBanner);
      currentBanner = null;
    }
  };

  const check = () => {
    if (dismissed) return;
    const text = getTextValue(el);
    const match = scanText(text);

    if (match) {
      if (!currentBanner) {
        currentBanner = createSecretBannerHost(match.name, () => {
          dismissed = true;
          removeBanner();
        });
        el.parentElement?.insertBefore(currentBanner, el.nextSibling);
      }
    } else {
      // Secret removed — reset dismissed flag and remove banner
      dismissed = false;
      removeBanner();
    }
  };

  el.addEventListener("input", check, { passive: true });
  el.addEventListener("paste", () => setTimeout(check, 0), { passive: true });
}
