/**
 * Athena – WarningBanner component.
 *
 * Renders inside the Shadow DOM react root. Uses Tailwind utility classes
 * (processed by the content build's tailwindcss plugin and inlined as a CSS
 * string in the shadow root).
 *
 * Severity levels:
 *   info  – blue  – informational notice, non-blocking
 *   warn  – amber – caution, user should pay attention
 *   block – red   – dangerous action intercepted / submission blocked
 */
import { useEffect, useState } from "react";
import { announceAthenaWarning } from "../ui/motion";

export type Severity = "info" | "warn" | "block";

export interface BannerAction {
  label: string;
  onClick: () => void;
  variant?: "primary" | "ghost";
}

export interface BannerProps {
  severity: Severity;
  title: string;
  message: string;
  onDismiss: () => void;
  actions?: BannerAction[];
}

const PALETTE: Record<Severity, {
  wrapper: string;
  iconBg: string;
  iconColor: string;
  dismiss: string;
  actionPrimary: string;
  actionGhost: string;
}> = {
  info: {
    wrapper: "border-neutral-700 text-neutral-100",
    iconBg: "border-neutral-700",
    iconColor: "text-neutral-200",
    dismiss: "text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800",
    actionPrimary: "athena-primary-btn",
    actionGhost: "text-neutral-200 border border-neutral-700 hover:bg-neutral-900",
  },
  warn: {
    wrapper: "border-neutral-700 text-neutral-100",
    iconBg: "border-neutral-700",
    iconColor: "text-neutral-200",
    dismiss: "text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800",
    actionPrimary: "athena-primary-btn",
    actionGhost: "text-neutral-200 border border-neutral-700 hover:bg-neutral-900",
  },
  block: {
    wrapper: "border-neutral-700 text-neutral-100",
    iconBg: "border-neutral-700",
    iconColor: "text-neutral-200",
    dismiss: "text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800",
    actionPrimary: "athena-primary-btn",
    actionGhost: "text-neutral-200 border border-neutral-700 hover:bg-neutral-900",
  },
};

const ICON_PATH: Record<Severity, string> = {
  info: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z M12 11v5 M12 8h.01",
  warn: "M12 3 22 20H2L12 3z M12 9v4 M12 16h.01",
  block: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z M8 8l8 8 M16 8l-8 8",
};

function SeverityIcon({ severity }: { severity: Severity }) {
  if (severity === "info") {
    return (
      <img
        src={chrome.runtime.getURL("icons/athena-32.png")}
        alt=""
        aria-hidden="true"
        width="22"
        height="22"
        style={{ objectFit: "contain" }}
      />
    );
  }

  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d={ICON_PATH[severity]} />
    </svg>
  );
}

export function WarningBanner({
  severity,
  title,
  message,
  onDismiss,
  actions = [],
}: BannerProps) {
  const [exiting, setExiting] = useState(false);
  const p = PALETTE[severity];

  useEffect(() => {
    announceAthenaWarning();
  }, []);

  function handleDismiss() {
    setExiting(true);
    const exitDelay = window.matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : 180;
    setTimeout(onDismiss, exitDelay);
  }

  return (
    <div
      role="alert"
      aria-live="polite"
      data-severity={severity}
      style={{
        pointerEvents: "auto",
        width: "min(440px, calc(100vw - 32px))",
        minWidth: "min(300px, calc(100vw - 32px))",
        maxWidth: "min(440px, calc(100vw - 32px))",
        opacity: exiting ? 0 : 1,
        transform: exiting ? "translateY(4px)" : "translateY(0)",
        backdropFilter: "blur(12px)",
        WebkitBackdropFilter: "blur(12px)",
      }}
      className={[
          `athena-banner athena-banner-${severity} flex items-start gap-3 rounded-xl border p-3.5 text-xs backdrop-blur-md transition-colors duration-150 select-none`,
        p.wrapper,
      ].join(" ")}
    >
      {/* Severity icon with cyber badge */}
      <div className={`athena-banner-icon w-7 h-7 rounded-lg border flex items-center justify-center shrink-0 text-sm font-bold select-none ${p.iconBg} ${p.iconColor}`} style={{ color: severity === "info" ? "var(--accent)" : severity === "warn" ? "var(--attention)" : "var(--danger)" }}>
        <SeverityIcon severity={severity} />
      </div>

      {/* Text body + action buttons */}
      <div className="athena-banner-body flex-1 min-w-0 pt-0.5">
        <div className="athena-banner-heading flex items-start justify-between gap-2">
          <p className="athena-banner-title font-bold text-xs text-neutral-100 leading-tight">{title}</p>
          <span className="athena-badge" style={{ color: severity === "info" ? "var(--accent)" : severity === "warn" ? "var(--attention)" : "var(--danger)" }}>
            {severity === "info" ? "INFO" : severity === "warn" ? "WARNING" : "DANGER"}
          </span>
        </div>
        <p className="athena-banner-message mt-1 text-[11.5px] text-neutral-300 leading-relaxed">{message}</p>

        {actions.length > 0 && (
          <div className="athena-banner-actions mt-2.5 flex flex-wrap gap-2">
            {actions.map((action, i) => (
              <button
                key={i}
                type="button"
                onClick={action.onClick}
                className={[
                  "athena-banner-action rounded-lg px-3 py-1 text-xs font-semibold cursor-pointer transition-colors duration-150 active:brightness-95",
                  action.variant === "primary" ? p.actionPrimary : p.actionGhost,
                ].join(" ")}
              >
                {action.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Close button */}
      <button
        type="button"
        aria-label="Dismiss banner"
        onClick={handleDismiss}
        className={[
          "athena-banner-dismiss shrink-0 rounded-lg p-1 text-xs transition-colors cursor-pointer leading-none",
          p.dismiss,
        ].join(" ")}
      >
        ✕
      </button>
    </div>
  );
}
