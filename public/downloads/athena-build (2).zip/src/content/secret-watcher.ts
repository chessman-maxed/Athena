/**
 * Athena – Secret Watcher (content-script integration).
 *
 * Architecture
 * ────────────
 * Single delegated listeners on document for "input" and "paste" debounce
 * scanning to every textarea / contenteditable on the page — including
 * elements added dynamically by GitHub's React/Turbo SPA.
 *
 * Per-field state machine
 * ───────────────────────
 *   CLEAN   → (finds secret) → BLOCKED
 *   BLOCKED → (secret cleared) → CLEAN           (auto-dismiss)
 *   BLOCKED → ("I understand") → ACKNOWLEDGED    (submit re-enabled)
 *   ACKNOWLEDGED → (new secret found) → BLOCKED  (re-block)
 *
 * UI
 * ──
 *   Uses addBanner / removeBanner from shadow-host so banners render
 *   inside the isolated Shadow DOM and are immune to GitHub's CSS.
 *   On BLOCKED, the nearest <button type="submit"> in the same form is
 *   disabled.  On CLEAN / ACKNOWLEDGED, it is re-enabled.
 *
 * Privacy
 * ───────
 *   Only the finding TYPE is passed to addBanner — the actual credential
 *   text is never stored, logged, or sent anywhere.
 */

import { scanText, type Finding } from "../rules/secrets";
import {
  isRuleEnabled,
  isSecretPatternEnabledForRepo,
  type RuleId,
  type SecretPatternId,
  logActivity,
} from "../storage/session";
import { isRestrictedPage } from "./restricted-pages";

// ── Field state ───────────────────────────────────────────────────────────────

type FieldStatus = "clean" | "blocked" | "acknowledged";

interface FieldState {
  status: FieldStatus;
  bannerId: string;
  panelHost: HTMLDivElement | null;
  submitEl: HTMLButtonElement | HTMLInputElement | null;
  debounceTimer: ReturnType<typeof setTimeout> | null;
}

// WeakMap so entries are GC'd when elements are removed from the DOM
const fieldState = new WeakMap<Element, FieldState>();

// ── DOM helpers ───────────────────────────────────────────────────────────────

function isEditableField(el: Element): el is HTMLTextAreaElement | HTMLElement {
  return (
    el instanceof HTMLTextAreaElement ||
    el instanceof HTMLInputElement ||
    (el instanceof HTMLElement && el.isContentEditable)
  );
}

function getTextValue(el: Element): string {
  if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
    return el.value;
  }
  return (el as HTMLElement).innerText ?? "";
}

/**
 * Walk up the DOM from `el` to find the nearest submit button in its form
 * or within the same ancestral container.
 */
function findNearestSubmit(
  el: Element
): HTMLButtonElement | HTMLInputElement | null {
  // 1. If inside a <form>, query that form's submit button
  const form = el.closest("form");
  if (form) {
    const btn =
      form.querySelector<HTMLButtonElement>("button[type=submit]") ??
      form.querySelector<HTMLInputElement>("input[type=submit]") ??
      // GitHub sometimes uses a button without explicit type inside a form
      form.querySelector<HTMLButtonElement>("button:not([type=button]):not([type=reset])");
    if (btn) return btn;
  }

  // 2. Walk up to find a comment/editor container and look for submit nearby
  const container = el.closest(
    ".js-write-bucket, .timeline-comment-group, " +
    ".comment-form-wrapper, .js-comment-container, " +
    "[data-target='diff-file-bucket']"
  );
  if (container) {
    return (
      container.querySelector<HTMLButtonElement>("button[type=submit]") ??
      container.querySelector<HTMLButtonElement>(".js-comment-submit-button") ??
      null
    );
  }

  return null;
}

// ── Banner ID helpers ─────────────────────────────────────────────────────────

let _bannerSeq = 0;
function newBannerId(): string {
  return `athena-secret-${++_bannerSeq}`;
}

// ── State transitions ─────────────────────────────────────────────────────────

function getOrCreateState(el: Element): FieldState {
  if (!fieldState.has(el)) {
    fieldState.set(el, {
      status: "clean",
      bannerId: newBannerId(),
      panelHost: null,
      submitEl: null,
      debounceTimer: null,
    });
  }
  return fieldState.get(el)!;
}

function setBlocked(el: Element, findings: Finding[]): void {
  const state = getOrCreateState(el);

  if (state.status === "blocked") {
    renderPanel(el, state, "threat", findings[0]);
    return; // already logged and blocked
  }

  state.status = "blocked";
  state.submitEl = findNearestSubmit(el);

  // Disable the submit button
  if (state.submitEl) {
    state.submitEl.disabled = true;
  }

  const topType = findings[0].type;
  const repoMatch = window.location.pathname.match(/^\/([^/]+)\/([^/]+)/);
  void logActivity({
    type: "secret-blocked",
    ruleId: TYPE_TO_RULE_ID[topType] ?? "secret_high-entropy",
    label: topType,
    repo: repoMatch ? `${repoMatch[1]}/${repoMatch[2]}` : "",
  });
  renderPanel(el, state, "threat", findings[0]);
}

function setClean(el: Element): void {
  const state = fieldState.get(el);
  if (!state) return;

  const hadFinding = state.status === "blocked";
  const hasText = getTextValue(el).trim().length > 0;
  if (!hadFinding && !hasText) {
    removePanel(state);
    state.status = "clean";
    return;
  }

  state.status = "clean";

  // Re-enable submit
  if (state.submitEl) {
    state.submitEl.disabled = false;
    state.submitEl = null;
  }

  if (hasText) renderPanel(el, state, "safe");
  else removePanel(state);
}

function setAcknowledged(el: Element): void {
  const state = fieldState.get(el);
  if (!state) return;

  state.status = "acknowledged";

  // Re-enable submit so the user can proceed
  if (state.submitEl) {
    state.submitEl.disabled = false;
  }

  removePanel(state);
  state.bannerId = newBannerId();
}

// This UI receives only detector labels and safe location metadata. The finding
// preview is deliberately ignored; no secret substring is copied into the DOM.
type PanelMode = "scanning" | "safe" | "threat";
const PANEL_CSS = `
  :host{display:block;margin:8px 0;font:12px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif;color:#fff}
  *{box-sizing:border-box}.panel{padding:12px 13px;border:1px solid rgba(255,255,255,.1);border-radius:9px;background:rgba(10,10,10,.94);box-shadow:0 5px 18px rgba(0,0,0,.24);animation:enter 200ms ease-out both}
  .panel.threat{background:rgba(45,12,14,.92);border-color:rgba(239,68,68,.4);box-shadow:0 0 10px rgba(239,68,68,.06)}
  .panel.safe{background:rgba(8,32,25,.9);border-color:rgba(16,185,129,.3)}
  .head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px}.brand{display:flex;align-items:center;gap:7px;font-weight:750;letter-spacing:.09em;font-size:11px}.status{font:700 10px ui-monospace,monospace;letter-spacing:.07em;color:#00f0ff}.safe .status{color:#34d399}.threat .status{color:#f87171}
  .dot{width:7px;height:7px;border-radius:50%;background:currentColor;box-shadow:0 0 5px currentColor}.scanning .dot{animation:pulse 2s ease-in-out infinite}.title{font-weight:750;font-size:13px;margin:2px 0 3px}.safe .title{color:#34d399}.threat .title{color:#f87171}.sub{color:#a3a3a3}.pipeline{display:grid;gap:3px;margin-top:9px;color:#737373;font:10px/1.35 ui-monospace,monospace}.stage{display:flex;align-items:center;gap:7px}.stage::before{content:"";width:5px;height:5px;border:1px solid currentColor;border-radius:50%}.stage:not(:last-child)::after{content:"↓";margin-left:auto;color:#555}.stage.active{color:#00f0ff}.stage.active::before{background:#00f0ff;box-shadow:0 0 7px #00f0ff}.scanner-scan-line{height:2px;margin-top:8px;overflow:hidden;background:rgba(0,240,255,.08)}.scanner-scan-line::after{display:block;width:28%;height:100%;content:"";background:#00f0ff;box-shadow:0 0 6px rgba(0,240,255,.5);animation:scanner-scan 1.8s ease-in-out infinite}.meta{display:grid;grid-template-columns:70px 1fr;gap:4px 8px;margin-top:9px;padding-top:8px;border-top:1px solid rgba(255,255,255,.08);font:10px/1.4 ui-monospace,monospace}.label{color:#a3a3a3;text-transform:uppercase}.value{color:#f87171;overflow-wrap:anywhere}.preview{color:#fca5a5}.actions{display:flex;gap:7px;margin-top:10px}.actions button{border:1px solid rgba(255,255,255,.16);border-radius:6px;padding:6px 9px;background:#171717;color:#eee;font:600 10px system-ui,sans-serif;cursor:pointer;transition:background 180ms,border-color 180ms,filter 180ms}.actions button:hover{filter:brightness(1.06);border-color:rgba(0,240,255,.35)}.actions .dismiss{border-color:rgba(239,68,68,.35);color:#fca5a5}.safe .title{margin-bottom:0}
  @keyframes pulse{50%{opacity:.72;box-shadow:0 0 7px rgba(0,240,255,.38)}}@keyframes scanner-scan{0%{transform:translateX(-120%)}100%{transform:translateX(460%)}}@keyframes enter{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
  @media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}}
`;

function ensurePanel(el: Element, state: FieldState): HTMLDivElement {
  if (state.panelHost?.isConnected) return state.panelHost;
  const host = document.createElement("div");
  host.dataset.athenaSecretScanner = "";
  const shadow = host.attachShadow({ mode: "open" });
  const style = document.createElement("style"); style.textContent = PANEL_CSS; shadow.append(style);
  (el.parentElement ?? el).insertAdjacentElement("afterend", host);
  state.panelHost = host;
  return host;
}

function removePanel(state: FieldState): void {
  state.panelHost?.remove();
  state.panelHost = null;
}

function safeLocation(el: Element, matchIndex: number): { path: string; line: string } {
  const parts = window.location.pathname.split("/").filter(Boolean);
  let path = "GitHub editor";
  const marker = parts.findIndex((part) => part === "edit" || part === "blob");
  if (marker >= 0 && parts.length > marker + 2) path = parts.slice(marker + 2).join("/");
  let line = "—";
  if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement || (el instanceof HTMLElement && el.isContentEditable)) {
    const text = getTextValue(el);
    let lineNumber = 1;
    for (let i = 0; i < Math.min(matchIndex, text.length); i++) if (text.charCodeAt(i) === 10) lineNumber++;
    line = String(lineNumber);
  } else {
    const lineEl = el.closest("[data-line-number]");
    if (lineEl) line = lineEl.getAttribute("data-line-number") || "—";
  }
  return { path, line };
}

function maskedTypePreview(type: string): string {
  if (type === "GitHub Fine-Grained PAT") return "github_pat_••••••••";
  if (type === "GitHub Personal Access Token") return "ghp_••••••••••••";
  if (type.startsWith("AWS")) return "AKIA••••••••••";
  if (type.startsWith("OpenAI")) return "sk-••••••••••••";
  if (type.startsWith("Slack")) return "xox•-••••••••••";
  return "••••••••••••••";
}

function renderPanel(el: Element, state: FieldState, mode: PanelMode, finding?: Finding): void {
  const host = ensurePanel(el, state);
  const shadow = host.shadowRoot!;
  shadow.querySelector(".panel")?.remove();
  const panel = document.createElement("section"); panel.className = `panel ${mode}`;
  const head = document.createElement("div"); head.className = "head";
  const brand = document.createElement("div"); brand.className = "brand"; brand.textContent = "ATHENA SECRET SCANNER";
  const status = document.createElement("span"); status.className = "status";
  const dot = document.createElement("span"); dot.className = "dot"; dot.setAttribute("aria-hidden", "true");
  status.append(dot, document.createTextNode(` ${mode === "scanning" ? "SCANNING" : mode === "safe" ? "CLEAR" : "THREAT"}`));
  head.append(brand, status); panel.append(head);
  const title = document.createElement("div"); title.className = "title";
  const sub = document.createElement("div"); sub.className = "sub";
  if (mode === "scanning") {
    title.textContent = "Analyzing locally";
    const stages = ["INPUT", "LOCAL RULE MATCH", "PATTERN CLASSIFIED", "RISK FLAGGED", "USER ACTION"];
    const pipeline = document.createElement("div"); pipeline.className = "pipeline";
    stages.forEach((label, index) => { const row = document.createElement("div"); row.className = `stage${index === 1 ? " active" : ""}`; row.textContent = label; pipeline.append(row); });
    const scanLine = document.createElement("div"); scanLine.className = "scanner-scan-line";
    panel.append(title, pipeline, scanLine);
  } else if (mode === "safe") {
    title.textContent = "SCAN CLEAR"; sub.textContent = "No suspicious credentials detected."; panel.append(title, sub);
  } else if (finding) {
    title.textContent = "SECRET DETECTED";
    sub.textContent = "Potential credential found. Submission is paused until you choose an action.";
    const { path, line } = safeLocation(el, finding.index);
    const meta = document.createElement("div"); meta.className = "meta";
    const rows: [string, string, string?][] = [
      ["Type", finding.type], ["Location", path], ["Detected", maskedTypePreview(finding.type), "preview"],
      ["Rule ID", TYPE_TO_RULE_ID[finding.type] ?? "secret_high-entropy"], ["Line", line], ["Risk", "CRITICAL"],
    ];
    for (const [label, value, extraClass] of rows) { const l = document.createElement("span"); l.className = "label"; l.textContent = label; const v = document.createElement("span"); v.className = `value ${extraClass ?? ""}`; v.textContent = value; meta.append(l, v); }
    panel.append(title, sub, meta);
    const actions = document.createElement("div"); actions.className = "actions";
    const view = document.createElement("button"); view.type = "button"; view.textContent = "VIEW LOCATION";
    view.addEventListener("click", () => { el.scrollIntoView({ behavior: "smooth", block: "center" }); if (el instanceof HTMLElement) el.focus({ preventScroll: true }); });
    const dismiss = document.createElement("button"); dismiss.type = "button"; dismiss.className = "dismiss"; dismiss.textContent = "DISMISS";
    dismiss.addEventListener("click", () => {
      if (window.confirm("A possible secret was detected. Dismiss this warning and continue with submission?")) {
        setAcknowledged(el);
      }
    });
    actions.append(view, dismiss); panel.append(actions);
  }
  shadow.append(panel);
}

// ── Mapping: Finding.type → RuleId & SecretPatternId ────────────────────────
 
const TYPE_TO_RULE_ID: Record<string, RuleId> = {
  "AWS Access Key ID":           "secret_aws-access-key",
  "GitHub Personal Access Token":"secret_github-pat",
  "GitHub Fine-Grained PAT":     "secret_github-fine-grained-pat",
  "PEM Private Key":             "secret_pem-private-key",
  "Slack Token":                 "secret_slack-token",
  "Google API Key":              "secret_google-api-key",
  "OpenAI API Key":              "secret_openai-key",
  "Stripe Secret Key":           "secret_stripe-key",
  "Stripe Publishable Key":      "secret_stripe-key",
  "High-Entropy String":         "secret_high-entropy",
};

const TYPE_TO_PATTERN_ID: Record<string, SecretPatternId> = {
  "AWS Access Key ID":           "aws-access-key",
  "GitHub Personal Access Token":"github-pat",
  "GitHub Fine-Grained PAT":     "github-fine-grained-pat",
  "PEM Private Key":             "pem-private-key",
  "Slack Token":                 "slack-token",
  "Google API Key":              "google-api-key",
  "OpenAI API Key":              "openai-key",
  "Stripe Secret Key":           "stripe-key",
  "Stripe Publishable Key":      "stripe-key",
  "High-Entropy String":         "high-entropy",
};

// ── Core scan + state update ──────────────────────────────────────────────────

function runScan(el: Element): void {
  if (isRestrictedPage()) return;
  const state = getOrCreateState(el);

  // If acknowledged, skip scanning until the field goes clean then dirty again
  if (state.status === "acknowledged") {
    const text = getTextValue(el);
    const findings = scanText(text);
    if (findings.length === 0) {
      // Cleared — reset so future typing re-enables scanning
      state.status = "clean";
    }
    return;
  }

  const text = getTextValue(el);
  const m = window.location.pathname.match(/^\/([^/]+)\/([^/]+)/);
  const repoKey = m ? `${m[1]}/${m[2]}`.toLowerCase() : "";

  // Filter out findings for disabled rules or disabled repo-specific secret patterns
  const findings = scanText(text).filter((f: Finding) => {
    const patternId = TYPE_TO_PATTERN_ID[f.type];
    if (patternId && !isSecretPatternEnabledForRepo(patternId, repoKey)) {
      return false;
    }
    const ruleId = TYPE_TO_RULE_ID[f.type];
    return ruleId ? isRuleEnabled(ruleId) : true;
  });

  if (findings.length > 0) {
    setBlocked(el, findings);
  } else {
    setClean(el);
  }
}

function scheduleScan(el: Element, delayMs = 300): void {
  const state = getOrCreateState(el);
  if (state.debounceTimer !== null) clearTimeout(state.debounceTimer);
  if (getTextValue(el).trim().length > 0 && state.status !== "acknowledged") {
    renderPanel(el, state, "scanning");
  }
  state.debounceTimer = setTimeout(() => {
    state.debounceTimer = null;
    runScan(el);
  }, delayMs);
}



/**
 * Returns true when `el` (or its closest ancestor) is inside a GitHub
 * comment form, PR description, issue editor, or web editor.
 */
function isInTargetContext(el: Element): boolean {
  return !!el.closest(
    ".js-write-bucket, .comment-form-wrapper, form, " +
    ".CodeMirror, .monaco-editor, " +
    '[data-target="code-editor.body"]'
  );
}

// ── Event delegation ──────────────────────────────────────────────────────────

let _initialised = false;

export function initSecretWatcher(): void {
  if (_initialised) return;
  _initialised = true;

  // Delegated input listener
  document.addEventListener(
    "input",
    (e) => {
      const el = e.target as Element;
      if (!isEditableField(el)) return;
      if (!isInTargetContext(el)) return;
      scheduleScan(el);
    },
    { passive: true, capture: true }
  );

  // Delegated paste listener (value not yet updated → defer)
  document.addEventListener(
    "paste",
    (e) => {
      const el = e.target as Element;
      if (!isEditableField(el)) return;
      if (!isInTargetContext(el)) return;
      // Paste fires before the value is updated; add a short delay
      scheduleScan(el, 50);
    },
    { passive: true, capture: true }
  );
}
