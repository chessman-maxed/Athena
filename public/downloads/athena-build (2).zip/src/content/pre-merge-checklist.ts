/**
 * Athena – Pre-Merge Checklist & Warning Interceptor.
 *
 * Responsibilities:
 *  1. Inspects the GitHub PR DOM to read:
 *     - CI / Checks status (passing, failing, pending)
 *     - Review approval status (approved, changes requested, no approval)
 *     - Merge conflict status (clean, conflicts, out-of-date)
 *  2. Displays an inline Shadow DOM "Pre-Merge Checklist" panel above the merge box.
 *  3. Intercepts the Merge button click if CI checks are failing/pending,
 *     review approvals are missing/rejected, or conflicts exist.
 *  4. Shows a prominent warning interstitial banner allowing explicit bypass or cancellation.
 */

import {
  isRuleEnabled,
  isWarningDismissedSync,
  dismissWarning,
  logConfirmedAction,
  logActivity,
  getRepoPolicySync,
  type RepoPolicy,
} from "../storage/session";
import { primerTokenStyles } from "../ui/tokens";
import { createOcticon } from "../ui/icons";
import { announceAthenaWarning, fadeOutAthenaHost } from "../ui/motion";

// ── Types ─────────────────────────────────────────────────────────────────────

export type CIStatus = "passing" | "failing" | "pending" | "unknown";
export type ReviewStatus = "approved" | "changes-requested" | "no-approval" | "unknown";
export type ConflictStatus = "clean" | "conflicts" | "out-of-date" | "unknown";

export interface PRHealth {
  ci: CIStatus;
  review: ReviewStatus;
  conflict: ConflictStatus;
}

// ── DOM Reading Logic ─────────────────────────────────────────────────────────

export function getCIStatus(doc: Document = document): CIStatus {
  const items = doc.querySelectorAll(".merge-status-item, [data-check-state], .branch-action-item");
  const fullText = Array.from(items)
    .map((el) => el.textContent ?? "")
    .join(" ")
    .toLowerCase();

  // Failing checks
  if (
    fullText.includes("checks failed") ||
    fullText.includes("check failed") ||
    fullText.includes("failing check") ||
    doc.querySelector('.merge-status-item [data-check-state="FAILURE"], .merge-status-item [data-check-state="ERROR"]') ||
    doc.querySelector('.merge-status-item svg.color-fg-danger, .merge-status-item .color-fg-danger')
  ) {
    return "failing";
  }

  // Pending checks
  if (
    fullText.includes("checks in progress") ||
    fullText.includes("checks pending") ||
    fullText.includes("expected — waiting for status") ||
    doc.querySelector('.merge-status-item [data-check-state="PENDING"], .merge-status-item [data-check-state="IN_PROGRESS"]') ||
    doc.querySelector('.merge-status-item svg.anim-rotate, .merge-status-item .color-fg-attention')
  ) {
    return "pending";
  }

  // Passing checks
  if (
    fullText.includes("all checks have passed") ||
    fullText.includes("checks passed") ||
    doc.querySelector('.merge-status-item [data-check-state="SUCCESS"]') ||
    doc.querySelector('.merge-status-item svg.color-fg-success, .merge-status-item .color-fg-success')
  ) {
    return "passing";
  }

  return "unknown";
}

export function getReviewStatus(doc: Document = document): ReviewStatus {
  // Inspect sidebar & merge box review areas
  const items = doc.querySelectorAll(".js-issue-sidebar, .discussion-sidebar-item, .reviewers-status, .branch-action-item, .merge-status-list");
  const combinedText = (Array.from(items).map((el) => el.textContent ?? "").join(" ") + " " + (doc.body?.textContent ?? "")).toLowerCase();

  if (
    combinedText.includes("changes requested") ||
    doc.querySelector('.discussion-sidebar-item .color-fg-danger, [aria-label*="changes requested"]')
  ) {
    return "changes-requested";
  }

  if (
    combinedText.includes("review approved") ||
    combinedText.includes("approved these changes") ||
    combinedText.includes("1 approving review") ||
    combinedText.includes("2 approving reviews") ||
    doc.querySelector('.discussion-sidebar-item .color-fg-success, .reviewers-status .color-fg-success')
  ) {
    return "approved";
  }

  if (
    combinedText.includes("review required") ||
    combinedText.includes("at least 1 approving review is required") ||
    combinedText.includes("no reviews")
  ) {
    return "no-approval";
  }

  return "unknown";
}

export function getConflictStatus(doc: Document = document): ConflictStatus {
  const mergeStatus = doc.querySelector(".branch-action-item, .merge-status-list, #partial-pull-merging");
  const text = (mergeStatus?.textContent ?? doc.body?.textContent ?? "").toLowerCase();

  if (
    text.includes("this branch has no conflicts") ||
    text.includes("no conflicts") ||
    text.includes("changes will be merged")
  ) {
    return "clean";
  }

  if (
    text.includes("conflicts with the base branch") ||
    text.includes("merge conflicts") ||
    text.includes("cannot be merged automatically") ||
    doc.querySelector(".gh-header-meta .State--red")
  ) {
    return "conflicts";
  }

  if (text.includes("out-of-date") || text.includes("out of date")) {
    return "out-of-date";
  }

  if (doc.querySelector(".branch-action-item .color-fg-success")) {
    return "clean";
  }

  return "unknown";
}

export function evaluatePRHealth(doc: Document = document): PRHealth {
  return {
    ci: getCIStatus(doc),
    review: getReviewStatus(doc),
    conflict: getConflictStatus(doc),
  };
}

// ── Checklist Panel Shadow DOM ────────────────────────────────────────────────

const CHECKLIST_CSS = `
  :host {
    display: block;
    margin-bottom: 12px;
  }

  .chk-card {
    background: var(--bg-canvas);
    border: 1.5px solid var(--border);
    border-radius: 8px;
    padding: 12px 16px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
    color: var(--fg-muted);
    box-shadow: 0 4px 12px var(--bg-inset);
  }

  .chk-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    margin-bottom: 10px;
    border-bottom: 1px solid var(--border-muted);
    padding-bottom: 8px;
  }

  .chk-title-wrap {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .chk-icon { display: inline-flex; width: 18px; height: 18px; }
  .chk-icon svg { width: 100%; height: 100%; }

  .chk-title {
    font-size: 13px;
    font-weight: 700;
    color: var(--fg);
    letter-spacing: -0.01em;
  }

  .chk-badge {
    font-size: 9px;
    font-weight: 700;
    padding: 2px 7px;
    border-radius: 999px;
    background: var(--accent);
    color: var(--fg);
    letter-spacing: 0.06em;
    text-transform: uppercase;
  }

  .chk-dismiss-btn {
    background: transparent;
    border: none;
    color: var(--fg-subtle);
    font-size: 16px;
    cursor: pointer;
    line-height: 1;
    padding: 2px 4px;
    border-radius: 4px;
  }

  .chk-dismiss-btn:hover { color: var(--fg); background: var(--border-muted); }

  .chk-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 8px;
  }

  .chk-item {
    background: var(--bg-subtle);
    border: 1px solid var(--border-muted);
    border-radius: 6px;
    padding: 8px 10px;
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  .chk-item-label {
    font-size: 10px;
    font-weight: 700;
    color: var(--fg-muted);
    text-transform: uppercase;
    letter-spacing: 0.06em;
  }

  .chk-item-value {
    font-size: 11px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 5px;
  }

  .status-pass, .status-warn, .status-fail, .status-info { display: inline-flex; align-items: center; gap: 4px; }
  .status-pass { color: var(--success); }
  .status-warn { color: var(--attention); }
  .status-fail { color: var(--danger); }
  .status-info { color: var(--accent); }
  .status-pass svg, .status-warn svg, .status-fail svg, .status-info svg { width: 14px; height: 14px; }
`;

function createChecklistPanelHost(
  health: PRHealth,
  onDismiss: () => void
): HTMLDivElement {
  const host = document.createElement("div");
  host.dataset.athenaChecklistPanel = "1";
  host.dataset.athenaThemeHost = "";

  const shadow = host.attachShadow({ mode: "open" });

  const style = document.createElement("style");
  style.textContent = `${primerTokenStyles}\n${CHECKLIST_CSS}`;
  shadow.appendChild(style);

  const card = document.createElement("div");
  card.className = "chk-card";

  const header = document.createElement("div");
  header.className = "chk-header";

  const titleWrap = document.createElement("div");
  titleWrap.className = "chk-title-wrap";

  const icon = document.createElement("span");
  icon.className = "chk-icon";
  icon.appendChild(createOcticon("check", 18));

  const title = document.createElement("span");
  title.className = "chk-title";
  title.textContent = "Pre-Merge Checklist";

  const badge = document.createElement("span");
  badge.className = "chk-badge";
  badge.textContent = "ATHENA";

  titleWrap.appendChild(icon);
  titleWrap.appendChild(title);
  titleWrap.appendChild(badge);

  const dismissBtn = document.createElement("button");
  dismissBtn.className = "chk-dismiss-btn";
  dismissBtn.textContent = "✕";
  dismissBtn.setAttribute("aria-label", "Dismiss checklist");
  dismissBtn.addEventListener("click", () => fadeOutAthenaHost(host, onDismiss));

  header.appendChild(titleWrap);
  header.appendChild(dismissBtn);
  card.appendChild(header);

  const grid = document.createElement("div");
  grid.className = "chk-grid";

  // CI Item
  const ciItem = document.createElement("div");
  ciItem.className = "chk-item";
  const ciLabel = document.createElement("div");
  ciLabel.className = "chk-item-label";
  ciLabel.textContent = "CI Checks";

  const ciVal = document.createElement("div");
  ciVal.className = "chk-item-value";
  if (health.ci === "passing") {
    ciVal.innerHTML = `<span class="status-pass">${createOcticon("check", 14).outerHTML} Passed</span>`;
  } else if (health.ci === "failing") {
    ciVal.innerHTML = `<span class="status-fail">${createOcticon("cancel", 14).outerHTML} Failing</span>`;
  } else if (health.ci === "pending") {
    ciVal.innerHTML = `<span class="status-warn">${createOcticon("warning", 14).outerHTML} In Progress</span>`;
  } else {
    ciVal.innerHTML = `<span class="status-info">${createOcticon("info", 14).outerHTML} Unknown</span>`;
  }
  ciItem.appendChild(ciLabel);
  ciItem.appendChild(ciVal);

  // Review Item
  const revItem = document.createElement("div");
  revItem.className = "chk-item";
  const revLabel = document.createElement("div");
  revLabel.className = "chk-item-label";
  revLabel.textContent = "Review Status";

  const revVal = document.createElement("div");
  revVal.className = "chk-item-value";
  if (health.review === "approved") {
    revVal.innerHTML = `<span class="status-pass">${createOcticon("check", 14).outerHTML} Approved</span>`;
  } else if (health.review === "changes-requested") {
    revVal.innerHTML = `<span class="status-fail">${createOcticon("cancel", 14).outerHTML} Changes Requested</span>`;
  } else if (health.review === "no-approval") {
    revVal.innerHTML = `<span class="status-warn">${createOcticon("warning", 14).outerHTML} No Approval</span>`;
  } else {
    revVal.innerHTML = `<span class="status-info">${createOcticon("info", 14).outerHTML} Unknown</span>`;
  }
  revItem.appendChild(revLabel);
  revItem.appendChild(revVal);

  // Conflict Item
  const cflItem = document.createElement("div");
  cflItem.className = "chk-item";
  const cflLabel = document.createElement("div");
  cflLabel.className = "chk-item-label";
  cflLabel.textContent = "Merge Conflicts";

  const cflVal = document.createElement("div");
  cflVal.className = "chk-item-value";
  if (health.conflict === "clean") {
    cflVal.innerHTML = `<span class="status-pass">${createOcticon("check", 14).outerHTML} No Conflicts</span>`;
  } else if (health.conflict === "conflicts") {
    cflVal.innerHTML = `<span class="status-fail">${createOcticon("alert", 14).outerHTML} Conflicts</span>`;
  } else if (health.conflict === "out-of-date") {
    cflVal.innerHTML = `<span class="status-warn">${createOcticon("branch", 14).outerHTML} Out of Date</span>`;
  } else {
    cflVal.innerHTML = `<span class="status-info">${createOcticon("info", 14).outerHTML} Unknown</span>`;
  }
  cflItem.appendChild(cflLabel);
  cflItem.appendChild(cflVal);

  grid.appendChild(ciItem);
  grid.appendChild(revItem);
  grid.appendChild(cflItem);

  card.appendChild(grid);
  shadow.appendChild(card);

  return host;
}

// ── Warning Interstitial Banner ───────────────────────────────────────────────

const INTERSTITIAL_CSS = `
  :host { display: block; position: relative; z-index: 10000; margin-bottom: 8px; }
  .warn-banner {
    background: rgba(10, 10, 10, .92);
    border: 1px solid rgba(239, 68, 68, .4);
    border-left: 3px solid #ef4444;
    border-radius: 8px;
    padding: 10px 12px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
    color: #fff;
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
  }
  .warn-title { display:flex; align-items:center; gap:7px; font:700 10px/1.3 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; letter-spacing:.09em; color:#f87171; margin-bottom:5px; }
  .warn-reason-label { color:#737373; font:600 8px/1 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; letter-spacing:.1em; text-transform:uppercase; }
  .warn-reason { color:#d4d4d4; font-size:11px; line-height:1.4; margin:4px 0 8px; }
  .warn-reasons { font-size:10px; line-height:1.4; color:#a3a3a3; margin:0 0 8px; padding-left:16px; }
  .warn-actions { display: flex; align-items:center; flex-wrap:wrap; gap:6px; }
  .btn-merge-anyway {
    background:rgba(239,68,68,.16); color:#f87171; border:1px solid rgba(239,68,68,.4); padding:5px 9px;
    border-radius:5px; font:600 9px/1.2 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; letter-spacing:.04em; cursor:pointer;
    transition: background 180ms ease, border-color 180ms ease, box-shadow 180ms ease, transform 180ms ease;
  }
  .btn-merge-anyway:hover { background:rgba(239,68,68,.25); }
  .btn-review-risk {
    background:rgba(0,240,255,.08); color:#67e8f9; border:1px solid rgba(0,240,255,.25); padding:5px 9px;
    border-radius:5px; font:600 9px/1.2 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; letter-spacing:.04em; cursor:pointer;
    transition: background 180ms ease, border-color 180ms ease, box-shadow 180ms ease, transform 180ms ease;
  }
  .btn-review-risk:hover { background:rgba(0,240,255,.14); }
  .btn-cancel {
    background:transparent; color:#a3a3a3; border:1px solid rgba(255,255,255,.1); padding:5px 9px;
    border-radius:5px; font:500 9px/1.2 system-ui,sans-serif; cursor:pointer;
    transition: background 180ms ease, border-color 180ms ease, color 180ms ease;
  }
  .btn-cancel:hover { background:rgba(255,255,255,.05); color:#fff; }
`;

function createWarningBannerHost(
  reasons: string[],
  onProceed: () => void,
  onCancel: () => void,
  onReviewRisk: () => void
): HTMLDivElement {
  const host = document.createElement("div");
  host.dataset.athenaThemeHost = "";
  host.dataset.athenaMergeWarning = "1";

  const shadow = host.attachShadow({ mode: "open" });

  const style = document.createElement("style");
  style.textContent = `${primerTokenStyles}\n${INTERSTITIAL_CSS}`;
  shadow.appendChild(style);

  const banner = document.createElement("div");
  banner.className = "warn-banner";

  const title = document.createElement("div");
  title.className = "warn-title";
  title.appendChild(createOcticon("warning", 16));
  title.appendChild(document.createTextNode("ACTION INTERCEPTED"));

  const reasonLabel = document.createElement("div");
  reasonLabel.className = "warn-reason-label";
  reasonLabel.textContent = "Reason";
  const reason = document.createElement("p");
  reason.className = "warn-reason";
  reason.textContent = reasons.some((item) => /conflict/i.test(item))
    ? "Potential merge conflict detected."
    : reasons[0] || "Potentially unsafe merge conditions detected.";

  const ul = document.createElement("ul");
  ul.className = "warn-reasons";
  for (const detail of reasons) {
    const li = document.createElement("li");
    li.textContent = detail;
    ul.appendChild(li);
  }

  const actions = document.createElement("div");
  actions.className = "warn-actions";

  const proceedBtn = document.createElement("button");
  proceedBtn.type = "button";
  proceedBtn.className = "btn-merge-anyway";
  proceedBtn.textContent = "CONTINUE ANYWAY";
  proceedBtn.addEventListener("click", () => fadeOutAthenaHost(host, onProceed));

  const reviewBtn = document.createElement("button");
  reviewBtn.type = "button";
  reviewBtn.className = "btn-review-risk";
  reviewBtn.textContent = "REVIEW RISK";
  reviewBtn.addEventListener("click", onReviewRisk);

  const cancelBtn = document.createElement("button");
  cancelBtn.type = "button";
  cancelBtn.className = "btn-cancel";
  cancelBtn.textContent = "Cancel";
  cancelBtn.addEventListener("click", () => fadeOutAthenaHost(host, onCancel));

  actions.appendChild(reviewBtn);
  actions.appendChild(proceedBtn);
  actions.appendChild(cancelBtn);

  banner.appendChild(title);
  banner.appendChild(reasonLabel);
  banner.appendChild(reason);
  banner.appendChild(ul);
  banner.appendChild(actions);

  shadow.appendChild(banner);
  announceAthenaWarning();
  return host;
}

// ── Branch & Repo Detection Helpers ──────────────────────────────────────────

export function getBaseBranchName(doc: Document = document): string {
  const baseEl = doc.querySelector(
    ".commit-ref.base-ref .css-truncate-target, " +
    ".gh-header-meta .base-ref .css-truncate-target, " +
    ".commit-ref.base-ref, " +
    ".base-ref"
  );
  return baseEl?.textContent?.trim() ?? "";
}

export function getRepoKeyFromUrl(url: string = (typeof window !== "undefined" ? window.location.href : "")): string {
  const m = url.match(/github\.com\/([^/]+)\/([^/]+)/i);
  if (m) {
    return `${m[1]}/${m[2]}`.toLowerCase();
  }
  return "";
}

export function evaluateUnsafeMergeReasons(
  doc: Document = document,
  url: string = (typeof window !== "undefined" ? window.location.href : ""),
  customPolicy?: RepoPolicy
): string[] {
  const health = evaluatePRHealth(doc);
  const repoKey = getRepoKeyFromUrl(url);
  const policy = customPolicy ?? getRepoPolicySync(repoKey);
  const unsafeReasons: string[] = [];

  // Policy 1: blockMergeToMain
  if (policy.blockMergeToMain) {
    const baseBranch = getBaseBranchName(doc).toLowerCase();
    if (baseBranch === "main" || baseBranch === "master") {
      unsafeReasons.push(`Merging directly to '${baseBranch}' is blocked by repository policy`);
    }
  }

  // Policy 2: requirePassingChecks
  if (policy.requirePassingChecks) {
    if (health.ci !== "passing") {
      unsafeReasons.push(
        `Repository policy requires all CI checks to pass before merging (current status: ${health.ci})`
      );
    }
  }

  // Standard health checks
  if (health.ci === "failing") {
    unsafeReasons.push("CI checks are failing");
  } else if (health.ci === "pending") {
    unsafeReasons.push("CI checks are still in progress");
  }

  if (health.review === "changes-requested") {
    unsafeReasons.push("Changes were requested by a reviewer");
  } else if (health.review === "no-approval") {
    unsafeReasons.push("No approving review has been submitted for this PR");
  }

  if (health.conflict === "conflicts") {
    unsafeReasons.push("This PR has unresolved merge conflicts");
  }

  return Array.from(new Set(unsafeReasons));
}

// ── Merge Button Interceptor ──────────────────────────────────────────────────

const INTERCEPTOR_DONE_ATTR = "data-athena-merge-guarded";

export function attachMergeButtonInterceptor(): void {
  const mergeBtns = document.querySelectorAll<HTMLElement>(
    "button.js-merge-box-button, .btn-group-merge button, button.js-merge-commit, button[data-details-container], .merge-pr-section button"
  );

  for (const btn of mergeBtns) {
    if (btn.getAttribute(INTERCEPTOR_DONE_ATTR) !== null) continue;

    // Check button text to confirm it's a merge button
    const text = (btn.textContent ?? "").toLowerCase();
    if (
      !text.includes("merge") &&
      !text.includes("squash") &&
      !text.includes("rebase")
    ) {
      continue;
    }

    btn.setAttribute(INTERCEPTOR_DONE_ATTR, "1");

    let bypassOnce = false;

    const clickHandler = async (e: Event) => {
      if (bypassOnce) {
        bypassOnce = false;
        return; // Allow native click through
      }

      if (!isRuleEnabled("passive_pre-merge-checklist")) return;

      const unsafeReasons = evaluateUnsafeMergeReasons(document, window.location.href);

      if (unsafeReasons.length > 0) {
        e.preventDefault();
        e.stopImmediatePropagation();

        // Check if warning banner already inserted
        if (document.querySelector("[data-athena-merge-warning]")) return;

        const anchor =
          btn.closest(".merge-message, .merge-pr-section, .discussion-timeline-actions") ??
          btn.parentElement ??
          document.body;

        if (anchor) {
          const repoMatch = window.location.pathname.match(/^\/([^/]+)\/([^/]+)/);
          const repo = repoMatch ? `${repoMatch[1]}/${repoMatch[2]}` : "";
          void logActivity({
            type: "merge-warned",
            ruleId: "passive_pre-merge-checklist",
            label: "Pre-Merge Warning",
            repo,
          });
          const warnHost = createWarningBannerHost(
            unsafeReasons,
            async () => {
              void logActivity({
                type: "proceeded",
                ruleId: "passive_pre-merge-checklist",
                label: "Override Pre-Merge Checklist",
                repo,
              });
              await logConfirmedAction({
                ruleId: "passive_pre-merge-checklist",
                actionType: "Override Pre-Merge Checklist",
                url: window.location.href,
              });
              warnHost.remove();
              bypassOnce = true;
              btn.click();
            },
            () => {
              void logActivity({
                type: "cancelled",
                ruleId: "passive_pre-merge-checklist",
                label: "Merge cancelled",
                repo,
              });
              warnHost.remove();
            },
            () => {
              void logActivity({
                type: "merge-warned",
                ruleId: "passive_pre-merge-checklist",
                label: "Reviewed intercepted merge risk",
                repo,
              });
              const hud = document.querySelector<HTMLElement>("[data-athena-security-hud]");
              if (hud) {
                hud.scrollIntoView({ behavior: "smooth", block: "center" });
                hud.setAttribute("tabindex", "-1");
                hud.focus({ preventScroll: true });
              }
            }
          );
          anchor.insertBefore(warnHost, anchor.firstChild);
        }
      }
    };

    btn.addEventListener("click", clickHandler, true);
  }
}

// ── Main Export ───────────────────────────────────────────────────────────────

const PANEL_DONE_ATTR = "data-athena-checklist-done";

export function runPreMergeChecklist(): void {
  if (!isRuleEnabled("passive_pre-merge-checklist")) return;

  const currentUrl = window.location.href;
  if (!currentUrl.match(/\/pull\/\d+/)) return;

  if (isWarningDismissedSync("passive_pre-merge-checklist", currentUrl)) return;

  // 1. Attach Merge Button Interceptor
  attachMergeButtonInterceptor();

  // 2. Render Checklist Panel
  const anchor = document.querySelector(
    ".discussion-timeline-actions, .merge-pr-section, #partial-pull-merging, #discussion_bucket"
  );
  if (!anchor) return;
  if (anchor.getAttribute(PANEL_DONE_ATTR) !== null) return;
  anchor.setAttribute(PANEL_DONE_ATTR, "1");

  const health = evaluatePRHealth(document);
  const panel = createChecklistPanelHost(health, async () => {
    await dismissWarning("passive_pre-merge-checklist", currentUrl);
    panel.remove();
  });

  anchor.insertBefore(panel, anchor.firstChild);
}
