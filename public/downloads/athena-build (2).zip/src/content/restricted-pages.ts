export function isRestrictedPage(path?: string): boolean {
  const currentPath = path ?? (typeof window !== "undefined" ? window.location.pathname : "");
  return (
    /^\/sessions\/sudo(?:\/|$)/.test(currentPath) ||
    /^\/login(?:\/|$)/.test(currentPath) ||
    /^\/[^/]+\/[^/]+\/settings\/delete(?:\/|$)/.test(currentPath)
  );
}