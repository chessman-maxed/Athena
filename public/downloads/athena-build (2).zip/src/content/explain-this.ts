/**
 * Athena – "Explain this" LLM Feature.
 *
 * Capabilities:
 *  - Sends ONLY the selected diff or log text to an OpenAI-compatible LLM endpoint
 *  - Pure secret guardrail: runs scanText() first and BLOCKS the request if any secret is detected
 *  - First-send privacy notice: ensures user consents before text leaves the browser
 *  - Requires user-provided API key from settings
 *
 * Security note on fetch routing
 * ─────────────────────────────────────────────────────────────────────────────
 * Content scripts share the page's network stack and therefore CANNOT fetch
 * external hosts that are not in the extension's host_permissions.  The
 * extension uses `optional_host_permissions` for LLM endpoints so that the
 * user only grants access to the exact provider they configure.
 *
 * To work around the content-script restriction while keeping the API key
 * out of message payloads (except when using the test-only `customFetch`
 * escape-hatch), the actual HTTP call is dispatched to the background service
 * worker via chrome.runtime.sendMessage({ type: "ATHENA_LLM_REQUEST", … }).
 * The background worker reads the API key from session storage itself and
 * performs the fetch, then replies with the JSON body or an error string.
 *
 * The API key is NEVER logged, NEVER included in error messages, and NEVER
 * sent to any host other than the user-configured base URL.
 */

import { scanText, type Finding } from "../rules/secrets";
import {
  loadSettings,
  hasLLMConsent,
  setLLMConsent,
  normalizeBaseUrl,
  formatLLMErrorResponse,
  type LLMSettings,
} from "../storage/session";

export interface ExplainRequestResult {
  status: "success" | "blocked-secret" | "missing-key" | "needs-consent" | "error";
  explanation?: string;
  findings?: Finding[];
  error?: string;
}

export interface ExplainOptions {
  forceConsent?: boolean;
  customScan?: (text: string) => Finding[];
  customLoadSettings?: () => Promise<LLMSettings>;
  customHasConsent?: () => Promise<boolean>;
  /**
   * Test-only escape hatch. When provided the LLM request is made directly
   * using this function instead of going through the background service worker.
   * NEVER set this in production code paths.
   */
  customFetch?: typeof fetch;
}

// ── Background-routed LLM request ─────────────────────────────────────────────

/**
 * Send the LLM chat-completion request via the background service worker.
 *
 * The background worker holds the API key and makes the actual fetch, so the
 * content script never needs host_permissions for the LLM provider.
 *
 * Returns the explanation string on success.
 * Throws a descriptive Error on failure (status codes, network errors, etc.).
 * The API key is never included in error messages.
 */
async function dispatchLLMRequestViaBackground(
  text: string
): Promise<string> {
  type BgResponse =
    | { ok: true; explanation: string }
    | { ok: false; error: string };

  const response = await new Promise<BgResponse>((resolve, reject) => {
    chrome.runtime.sendMessage(
      { type: "ATHENA_LLM_REQUEST", text },
      (resp: BgResponse | undefined) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message ?? "Background message failed"));
          return;
        }
        if (!resp) {
          reject(new Error("No response received from Athena background worker."));
          return;
        }
        resolve(resp);
      }
    );
  });

  if (!response.ok) {
    throw new Error(response.error);
  }
  return response.explanation;
}

/**
 * Core processor for "Explain this".
 * Validates secrets, API key, consent, and sends ONLY the selected text to LLM.
 */
export async function processExplainRequest(
  selectedText: string,
  options?: ExplainOptions
): Promise<ExplainRequestResult> {
  const text = (selectedText ?? "").trim();
  if (!text) {
    return { status: "error", error: "No text selected to explain." };
  }

  // 1. Security Check: scanText() MUST run first and block if ANY secret is detected
  const scanFn = options?.customScan ?? scanText;
  const findings = scanFn(text);
  if (findings.length > 0) {
    return {
      status: "blocked-secret",
      findings,
      error: `Request blocked: ${findings.length} potential secret(s) detected in selected text.`,
    };
  }

  // 2. Settings Check: If customLoadSettings is explicitly provided (e.g. in unit tests), validate it
  if (options?.customLoadSettings || options?.customFetch) {
    const loadSettingsFn = options?.customLoadSettings ?? loadSettings;
    const settings = await loadSettingsFn();
    if (!settings.apiKey || !settings.apiKey.trim()) {
      return {
        status: "missing-key",
        error: "LLM API key is required. Please set your API key in Athena Settings.",
      };
    }
  }

  // 3. Privacy Notice: First-send consent check
  if (!options?.forceConsent) {
    const hasConsentFn = options?.customHasConsent ?? hasLLMConsent;
    const hasConsent = await hasConsentFn();
    if (!hasConsent) {
      return {
        status: "needs-consent",
      };
    }
  }

  // 4. Request Dispatch
  try {
    if (options?.customFetch) {
      // ── Test-only path: call the provided fetch mock directly ────────────
      const loadSettingsFn = options?.customLoadSettings ?? loadSettings;
      const settings = await loadSettingsFn();
      const rawBase = settings.baseUrl ? normalizeBaseUrl(settings.baseUrl) : "https://api.openai.com/v1";
      const endpoint = `${rawBase}/chat/completions`;

      const res = await options.customFetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${settings.apiKey.trim()}`,
        },
        body: JSON.stringify({
          model: settings.model?.trim() || "gpt-4o-mini",
          messages: [
            {
              role: "system",
              content:
                "You are an expert developer and code reviewer. Explain the selected git diff, commit changes, or error log snippet in clear, plain English. Highlight key changes, potential side-effects or risks, and what caused any errors.",
            },
            {
              role: "user",
              content: text,
            },
          ],
          max_tokens: 600,
          temperature: 0.2,
        }),
      });

      if (!res.ok) {
        return {
          status: "error",
          error: formatLLMErrorResponse(res.status),
        };
      }

      let rawText = "";
      if (typeof res.text === "function") {
        rawText = await res.text().catch(() => "");
        if (rawText.trim().startsWith("<")) {
          return {
            status: "error",
            error: formatLLMErrorResponse(res.status),
          };
        }
      }

      let data: { choices?: Array<{ message?: { content?: string } }> };
      if (rawText) {
        try {
          data = JSON.parse(rawText);
        } catch {
          if (typeof res.json === "function") {
            data = (await res.json()) as typeof data;
          } else {
            return { status: "error", error: "LLM returned an invalid response." };
          }
        }
      } else if (typeof res.json === "function") {
        data = (await res.json()) as typeof data;
      } else {
        return { status: "error", error: "LLM returned an empty explanation." };
      }

      const explanation = data.choices?.[0]?.message?.content?.trim();
      if (!explanation) {
        return { status: "error", error: "LLM returned an empty explanation." };
      }

      return { status: "success", explanation };
    }

    // ── Production path: route through background service worker ───────────
    // The background worker reads settings + API key from trusted storage itself;
    // we only send the (already secret-scanned, consented) text.
    const explanation = await dispatchLLMRequestViaBackground(text);
    return { status: "success", explanation };

  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.toLowerCase().includes("not configured") || msg.toLowerCase().includes("api key is required")) {
      return {
        status: "missing-key",
        error: "LLM API key is required. Please set your API key in Athena Settings.",
      };
    }
    if (msg.toLowerCase().includes("permission")) {
      return {
        status: "error",
        error:
          "Permission denied: Athena does not have access to your LLM endpoint yet. " +
          "Open Athena Settings in the extension popup, re-save your endpoint URL, and grant access when prompted.",
      };
    }
    if (msg.trim().startsWith("<")) {
      return {
        status: "error",
        error: "LLM endpoint returned a web page. Check that the Base URL is correct, e.g. https://openrouter.ai/api/v1",
      };
    }
    return {
      status: "error",
      error: msg,
    };
  }
}

export { setLLMConsent };
