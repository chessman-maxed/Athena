/**
 * Athena – Shadow DOM host + React root.
 *
 * Architecture
 * ────────────
 * One <div id="athena-react-host"> is appended to document.body and never
 * removed.  `data-turbo-permanent` tells Turbo Drive to preserve the element
 * across navigations so the React root stays alive without re-mounting.
 *
 * For legacy pjax navigations (which do replace the body children), calling
 * initShadowHost() a second time is safe – the guard re-creates the host and
 * React root while replaying the current banner list.
 *
 * Banner API (used by other modules)
 * ───────────────────────────────────
 *   addBanner(banner)   – show a banner (deduped by id)
 *   removeBanner(id)    – remove by id
 *   clearBanners()      – remove all
 *   initShadowHost()    – call once on content-script init; idempotent
 */

import { createRoot, type Root } from "react-dom/client";
import { useState, useEffect, useCallback, useRef } from "react";
import { WarningBanner, type BannerProps } from "./WarningBanner";
import { isRestrictedPage } from "./restricted-pages";
import { SettingsPanel } from "./SettingsPanel";
import { ExplainModal } from "./ExplainModal";
import { getRepoKeyFromUrl } from "./pre-merge-checklist";
// Tailwind CSS processed to a plain string; injected into the shadow root.
import shadowStyles from "./shadow-ui.css?inline";
import { primerTokenStyles } from "../ui/tokens";

// ── Banner state (module-level, survives React re-mounts) ────────────────────

export interface Banner {
  id: string;
  severity: BannerProps["severity"];
  title: string;
  message: string;
  /** Optional action buttons forwarded to WarningBanner's `actions` prop. */
  actions?: BannerProps["actions"];
}

let _banners: Banner[] = [];
let _isSettingsOpen = false;
let _settingsRepoKey = "";
let _isExplainOpen = false;
let _explainSelectedText = "";
const _stateListeners = new Set<() => void>();

function _notify(): void {
  _stateListeners.forEach((fn) => fn());
}

/** Add a banner.  No-op if a banner with the same id is already visible. */
export function addBanner(banner: Banner): void {
  if (_banners.find((b) => b.id === banner.id)) return;
  _banners = [..._banners, banner];
  _notify();
}

/** Remove the banner with this id. */
export function removeBanner(id: string): void {
  _banners = _banners.filter((b) => b.id !== id);
  _notify();
}

/** Remove all banners. */
export function clearBanners(): void {
  if (_banners.length === 0) return;
  _banners = [];
  _notify();
}

/** Open the Shadow DOM rules & policy settings panel. */
export function openSettingsPanel(repoKey?: string): void {
  _isSettingsOpen = true;
  _settingsRepoKey = repoKey || (typeof window !== "undefined" ? getRepoKeyFromUrl(window.location.href) : "");
  _notify();
}

/** Close the Shadow DOM rules & policy settings panel. */
export function closeSettingsPanel(): void {
  _isSettingsOpen = false;
  _notify();
}

/** Open the "Explain this" modal for the given text. */
export function openExplainModal(text: string): void {
  if (!text || !text.trim()) return;
  _explainSelectedText = text;
  _isExplainOpen = true;
  _notify();
}

/** Close the "Explain this" modal. */
export function closeExplainModal(): void {
  _isExplainOpen = false;
  _notify();
}

// ── Root React component ─────────────────────────────────────────────────────

function AthenaUI() {
  const [banners, setBanners] = useState<Banner[]>(_banners);
  const [isSettingsOpen, setIsSettingsOpen] = useState(_isSettingsOpen);
  const [settingsRepoKey, setSettingsRepoKey] = useState(_settingsRepoKey);
  const [isExplainOpen, setIsExplainOpen] = useState(_isExplainOpen);
  const [explainText, setExplainText] = useState(_explainSelectedText);

  // Floating selection prompt state
  const [floatingSelection, setFloatingSelection] = useState<{
    text: string;
    x: number;
    y: number;
  } | null>(null);
  const policyWrapRef = useRef<HTMLDivElement>(null);
  const policyWasDragged = useRef(false);

  useEffect(() => {
    const element = policyWrapRef.current;
    if (!element) return;

    const constrain = (x: number, y: number) => ({
      x: Math.min(Math.max(0, window.innerWidth - element.offsetWidth), Math.max(0, x)),
      y: Math.min(Math.max(0, window.innerHeight - element.offsetHeight), Math.max(0, y)),
    });
    const applyPosition = (x: number, y: number) => {
      const p = constrain(x, y);
      element.style.left = `${p.x}px`;
      element.style.top = `${p.y}px`;
      element.style.right = "auto";
      element.style.bottom = "auto";
      return p;
    };

    chrome.storage.local.get("athena-policy-position", (values) => {
      const saved = values["athena-policy-position"] as { x?: unknown; y?: unknown } | undefined;
      if (typeof saved?.x === "number" && typeof saved.y === "number") applyPosition(saved.x, saved.y);
    });

    let drag: { pointerId: number; startX: number; startY: number; originX: number; originY: number; moved: boolean; captureTarget: Element } | null = null;
    const onPointerDown = (event: PointerEvent) => {
      if (event.button !== 0) return;
      const rect = element.getBoundingClientRect();
      const captureTarget = event.target instanceof Element ? event.target : element;
      drag = { pointerId: event.pointerId, startX: event.clientX, startY: event.clientY, originX: rect.left, originY: rect.top, moved: false, captureTarget };
      captureTarget.setPointerCapture(event.pointerId);
    };
    const onPointerMove = (event: PointerEvent) => {
      if (!drag || event.pointerId !== drag.pointerId) return;
      const dx = event.clientX - drag.startX;
      const dy = event.clientY - drag.startY;
      if (Math.abs(dx) + Math.abs(dy) > 3) drag.moved = true;
      if (!drag.moved) return;
      event.preventDefault();
      element.style.transition = "none";
      applyPosition(drag.originX + dx, drag.originY + dy);
    };
    const onPointerUp = (event: PointerEvent) => {
      if (!drag || event.pointerId !== drag.pointerId) return;
      const completed = drag;
      drag = null;
      element.style.transition = "";
      if (completed.moved) {
        policyWasDragged.current = true;
        const rect = element.getBoundingClientRect();
        chrome.storage.local.set({ "athena-policy-position": { x: rect.left, y: rect.top } });
        window.setTimeout(() => { policyWasDragged.current = false; }, 0);
      }
      if (completed.captureTarget.hasPointerCapture(event.pointerId)) completed.captureTarget.releasePointerCapture(event.pointerId);
    };

    element.addEventListener("pointerdown", onPointerDown);
    element.addEventListener("pointermove", onPointerMove);
    element.addEventListener("pointerup", onPointerUp);
    element.addEventListener("pointercancel", onPointerUp);
    return () => {
      element.removeEventListener("pointerdown", onPointerDown);
      element.removeEventListener("pointermove", onPointerMove);
      element.removeEventListener("pointerup", onPointerUp);
      element.removeEventListener("pointercancel", onPointerUp);
    };
  }, []);

  // Subscribe to external state changes
  useEffect(() => {
    const handler = () => {
      setBanners([..._banners]);
      setIsSettingsOpen(_isSettingsOpen);
      setSettingsRepoKey(_settingsRepoKey);
      setIsExplainOpen(_isExplainOpen);
      setExplainText(_explainSelectedText);
    };
    _stateListeners.add(handler);
    return () => {
      _stateListeners.delete(handler);
    };
  }, []);

  // Selection detection for "Explain this"
  useEffect(() => {
    const handleMouseUp = (e: MouseEvent) => {
      const selection = window.getSelection();
      const text = selection?.toString()?.trim() ?? "";

      if (text.length >= 5) {
        // Position near mouse coordinates
        const x = Math.min(window.innerWidth - 130, Math.max(10, e.clientX));
        const y = Math.max(10, e.clientY - 42);
        setFloatingSelection({ text, x, y });
      } else {
        setFloatingSelection(null);
      }
    };

    document.addEventListener("mouseup", handleMouseUp);
    return () => {
      document.removeEventListener("mouseup", handleMouseUp);
    };
  }, []);

  const dismiss = useCallback((id: string) => removeBanner(id), []);

  const detectedRepoKey = typeof window !== "undefined" ? getRepoKeyFromUrl(window.location.href) : "";

  return (
    <>
      {/* Floating Selection Explain this Button */}
      {floatingSelection && !isExplainOpen && (
        <div
          style={{
            position: "fixed",
            left: `${floatingSelection.x}px`,
            top: `${floatingSelection.y}px`,
            zIndex: 2147483645,
            pointerEvents: "auto",
          }}
        >
          <button
            type="button"
            onClick={() => {
              openExplainModal(floatingSelection.text);
              setFloatingSelection(null);
            }}
            style={{
              background: "var(--bg-subtle)",
              color: "var(--fg)",
              border: "1px solid var(--border-soft)",
              borderRadius: "999px",
              padding: "5px 13px",
              fontSize: "11.5px",
              fontWeight: 600,
              letterSpacing: "0.01em",
              cursor: "pointer",
              boxShadow: "0 6px 20px var(--border-soft), 0 0 1px var(--border-soft) inset",
              display: "flex",
              alignItems: "center",
              gap: "5px",
              whiteSpace: "nowrap",
            }}
          >
            <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="14" height="14"><path d="m12 3 1.6 6.4L20 11l-6.4 1.6L12 19l-1.6-6.4L4 11l6.4-1.6z M19 3v4m-2-2h4" /></svg>
            <span>Explain this</span>
          </button>
        </div>
      )}

      {/* Floating Banners Stack */}
      {banners.length > 0 && (
        <div
          style={{
            position: "fixed",
            top: 16,
            right: 16,
            zIndex: 2147483646,
            display: "flex",
            flexDirection: "column",
            gap: 10,
            pointerEvents: "none",
          }}
        >
          {banners.map((b) => (
            <WarningBanner
              key={b.id}
              severity={b.severity}
              title={b.title}
              message={b.message}
              onDismiss={() => dismiss(b.id)}
              actions={b.actions}
            />
          ))}
        </div>
      )}

      {/* Floating Athena Policy Settings Trigger */}
      <div
        ref={policyWrapRef}
        style={{
          position: "fixed",
          bottom: 16,
          right: 76,
          zIndex: 2147483640,
          pointerEvents: "auto",
        }}
      >
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            if (policyWasDragged.current) {
              policyWasDragged.current = false;
              return;
            }
            openSettingsPanel(detectedRepoKey);
          }}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "6px",
            background: "var(--bg-subtle)",
            border: "1px solid var(--border-soft)",
            color: "var(--fg)",
            padding: "6px 12px",
            borderRadius: "999px",
            fontSize: "11px",
            fontWeight: 600,
            cursor: "grab",
            touchAction: "none",
            boxShadow: "0 4px 14px var(--bg-inset)",
            backdropFilter: "blur(8px)",
            WebkitBackdropFilter: "blur(8px)",
          }}
          title="Drag to move • Athena Rules & Policy Settings"
        >
          <img
            src={chrome.runtime.getURL("icons/athena-32.png")}
            alt=""
            aria-hidden="true"
            width="16"
            height="16"
            style={{ objectFit: "contain" }}
          />
          <span>Athena Policies</span>
        </button>
      </div>

      {/* In-DOM Policy Settings Modal */}
      {isSettingsOpen && (
        <SettingsPanel
          isOpen={isSettingsOpen}
          initialRepoKey={settingsRepoKey || detectedRepoKey}
          onClose={closeSettingsPanel}
        />
      )}

      {/* In-DOM "Explain this" Modal */}
      <ExplainModal
        isOpen={isExplainOpen}
        selectedText={explainText}
        onClose={closeExplainModal}
        onOpenSettings={() => openSettingsPanel(detectedRepoKey)}
      />
    </>
  );
}

// ── Host lifecycle ────────────────────────────────────────────────────────────

const HOST_ID = "athena-react-host";
let _root: Root | null = null;
let _host: HTMLDivElement | null = null;
let _mount: HTMLDivElement | null = null;

function unmountRoot(): void {
  if (_root) {
    try {
      _root.unmount();
    } catch {
      // A detached host may already have been cleaned up by the page.
    }
  }
  _root = null;
  _host = null;
  _mount = null;
}

/**
 * Ensure the Shadow DOM host exists and React is mounted inside it.
 * Guarantees that only ONE #athena-react-host element exists.
 * Any existing #athena-react-host is removed before mounting.
 *
 * Must be called after document.body is available.
 */
export function initShadowHost(): void {
  if (typeof document === "undefined" || !document.body) {
    return;
  }

  const existingHosts = [...document.querySelectorAll<HTMLDivElement>(`#${HOST_ID}`)];
  if (isRestrictedPage()) {
    unmountRoot();
    existingHosts.forEach((hostEl) => hostEl.remove());
    return;
  }

  // Keep a valid React root across GitHub SPA transitions. Remove only stray
  // duplicate hosts and refresh the component so it reads the new repo route.
  if (_root && _host?.isConnected && _mount?.isConnected && existingHosts.includes(_host)) {
    existingHosts.filter((hostEl) => hostEl !== _host).forEach((hostEl) => hostEl.remove());
    _root.render(<AthenaUI />);
    return;
  }

  unmountRoot();
  existingHosts.forEach((hostEl) => hostEl.remove());
  if (!document.body) return;

  // ── Create host element ────────────────────────────────────────────────
  const host = document.createElement("div");
  _host = host;
  host.id = HOST_ID;
  host.setAttribute("data-athena-theme-host", "");
  // Turbo Drive: preserve this element across SPA navigations
  host.setAttribute("data-turbo-permanent", "");
  // The host itself is zero-size; actual UI lives in the shadow root
  Object.assign(host.style, {
    position: "fixed",
    top: "0",
    left: "0",
    width: "0",
    height: "0",
    overflow: "visible",
    pointerEvents: "none",
    zIndex: "2147483647",
  });
  document.body.appendChild(host);

  // ── Attach Shadow DOM ──────────────────────────────────────────────────
  const shadow = host.attachShadow({ mode: "open" });

  // Inject Tailwind utilities (processed CSS string from the ?inline import)
  const styleEl = document.createElement("style");
  styleEl.textContent = `${primerTokenStyles}\n${shadowStyles}`;
  shadow.appendChild(styleEl);

  // Mount point for React
  const mount = document.createElement("div");
  mount.id = "athena-mount";
  shadow.appendChild(mount);
  _mount = mount;

  // ── Mount React ────────────────────────────────────────────────────────
  _root = createRoot(mount);
  _root.render(<AthenaUI />);
}
