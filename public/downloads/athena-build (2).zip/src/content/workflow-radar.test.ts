/**
 * Unit tests for src/content/workflow-radar.ts
 *
 * Tests:
 *  - Glob to regex conversion & GitHub Actions path pattern matching
 *  - Workflow YAML parsing (name, deploy keyword detection, triggers, paths, paths-ignore)
 *  - Deployment configuration file detection
 *  - Impact analysis logic (matching PR changed files to workflows)
 */

import { describe, it, expect } from "vitest";
import {
  matchesPathPattern,
  parseWorkflowYaml,
  isDeploymentConfigFile,
  analyzeImpact,
  type WorkflowInfo,
} from "./workflow-radar";

describe("Workflow Radar Path Matching", () => {
  it("matches root glob patterns (*.js)", () => {
    expect(matchesPathPattern("index.js", "*.js")).toBe(true);
    expect(matchesPathPattern("src/index.js", "*.js")).toBe(true);
    expect(matchesPathPattern("index.ts", "*.js")).toBe(false);
  });

  it("matches recursive directory globs (src/**)", () => {
    expect(matchesPathPattern("src/components/Button.tsx", "src/**")).toBe(true);
    expect(matchesPathPattern("src/index.ts", "src/**")).toBe(true);
    expect(matchesPathPattern("docs/readme.md", "src/**")).toBe(false);
  });

  it("matches exact paths", () => {
    expect(matchesPathPattern("package.json", "package.json")).toBe(true);
    expect(matchesPathPattern("package-lock.json", "package.json")).toBe(false);
  });
});

describe("Workflow YAML Parsing", () => {
  it("parses workflow name, pull_request trigger, and paths", () => {
    const yaml = `
name: CI Checks
on:
  pull_request:
    paths:
      - 'src/**'
      - 'package.json'
    paths-ignore:
      - '**.md'
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - run: npm test
`;
    const parsed = parseWorkflowYaml("ci.yml", yaml);
    expect(parsed.name).toBe("CI Checks");
    expect(parsed.filename).toBe("ci.yml");
    expect(parsed.triggersPr).toBe(true);
    expect(parsed.paths).toEqual(["src/**", "package.json"]);
    expect(parsed.pathsIgnore).toEqual(["**.md"]);
    expect(parsed.isDeploy).toBe(false);
  });

  it("detects deployment keywords in workflow name or steps", () => {
    const yaml = `
name: Production Deployment
on:
  push:
    branches: [main]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - run: ./deploy.sh
`;
    const parsed = parseWorkflowYaml("deploy.yml", yaml);
    expect(parsed.name).toBe("Production Deployment");
    expect(parsed.isDeploy).toBe(true);
  });
});

describe("Deployment Config File Detection", () => {
  it("identifies Docker, Kubernetes, Terraform, Helm, and GitHub workflow files", () => {
    expect(isDeploymentConfigFile("Dockerfile")).toBe(true);
    expect(isDeploymentConfigFile("Dockerfile.prod")).toBe(true);
    expect(isDeploymentConfigFile("docker-compose.yml")).toBe(true);
    expect(isDeploymentConfigFile(".github/workflows/deploy.yml")).toBe(true);
    expect(isDeploymentConfigFile("terraform/main.tf")).toBe(true);
    expect(isDeploymentConfigFile("helm/chart/values.yaml")).toBe(true);
    expect(isDeploymentConfigFile("k8s/deployment.yaml")).toBe(true);
    expect(isDeploymentConfigFile(".env.production")).toBe(true);
    expect(isDeploymentConfigFile("fly.toml")).toBe(true);
    expect(isDeploymentConfigFile("vercel.json")).toBe(true);
  });

  it("returns false for non-deployment source code files", () => {
    expect(isDeploymentConfigFile("src/App.tsx")).toBe(false);
    expect(isDeploymentConfigFile("README.md")).toBe(false);
    expect(isDeploymentConfigFile("src/utils/math.ts")).toBe(false);
  });
});

describe("Impact Analysis Logic", () => {
  const workflows: WorkflowInfo[] = [
    {
      filename: "test.yml",
      name: "Unit Tests",
      paths: ["src/**"],
      isDeploy: false,
      triggersPr: true,
    },
    {
      filename: "deploy.yml",
      name: "Staging Deploy",
      paths: ["src/**", "Dockerfile"],
      isDeploy: true,
      triggersPr: true,
    },
    {
      filename: "docs.yml",
      name: "Build Docs",
      paths: ["docs/**"],
      isDeploy: false,
      triggersPr: true,
    },
  ];

  it("matches changed files against workflows and produces correct impact lists", () => {
    const changedFiles = ["src/components/Button.tsx", "Dockerfile"];
    const result = analyzeImpact(changedFiles, workflows);

    expect(result.runningWorkflows.map((w) => w.name)).toEqual([
      "Unit Tests",
      "Staging Deploy",
    ]);

    expect(result.deployFiles).toContain("Dockerfile");
    expect(result.deployFiles).toContain("src/components/Button.tsx");
  });

  it("returns empty workflows list when no changed files match paths", () => {
    const changedFiles = ["docs/guide.md"];
    const result = analyzeImpact(changedFiles, [workflows[0]]);
    expect(result.runningWorkflows).toHaveLength(0);
  });
});
