/**
 * Athena – Intermediate Tier: Conflict Radar (v2).
 *
 * Detection strategies (DOM-first, API optional):
 *
 *  1. DOM-BASED (zero cost, instant):
 *     - Reads GitHub's own merge-status banners and text to detect conflicts,
 *       out-of-date status, and CI failures.
 *     - Parses "N commits behind" from GitHub's rendered UI text.
 *     - Reads CI status (passing / failing / pending) from merge-status items.
 *     - Reads review approval status from the sidebar.
 *     - Triggers a FAR_BEHIND banner when behind count >= FAR_BEHIND_THRESHOLD,
 *       even if GitHub hasn't flagged the branch as "out-of-date" yet.
 *
 *  2. API-BASED (optional enrichment, PAT if set, 60 req/hr unauthenticated):
 *     - Fetches precise ahead/behind counts via GitHub REST for the "out-of-date"
 *       case only (to show exact numbers in the banner).
 *
 * Banner types (in priority order):
 *  conflict    – merge conflicts must be resolved first
 *  far-behind  – branch is >= FAR_BEHIND_THRESHOLD commits behind base
 *  out-of-date – branch is behind (any amount) per GitHub's own indicator
 *  ci-failing  – one or more CI checks are failing
 *
 * Each banner includes a step-by-step guide to fix the issue safely.
 */

import {
  getGitHubAuthHeaders,
  isRuleEnabled,
  isWarningDismissedSync,
  dismissWarning,
  logActivity,
} from "../storage/session";
import { primerTokenStyles } from "../ui/tokens";
import { createOcticon, type OcticonName } from "../ui/icons";
import { announceAthenaWarning, fadeOutAthenaHost } from "../ui/motion";

import {
  getCIStatus,
  getReviewStatus,
  getConflictStatus,
  type CIStatus,
  type ReviewStatus,
  type ConflictStatus,
} from "./pre-merge-checklist";

// ─────────────────────────────────────────────────────────────────────────────
// THRESHOLD CONSTANT
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Number of commits a branch must be behind the base branch before Athena
 * shows a "Far Behind" banner, even when GitHub hasn't flagged it as
 * "out-of-date" yet. Increase this value to reduce banner noise on long-lived
 * branches; decrease it to catch divergence earlier.
 */
export const FAR_BEHIND_THRESHOLD = 10;

// ─────────────────────────────────────────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────────────────────────────────────────

export type RadarType =
  | "conflict"
  | "far-behind"
  | "out-of-date"
  | "ci-failing";

export interface RadarSnapshot {
  /** Primary problem type driving the banner. */
  type: RadarType;
  /** Human-readable headline for the banner. */
  headline: string;
  /** One-sentence summary of the issue. */
  summary: string;
  /** CI status at detection time. */
  ci: CIStatus;
  /** Review status at detection time. */
  review: ReviewStatus;
  /** Conflict status at detection time. */
  conflict: ConflictStatus;
  /** Commits behind base (0 = unknown / not detected from DOM). */
  behindBy: number;
  /** Commits ahead of base (0 = unknown). */
  aheadBy: number;
  /** Head branch name (may be empty string if not found in DOM). */
  headBranch: string;
  /** Base branch name (may be empty string if not found in DOM). */
  baseBranch: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// DOM-ONLY: EXTRACT COMMITS-BEHIND COUNT
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Parse the number of commits this branch is behind the base branch from
 * GitHub's rendered page text.  GitHub renders phrases like:
 *   "This branch is 5 commits behind main."
 *   "12 commits behind"
 * Returns 0 if not found.
 */
export function parseBehindCountFromDom(doc: Document = document): number {
  // GitHub renders this in several places; try all of them.
  const candidates = [
    doc.querySelector(".branch-action-item"),
    doc.querySelector(".merge-status-list"),
    doc.querySelector("#partial-pull-merging"),
    doc.querySelector(".mergability-message"),
    doc.querySelector(".gh-header-meta"),
    doc.body,
  ];

  for (const el of candidates) {
    if (!el) continue;
    const text = el.textContent ?? "";
    // "5 commits behind" or "This branch is 5 commits behind main"
    const m =
      text.match(/(\d+)\s+commits?\s+behind/i) ??
      text.match(/behind\s+\S+\s+by\s+(\d+)\s+commits?/i);
    if (m) {
      const n = parseInt(m[1], 10);
      if (!isNaN(n) && n > 0) return n;
    }
  }
  return 0;
}

/**
 * Parse branch names from the PR page DOM.
 * Returns { headBranch, baseBranch } — empty strings when not found.
 */
export function parseBranchNamesFromDom(doc: Document = document): {
  headBranch: string;
  baseBranch: string;
} {
  const head =
    (doc.querySelector(
      ".commit-ref.head-ref .css-truncate-target, " +
      ".gh-header-meta .head-ref .css-truncate-target, " +
      ".head-ref"
    ) as HTMLElement | null)?.textContent?.trim() ?? "";

  const base =
    (doc.querySelector(
      ".commit-ref.base-ref .css-truncate-target, " +
      ".gh-header-meta .base-ref .css-truncate-target, " +
      ".base-ref"
    ) as HTMLElement | null)?.textContent?.trim() ?? "";

  return { headBranch: head, baseBranch: base };
}

// ─────────────────────────────────────────────────────────────────────────────
// API: ENRICH WITH PRECISE AHEAD/BEHIND COUNTS (optional)
// ─────────────────────────────────────────────────────────────────────────────

interface ComparePayload {
  aheadBy: number;
  behindBy: number;
  headBranch: string;
  baseBranch: string;
}

function parsePrUrl(
  url: string
): { owner: string; repo: string; prNumber: number } | null {
  const m = url.match(/github\.com\/([^/]+)\/([^/]+)\/pull\/(\d+)/);
  if (!m) return null;
  return { owner: m[1], repo: m[2], prNumber: parseInt(m[3], 10) };
}

async function fetchBranchCompare(
  owner: string,
  repo: string,
  prNumber: number
): Promise<ComparePayload | null> {
  const restUrl = `https://api.github.com/repos/${owner}/${repo}/pulls/${prNumber}`;
  try {
    const authHeaders = await getGitHubAuthHeaders(restUrl);
    const res = await fetch(restUrl, {
      headers: { Accept: "application/vnd.github+json", ...authHeaders },
    });
    if (!res.ok) return null;
    const data = await res.json() as {
      head: { ref: string };
      base: { ref: string };
    };

    const compareUrl = `https://api.github.com/repos/${owner}/${repo}/compare/${data.base.ref}...${data.head.ref}`;
    const cmpHeaders = await getGitHubAuthHeaders(compareUrl);
    const cmpRes = await fetch(compareUrl, {
      headers: { Accept: "application/vnd.github+json", ...cmpHeaders },
    });
    if (!cmpRes.ok) return null;
    const cmp = await cmpRes.json() as {
      ahead_by: number;
      behind_by: number;
    };

    return {
      aheadBy: cmp.ahead_by,
      behindBy: cmp.behind_by,
      headBranch: data.head.ref,
      baseBranch: data.base.ref,
    };
  } catch {
    return null;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CORE: EVALUATE FULL RADAR SNAPSHOT
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Evaluates the full radar snapshot from DOM data only (no network calls).
 * Returns null when no banner-worthy issue is detected.
 */
export function evaluateRadarSnapshot(
  doc: Document = document
): RadarSnapshot | null {
  const ci      = getCIStatus(doc);
  const review  = getReviewStatus(doc);
  const conflict = getConflictStatus(doc);
  const behindBy = parseBehindCountFromDom(doc);
  const { headBranch, baseBranch } = parseBranchNamesFromDom(doc);

  // Priority 1: merge conflicts — must resolve before anything else
  if (conflict === "conflicts") {
    return {
      type: "conflict",
      headline: "Merge Conflicts Detected",
      summary:
        "This PR cannot be merged automatically because it has conflicts with " +
        (baseBranch ? `'${baseBranch}'` : "the base branch") + ".",
      ci,
      review,
      conflict,
      behindBy,
      aheadBy: 0,
      headBranch,
      baseBranch,
    };
  }

  // Priority 2: far behind — explicit commit count >= threshold
  if (behindBy >= FAR_BEHIND_THRESHOLD) {
    return {
      type: "far-behind",
      headline: `Branch Far Behind (${behindBy} commits)`,
      summary:
        `'${headBranch || "This branch"}' is ${behindBy} commits behind ` +
        (baseBranch ? `'${baseBranch}'` : "the base branch") +
        `. Merging now risks integrating stale code and making conflicts harder to resolve.`,
      ci,
      review,
      conflict,
      behindBy,
      aheadBy: 0,
      headBranch,
      baseBranch,
    };
  }

  // Priority 3: GitHub's "out of date" indicator (any amount)
  if (conflict === "out-of-date") {
    return {
      type: "out-of-date",
      headline: "Branch Out of Date",
      summary:
        (headBranch ? `'${headBranch}'` : "This branch") +
        " is behind " +
        (baseBranch ? `'${baseBranch}'` : "the base branch") +
        (behindBy > 0 ? ` by ${behindBy} commit${behindBy === 1 ? "" : "s"}` : "") +
        ". Update it before merging to avoid losing recent changes.",
      ci,
      review,
      conflict,
      behindBy,
      aheadBy: 0,
      headBranch,
      baseBranch,
    };
  }

  // Priority 4: CI failing — doesn't block merge but warrants a banner
  if (ci === "failing") {
    return {
      type: "ci-failing",
      headline: "CI Checks Failing",
      summary:
        "One or more CI checks are failing on this PR. Merging with failing checks " +
        "may introduce regressions to the base branch.",
      ci,
      review,
      conflict,
      behindBy,
      aheadBy: 0,
      headBranch,
      baseBranch,
    };
  }

  return null; // Nothing to warn about
}

// ─────────────────────────────────────────────────────────────────────────────
// STEP-BY-STEP SAFE UPDATE GUIDES
// ─────────────────────────────────────────────────────────────────────────────

interface Step {
  cmd?: string;   // inline code block
  text: string;   // description
}

function getUpdateSteps(snap: RadarSnapshot): Step[] {
  const head = snap.headBranch || "<your-branch>";
  const base = snap.baseBranch || "main";

  if (snap.type === "conflict") {
    return [
      {
        text: `Fetch the latest state of '${base}' from remote:`,
        cmd: `git fetch origin ${base}`,
      },
      {
        text: "Switch to your branch:",
        cmd: `git checkout ${head}`,
      },
      {
        text: `Merge (or rebase) '${base}' into your branch to surface conflicts locally:`,
        cmd: `git merge origin/${base}`,
      },
      {
        text: "Open the conflicted files and resolve each conflict marker (<<<<<<<, =======, >>>>>>>).",
      },
      {
        text: "Stage the resolved files and complete the merge:",
        cmd: "git add . && git commit",
      },
      {
        text: "Push the conflict-resolution commit:",
        cmd: `git push origin ${head}`,
      },
      {
        text: "Return to this PR — the conflict indicator should clear within a few seconds.",
      },
    ];
  }

  if (snap.type === "far-behind" || snap.type === "out-of-date") {
    return [
      {
        text: `Fetch the latest commits from '${base}':`,
        cmd: `git fetch origin ${base}`,
      },
      {
        text: "Switch to your branch:",
        cmd: `git checkout ${head}`,
      },
      {
        text: `Rebase your branch on top of the latest '${base}' (preferred — keeps history linear):`,
        cmd: `git rebase origin/${base}`,
      },
      {
        text: `Alternatively, merge '${base}' into your branch (creates a merge commit):`,
        cmd: `git merge origin/${base}`,
      },
      {
        text: "Resolve any conflicts that surface during the rebase / merge, then continue:",
        cmd: "git rebase --continue   # or: git merge --continue",
      },
      {
        text: "Push (force-push only if you rebased — never force-push shared branches):",
        cmd: `git push origin ${head}   # add --force-with-lease if you rebased`,
      },
      {
        text: "GitHub will update the PR status automatically once the push arrives.",
      },
    ];
  }

  if (snap.type === "ci-failing") {
    return [
      {
        text: "Click 'Show all checks' in the merge box to see which job(s) failed.",
      },
      {
        text: "Open the failing check's log and look for the first ERROR or FAILED line.",
      },
      {
        text: "Fix the root cause in your local checkout, commit, and push:",
        cmd: `git push origin ${head}`,
      },
      {
        text: "GitHub Actions / CI will re-run automatically on the new push.",
      },
      {
        text:
          "If the failure is flaky (network timeout, etc.), re-trigger via " +
          "the 'Re-run jobs' button on the Actions page.",
      },
    ];
  }

  return [];
}

// ─────────────────────────────────────────────────────────────────────────────
// BANNER CSS (Shadow DOM)
// ─────────────────────────────────────────────────────────────────────────────

const RADAR_CSS = `
  :host {
    display: block;
    margin-bottom: 14px;
    font-family: Inter, Geist, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  }

  /* ── outer card ── */
  .radar-card {
    border-radius: 12px;
    border: 1px solid;
    overflow: hidden;
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    box-shadow: 0 8px 20px -12px var(--bg-inset);
  }

  .radar-card[data-type="conflict"] {
    background: var(--bg-subtle);
    border-color: var(--danger-subtle);
    box-shadow: 0 8px 20px -12px var(--bg-inset);
  }
  .radar-card[data-type="far-behind"],
  .radar-card[data-type="out-of-date"],
  .radar-card[data-type="ci-failing"] {
    background: var(--bg-subtle);
    border-color: var(--attention-subtle);
    box-shadow: 0 8px 20px -12px var(--bg-inset);
  }

  /* ── header row ── */
  .radar-header {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 13px 16px 10px;
  }

  .radar-icon { display: inline-flex; width: 18px; height: 18px; flex-shrink: 0; }
  .radar-icon svg { width: 100%; height: 100%; }

  .radar-titles { flex: 1; min-width: 0; }

  .radar-headline {
    font-size: 13px;
    font-weight: 700;
    letter-spacing: -0.01em;
  }
  .radar-card[data-type="conflict"]   .radar-headline { color: var(--danger); }
  .radar-card[data-type="far-behind"] .radar-headline { color: var(--attention); }
  .radar-card[data-type="out-of-date"].radar-headline { color: var(--attention); }
  .radar-card[data-type="ci-failing"] .radar-headline { color: var(--attention); }

  .radar-summary {
    font-size: 11.5px;
    color: var(--fg-muted);
    line-height: 1.5;
    margin-top: 2px;
  }

  .radar-badge {
    font-size: 9.5px;
    font-weight: 700;
    padding: 2px 8px;
    border-radius: 999px;
    color: var(--fg);
    letter-spacing: 0.06em;
    text-transform: uppercase;
    flex-shrink: 0;
  }
  .radar-card[data-type="conflict"]   .radar-badge { background: var(--danger); }
  .radar-card[data-type="far-behind"] .radar-badge { background: var(--attention); }
  .radar-card[data-type="out-of-date"].radar-badge { background: var(--attention); }
  .radar-card[data-type="ci-failing"] .radar-badge { background: var(--attention); }

  /* ── status pills row ── */
  .radar-status-row {
    display: flex;
    gap: 6px;
    padding: 0 16px 12px;
    flex-wrap: wrap;
  }

  .status-pill {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-size: 10px;
    font-weight: 600;
    padding: 2px 8px;
    border-radius: 999px;
    border: 1px solid;
    letter-spacing: 0.03em;
  }

  .pill-green  { color: var(--success); border-color: var(--success-subtle); background: var(--success-subtle); }
  .pill-red    { color: var(--danger); border-color: var(--danger-subtle);  background: var(--danger-subtle); }
  .pill-yellow { color: var(--attention); border-color: var(--attention-subtle); background: var(--attention-subtle); }
  .pill-gray   { color: var(--fg-muted); border-color: var(--border-soft); background: var(--border-soft); }

  /* ── divider ── */
  .radar-divider {
    height: 1px;
    background: var(--border-soft);
    margin: 0 16px;
  }

  /* ── guide section ── */
  .radar-guide-toggle {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 10px 16px;
    font-size: 11.5px;
    font-weight: 600;
    color: var(--accent);
    cursor: pointer;
    background: none;
    border: none;
    width: 100%;
    text-align: left;
  }
  .radar-guide-toggle:hover { color: var(--accent); }
  .radar-guide-toggle:focus-visible {
    outline: 2px solid var(--accent);
    outline-offset: -2px;
  }

  .radar-guide-toggle .caret {
    font-size: 10px;
    display: inline-block;
  }
  .radar-guide-toggle.open .caret { transform: rotate(90deg); }

  .radar-steps {
    padding: 0 16px 14px;
    display: none;
  }
  .radar-steps.visible { display: block; }

  .radar-step {
    display: flex;
    gap: 10px;
    margin-bottom: 10px;
  }
  .radar-step:last-child { margin-bottom: 0; }

  .step-num {
    flex-shrink: 0;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: var(--accent-subtle);
    border: 1px solid var(--accent-subtle);
    color: var(--accent);
    font-size: 10px;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 1px;
  }

  .step-body { flex: 1; min-width: 0; }

  .step-text {
    font-size: 11.5px;
    color: var(--fg-muted);
    line-height: 1.5;
  }

  .step-cmd {
    display: block;
    margin-top: 5px;
    padding: 6px 10px;
    background: var(--bg-subtle);
    border: 1px solid var(--border-soft);
    border-radius: 6px;
    font-family: ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace;
    font-size: 11px;
    color: var(--accent);
    white-space: pre;
    overflow-x: auto;
  }

  /* ── footer ── */
  .radar-footer {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding: 9px 16px;
    gap: 8px;
    border-top: 1px solid var(--border-soft);
    background: var(--bg-subtle);
  }

  .btn-dismiss {
    font-size: 11px;
    font-weight: 600;
    color: var(--fg-muted);
    background: var(--border-soft);
    border: 1px solid var(--border-soft);
    border-radius: 6px;
    padding: 4px 11px;
    cursor: pointer;
  }
  .btn-dismiss:hover {
    color: var(--fg);
    background: var(--border-soft);
    border-color: var(--border-soft);
  }
  .btn-dismiss:focus-visible {
    outline: 2px solid var(--accent);
    outline-offset: 2px;
  }

  .btn-update-branch {
    font-size: 11px;
    font-weight: 650;
    color: var(--fg-on-emphasis, #fff);
    background: var(--success-emphasis, #1f883d);
    border: 1px solid var(--success, #2da44e);
    border-radius: 6px;
    padding: 5px 12px;
    cursor: pointer;
    transition: filter 180ms ease, border-color 180ms ease, box-shadow 180ms ease;
  }
  .btn-update-branch:hover:not(:disabled) { filter: brightness(1.06); border-color: rgba(0,240,255,.42); box-shadow: 0 0 6px rgba(0,240,255,.12); }
  .btn-update-branch:disabled { opacity: .65; cursor: wait; }
  .fix-action-status { margin-right: auto; color: var(--fg-muted); font-size: 11px; }
  .fix-action-status[data-state="error"] { color: var(--danger-fg, #cf222e); }
  .fix-action-status[data-state="success"] { color: var(--success, #2da44e); }
`;

const SECURITY_HUD_CSS = `
  :host {
    display: block;
    position: relative;
    z-index: 9999;
    margin: 0 0 8px;
    container-type: inline-size;
    font-family: system-ui, Inter, "Geist Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  }
  .hud {
    position: relative;
    overflow: hidden;
    color: #fff;
    background: rgba(10, 10, 10, .82);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid rgba(255, 255, 255, .10);
    border-radius: 8px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, .32);
  }
  .hud[data-mode="safe"] { border-color: rgba(16,185,129,.32); }
  .hud[data-mode="analyzing"] { border-color: rgba(0,240,255,.28); }
  .hud[data-risk="threat"] { border-color: rgba(239,68,68,.42); }
  .hud[data-risk="warning"] { border-color: rgba(245,158,11,.34); }
  [hidden] { display:none !important; }
  .hud::before {
    position: absolute;
    inset: 0;
    z-index: 0;
    content: "";
    pointer-events: none;
    opacity: .35;
    background-image: linear-gradient(to right, rgba(255,255,255,.025) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,.025) 1px, transparent 1px);
    background-size: 20px 20px;
  }
  .hud > * { position: relative; z-index: 1; }
  .hud-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 9px 12px;
    border-bottom: 1px solid rgba(255,255,255,.07);
  }
  .brand { display:flex; align-items:center; gap:8px; min-width:0; }
  .brand-icon { display:inline-flex; color:#00f0ff; }
  .brand-icon svg { width:17px; height:17px; }
  .brand-copy { display:flex; flex-direction:column; gap:2px; }
  .brand-name { color:#fff; font-size:10px; font-weight:750; letter-spacing:.12em; }
  .brand-subtitle { color:#737373; font: 8px/1.2 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; letter-spacing:.045em; }
  .monitoring { display:flex; align-items:center; gap:6px; color:#67e8f9; font:600 8px/1 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; letter-spacing:.055em; white-space:nowrap; }
  .monitor-dot { width:6px; height:6px; flex:0 0 6px; border-radius:50%; background:#00f0ff; box-shadow:0 0 5px rgba(0,240,255,.3); }
  .hud[data-mode="analyzing"] .monitor-dot { animation:hud-pulse 2s ease-in-out infinite; }
  .hud[data-mode="safe"] .monitoring { color:#34d399; }
  .hud[data-mode="safe"] .monitor-dot { background:#10b981; box-shadow:0 0 7px rgba(16,185,129,.35); }
  .hud[data-mode="risk"][data-risk="warning"] .monitoring { color:#fbbf24; }
  .hud[data-risk="threat"] .monitoring { color:#f87171; }
  .hud[data-risk="threat"] .monitor-dot { background:#ef4444; box-shadow:0 0 7px rgba(239,68,68,.38); }
  .scan-state { padding:8px 12px 2px; color:#67e8f9; font:600 9px/1.2 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; letter-spacing:.06em; }
  .scan-label { display:flex; align-items:center; gap:7px; }
  .branch-route { display:flex; align-items:center; gap:8px; padding:5px 0 1px 17px; color:#d4d4d4; font:10px/1.2 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; }
  .route-arrow { color:#00f0ff; font-size:13px; }
  .spinner { width:10px; height:10px; box-sizing:border-box; border:1.5px solid rgba(0,240,255,.25); border-top-color:#00f0ff; border-radius:50%; animation:hud-spin 1.2s linear infinite; }
  .scan-line { height:2px; margin-top:7px; overflow:hidden; background:rgba(0,240,255,.08); }
  .scan-line::after { display:block; width:28%; height:100%; content:""; background:#00f0ff; box-shadow:0 0 7px rgba(0,240,255,.65); animation:hud-scan 1.8s ease-in-out infinite; }
  .telemetry { display:grid; grid-template-columns:repeat(4, minmax(0, 1fr)); gap:0; }
  .metric { min-width:0; padding:8px 12px; border-top:1px solid rgba(255,255,255,.05); }
  .metric:not(:nth-child(4n)) { border-right:1px solid rgba(255,255,255,.05); }
  .metric-label { margin-bottom:4px; color:#737373; font:600 8px/1 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; letter-spacing:.12em; }
  .metric-value { overflow:hidden; color:#d4d4d4; font:500 10px/1.3 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; text-overflow:ellipsis; white-space:nowrap; }
  .metric-status[data-level="safe"], .metric-risk[data-level="safe"] { color:#34d399; }
  .metric-status[data-level="warning"], .metric-risk[data-level="warning"] { color:#fbbf24; }
  .metric-status[data-level="threat"], .metric-risk[data-level="threat"] { color:#f87171; }
  @container (max-width: 620px) {
    .telemetry { grid-template-columns:repeat(2, minmax(0, 1fr)); }
    .metric:not(:nth-child(2n)) { border-right:1px solid rgba(255,255,255,.05); }
    .metric:nth-child(2n) { border-right:0; }
  }
  @keyframes hud-pulse { 0%,100%{opacity:.82;box-shadow:0 0 4px rgba(0,240,255,.25)} 50%{opacity:1;box-shadow:0 0 6px rgba(0,240,255,.4)} }
  @keyframes hud-spin { to { transform:rotate(360deg) } }
  @keyframes hud-scan { 0%{transform:translateX(-120%)} 100%{transform:translateX(460%)} }
  @media (prefers-reduced-motion: reduce) { .monitor-dot,.spinner,.scan-line::after { animation:none!important; } .scan-line::after { transform:translateX(0); } }
`;

// ─────────────────────────────────────────────────────────────────────────────
// BANNER DOM BUILDER
// ─────────────────────────────────────────────────────────────────────────────

interface HudTelemetry {
  base: string;
  head: string;
  status: string;
  risk: string;
  riskLevel: "safe" | "warning" | "threat";
  statusLevel: "safe" | "warning" | "threat";
  mode: "safe" | "analyzing" | "risk";
  analyzing: boolean;
}

function getHudTelemetry(snap: RadarSnapshot | null, analyzing: boolean, doc: Document = document): HudTelemetry {
  const branches = parseBranchNamesFromDom(doc);
  const behindBy = snap?.behindBy || parseBehindCountFromDom(doc);
  const conflict = snap?.conflict ?? getConflictStatus(doc);
  const ci = snap?.ci ?? getCIStatus(doc);
  const review = snap?.review ?? getReviewStatus(doc);
  const status = analyzing
    ? "ANALYZING"
    : behindBy > 0
    ? `${behindBy} BEHIND`
    : conflict === "out-of-date"
      ? "BRANCH OUT OF DATE"
      : conflict === "clean"
        ? "UP TO DATE"
        : "STATUS UNKNOWN";
  const isThreat = conflict === "conflicts" || ci === "failing";
  const isSafe = conflict === "clean" && ci !== "failing" && ci !== "pending" && review !== "changes-requested" && review !== "no-approval" && behindBy === 0;
  const isWarning = !isThreat && !isSafe;
  const risk = isThreat
    ? conflict === "conflicts" ? "CONFLICT DETECTED" : "CHECKS FAILING"
    : isWarning
      ? conflict === "out-of-date" || behindBy > 0 ? "UPDATE RECOMMENDED"
        : ci === "pending" ? "CHECKS IN PROGRESS"
          : review === "changes-requested" ? "CHANGES REQUESTED"
            : review === "no-approval" ? "APPROVAL REQUIRED" : "STATUS UNAVAILABLE"
      : "MERGE PATH CLEAR";
  return {
    base: snap?.baseBranch || branches.baseBranch || "Unknown",
    head: snap?.headBranch || branches.headBranch || "Unknown",
    status,
    risk: isSafe ? "MERGE PATH CLEAR" : risk,
    riskLevel: isThreat ? "threat" : isWarning ? "warning" : "safe",
    statusLevel: isThreat ? "threat" : isWarning ? "warning" : "safe",
    mode: analyzing ? "analyzing" : isSafe ? "safe" : "risk",
    analyzing,
  };
}

function createSecurityHud(data: HudTelemetry, pageUrl: string): HTMLDivElement {
  const host = document.createElement("div");
  host.dataset.athenaSecurityHud = "";
  host.dataset.pageUrl = pageUrl;
  host.dataset.athenaThemeHost = "";
  host.setAttribute("aria-label", "Athena GitHub protection telemetry");
  const shadow = host.attachShadow({ mode: "open" });
  const style = document.createElement("style");
  style.textContent = `${primerTokenStyles}\n${SECURITY_HUD_CSS}`;
  shadow.appendChild(style);

  const card = document.createElement("section");
  card.className = "hud";
  const header = document.createElement("div");
  header.className = "hud-head";
  const brand = document.createElement("div");
  brand.className = "brand";
  const icon = document.createElement("span");
  icon.className = "brand-icon";
  icon.appendChild(createOcticon("shield", 17));
  const brandCopy = document.createElement("div");
  brandCopy.className = "brand-copy";
  const name = document.createElement("span");
  name.className = "brand-name";
  name.textContent = "ATHENA // BRANCH RADAR";
  const subtitle = document.createElement("span");
  subtitle.className = "brand-subtitle";
  subtitle.dataset.hudSubtitle = "";
  brandCopy.append(name, subtitle);
  brand.append(icon, brandCopy);
  const monitoring = document.createElement("div");
  monitoring.className = "monitoring";
  const dot = document.createElement("span");
  dot.className = "monitor-dot";
  const monitoringText = document.createElement("span");
  monitoringText.dataset.hudStatus = "";
  monitoringText.textContent = "MONITORING";
  monitoring.append(dot, monitoringText);
  header.append(brand, monitoring);
  card.appendChild(header);

  const scan = document.createElement("div");
  scan.className = "scan-state";
  scan.dataset.hudScan = "";
  const scanLabel = document.createElement("div");
  scanLabel.className = "scan-label";
  const spinner = document.createElement("span");
  spinner.className = "spinner";
  const scanText = document.createElement("span");
  scanText.textContent = "ANALYZING BRANCH";
  scanLabel.append(spinner, scanText);
  const branchRoute = document.createElement("div");
  branchRoute.className = "branch-route";
  branchRoute.dataset.hudRoute = "";
  const routeHead = document.createElement("span");
  routeHead.dataset.routeHead = "";
  const routeArrow = document.createElement("span");
  routeArrow.className = "route-arrow";
  routeArrow.textContent = "↓";
  const routeBase = document.createElement("span");
  routeBase.dataset.routeBase = "";
  branchRoute.append(routeHead, routeArrow, routeBase);
  const scanLine = document.createElement("div");
  scanLine.className = "scan-line";
  scan.append(scanLabel, branchRoute, scanLine);
  card.appendChild(scan);

  const telemetry = document.createElement("div");
  telemetry.className = "telemetry";
  for (const [key, label] of [["base", "BASE"], ["head", "HEAD"], ["status", "STATUS"], ["risk", "RISK"]] as const) {
    const metric = document.createElement("div");
    metric.className = "metric";
    const metricLabel = document.createElement("div");
    metricLabel.className = "metric-label";
    metricLabel.textContent = label;
    const value = document.createElement("div");
    value.className = `metric-value${key === "status" ? " metric-status" : key === "risk" ? " metric-risk" : ""}`;
    value.dataset.metric = key;
    metric.append(metricLabel, value);
    telemetry.appendChild(metric);
  }
  card.appendChild(telemetry);
  shadow.appendChild(card);
  updateSecurityHud(host, data);
  return host;
}

function updateSecurityHud(host: HTMLElement, data: HudTelemetry): void {
  const shadow = host.shadowRoot;
  const card = shadow?.querySelector<HTMLElement>(".hud");
  if (!shadow || !card) return;
  card.dataset.risk = data.riskLevel;
  card.dataset.mode = data.mode;
  const subtitle = shadow.querySelector<HTMLElement>("[data-hud-subtitle]");
  if (subtitle) subtitle.textContent = data.mode === "safe" ? "ANALYSIS COMPLETE" : data.mode === "risk" ? "ATHENA SECURITY WARNING" : "GITHUB PROTECTION ACTIVE";
  const status = shadow.querySelector<HTMLElement>("[data-hud-status]");
  if (status) status.textContent = "MONITORING";
  const scan = shadow.querySelector<HTMLElement>("[data-hud-scan]");
  if (scan) scan.hidden = !data.analyzing;
  const route = shadow.querySelector<HTMLElement>("[data-hud-route]");
  if (route) route.hidden = !data.analyzing;
  const routeHead = shadow.querySelector<HTMLElement>("[data-route-head]");
  const routeBase = shadow.querySelector<HTMLElement>("[data-route-base]");
  if (routeHead) routeHead.textContent = data.head;
  if (routeBase) routeBase.textContent = data.base;
  const statusValue = shadow.querySelector<HTMLElement>('[data-metric="status"]');
  if (statusValue) statusValue.dataset.level = data.statusLevel;
  const riskValue = shadow.querySelector<HTMLElement>('[data-metric="risk"]');
  if (riskValue) riskValue.dataset.level = data.riskLevel;
  for (const key of ["base", "head", "status", "risk"] as const) {
    const value = shadow.querySelector<HTMLElement>(`[data-metric="${key}"]`);
    if (value) value.textContent = data[key];
  }
}

function pillClass(status: string, okValue: string, warnValues: string[]): string {
  if (status === okValue) return "status-pill pill-green";
  if (warnValues.includes(status)) return "status-pill pill-red";
  if (status === "pending") return "status-pill pill-yellow";
  return "status-pill pill-gray";
}

function ciPillLabel(ci: CIStatus): string {
  if (ci === "passing") return "CI Passed";
  if (ci === "failing") return "CI Failing";
  if (ci === "pending") return "CI Pending";
  return "CI Unknown";
}

function reviewPillLabel(review: ReviewStatus): string {
  if (review === "approved")          return "Approved";
  if (review === "changes-requested") return "Changes Requested";
  if (review === "no-approval")       return "No Approval";
  return "Review Unknown";
}

function conflictPillLabel(conflict: ConflictStatus): string {
  if (conflict === "clean")     return "No Conflicts";
  if (conflict === "conflicts") return "Conflicts";
  if (conflict === "out-of-date") return "Out of Date";
  return "Conflict Unknown";
}

function typeIcon(type: RadarType): OcticonName {
  if (type === "conflict") return "alert";
  if (type === "far-behind") return "arrow";
  if (type === "out-of-date") return "branch";
  return "warning";
}

function addStatusIcon(element: HTMLElement, name: OcticonName, label: string): void {
  element.appendChild(createOcticon(name, 14));
  element.appendChild(document.createTextNode(label));
}

function createRadarBanner(
  snap: RadarSnapshot,
  onDismiss: () => void
): HTMLDivElement {
  const host = document.createElement("div");
  host.dataset.athenaRadarBanner = snap.type;
  host.dataset.athenaThemeHost = "";

  const shadow = host.attachShadow({ mode: "open" });

  const style = document.createElement("style");
  style.textContent = `${primerTokenStyles}\n${RADAR_CSS}`;
  shadow.appendChild(style);

  // ── Card ──────────────────────────────────────────────────────────────────
  const card = document.createElement("div");
  card.className = "radar-card";
  card.dataset.type = snap.type;

  // ── Header ────────────────────────────────────────────────────────────────
  const headerEl = document.createElement("div");
  headerEl.className = "radar-header";

  const iconEl = document.createElement("span");
  iconEl.className = "radar-icon";
  iconEl.appendChild(createOcticon(typeIcon(snap.type), 18));

  const titlesEl = document.createElement("div");
  titlesEl.className = "radar-titles";

  const headlineEl = document.createElement("div");
  headlineEl.className = "radar-headline";
  headlineEl.textContent = snap.headline;

  const summaryEl = document.createElement("div");
  summaryEl.className = "radar-summary";
  summaryEl.textContent = snap.summary;

  titlesEl.appendChild(headlineEl);
  titlesEl.appendChild(summaryEl);

  const badgeEl = document.createElement("span");
  badgeEl.className = "radar-badge";
  badgeEl.textContent = `ATHENA · ${snap.type === "conflict" || snap.type === "ci-failing" ? "DANGER" : "WARNING"}`;

  headerEl.appendChild(iconEl);
  headerEl.appendChild(titlesEl);
  headerEl.appendChild(badgeEl);
  card.appendChild(headerEl);

  // ── Status pills ──────────────────────────────────────────────────────────
  const pillsRow = document.createElement("div");
  pillsRow.className = "radar-status-row";

  const ciPill = document.createElement("span");
  ciPill.className = pillClass(snap.ci, "passing", ["failing"]);
  addStatusIcon(ciPill, snap.ci === "passing" ? "check" : snap.ci === "failing" ? "cancel" : snap.ci === "pending" ? "warning" : "info", ciPillLabel(snap.ci));

  const revPill = document.createElement("span");
  revPill.className = pillClass(snap.review, "approved", ["changes-requested"]);
  addStatusIcon(revPill, snap.review === "approved" ? "check" : snap.review === "changes-requested" ? "cancel" : snap.review === "no-approval" ? "warning" : "info", reviewPillLabel(snap.review));

  const cflPill = document.createElement("span");
  cflPill.className = pillClass(snap.conflict, "clean", ["conflicts"]);
  addStatusIcon(cflPill, snap.conflict === "clean" ? "check" : snap.conflict === "conflicts" ? "alert" : snap.conflict === "out-of-date" ? "branch" : "info", conflictPillLabel(snap.conflict));

  if (snap.behindBy > 0) {
    const behindPill = document.createElement("span");
    behindPill.className =
      snap.behindBy >= FAR_BEHIND_THRESHOLD
        ? "status-pill pill-red"
        : "status-pill pill-yellow";
    addStatusIcon(behindPill, "arrow", `${snap.behindBy} behind`);
    pillsRow.appendChild(behindPill);
  }

  pillsRow.appendChild(ciPill);
  pillsRow.appendChild(revPill);
  pillsRow.appendChild(cflPill);
  card.appendChild(pillsRow);

  // ── Step-by-step guide ────────────────────────────────────────────────────
  const steps = getUpdateSteps(snap);
  if (steps.length > 0) {
    const div1 = document.createElement("div");
    div1.className = "radar-divider";
    card.appendChild(div1);

    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.className = "radar-guide-toggle";
    toggle.innerHTML =
      `<span class="caret">▶</span> ` +
      (snap.type === "ci-failing"
        ? "How to fix failing CI checks"
        : "How to update this branch safely") +
      ` (${steps.length} steps)`;

    const stepsEl = document.createElement("div");
    stepsEl.className = "radar-steps";

    steps.forEach((step, i) => {
      const stepDiv = document.createElement("div");
      stepDiv.className = "radar-step";

      const numEl = document.createElement("div");
      numEl.className = "step-num";
      numEl.textContent = String(i + 1);

      const bodyEl = document.createElement("div");
      bodyEl.className = "step-body";

      const textEl = document.createElement("div");
      textEl.className = "step-text";
      textEl.textContent = step.text;
      bodyEl.appendChild(textEl);

      if (step.cmd) {
        const cmdEl = document.createElement("code");
        cmdEl.className = "step-cmd";
        cmdEl.textContent = step.cmd;
        bodyEl.appendChild(cmdEl);
      }

      stepDiv.appendChild(numEl);
      stepDiv.appendChild(bodyEl);
      stepsEl.appendChild(stepDiv);
    });

    toggle.addEventListener("click", () => {
      const open = stepsEl.classList.toggle("visible");
      toggle.classList.toggle("open", open);
    });

    card.appendChild(toggle);
    card.appendChild(stepsEl);
  }

  // ── Footer / dismiss ──────────────────────────────────────────────────────
  const footer = document.createElement("div");
  footer.className = "radar-footer";

  if (snap.type === "conflict") {
    const resolveBtn = document.createElement("button");
    resolveBtn.type = "button";
    resolveBtn.className = "btn-update-branch";
    resolveBtn.textContent = "Help me resolve";
    resolveBtn.addEventListener("click", () => {
      document.dispatchEvent(new CustomEvent("ATHENA_CONFLICT_RESOLUTION_REQUESTED"));
    });
    footer.appendChild(resolveBtn);
  }

  if (snap.type === "out-of-date" || snap.type === "far-behind") {
    const status = document.createElement("span");
    status.className = "fix-action-status";
    status.setAttribute("aria-live", "polite");
    const updateBtn = document.createElement("button");
    updateBtn.type = "button";
    updateBtn.className = "btn-update-branch";
    updateBtn.textContent = "Update branch";
    updateBtn.addEventListener("click", () => {
      const parsed = parsePrUrl(window.location.href);
      if (!parsed) {
        status.dataset.state = "error";
        status.textContent = "Could not identify this pull request.";
        return;
      }
      if (!window.confirm(`Update ${snap.headBranch || "this branch"} with the latest commits from ${snap.baseBranch || "the base branch"}? GitHub will update the pull request branch.`)) {
        status.textContent = "Update cancelled.";
        void logActivity({ type: "fix-action", ruleId: "fix-it", label: "Branch update cancelled", repo: `${parsed.owner}/${parsed.repo}` });
        return;
      }
      updateBtn.disabled = true;
      status.dataset.state = "pending";
      status.textContent = "Updating branch…";
      chrome.runtime.sendMessage(
        { type: "ATHENA_UPDATE_BRANCH", owner: parsed.owner, repo: parsed.repo, pullNumber: parsed.prNumber },
        (response: { ok?: boolean; message?: string; error?: string } | undefined) => {
          if (chrome.runtime.lastError || !response?.ok) {
            status.dataset.state = "error";
            status.textContent = response?.error ?? "Could not update the branch. Check your saved GitHub token.";
            updateBtn.disabled = false;
            return;
          }
          status.dataset.state = "success";
          status.textContent = "Update requested. Refresh GitHub to see the result.";
          updateBtn.textContent = "Update requested";
        }
      );
    });
    footer.appendChild(status);
    footer.appendChild(updateBtn);
  }

  const dismissBtn = document.createElement("button");
  dismissBtn.type = "button";
  dismissBtn.className = "btn-dismiss";
  dismissBtn.textContent = "Dismiss for this PR";
  dismissBtn.addEventListener("click", () => fadeOutAthenaHost(host, onDismiss));

  footer.appendChild(dismissBtn);
  card.appendChild(footer);

  shadow.appendChild(card);
  announceAthenaWarning();
  return host;
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN EXPORT
// ─────────────────────────────────────────────────────────────────────────────

const RADAR_ATTR = "data-athena-radar-done";

export async function runConflictRadar(): Promise<void> {
  const pageUrl = window.location.pathname;
  const isPullRequestPage = /\/pull\/\d+/.test(pageUrl);
  if (!isRuleEnabled("passive_conflict-radar") || !isPullRequestPage) {
    document.querySelectorAll<HTMLElement>("[data-athena-security-hud], [data-athena-radar-banner]").forEach((host) => host.remove());
    return;
  }
  const currentUrl = window.location.href;

  // Prefer the merge context; fall back to the PR metadata area without using
  // fixed positioning, so the HUD never overlays GitHub's merge controls.
  const mergeBox = document.querySelector(
    ".discussion-timeline-actions, .merge-pr-section, #partial-pull-merging"
  );
  const anchor = mergeBox ?? document.querySelector(".gh-header-meta");
  if (!anchor) return;

  document.querySelectorAll<HTMLElement>("[data-athena-security-hud]").forEach((existing) => {
    if (existing.dataset.pageUrl !== pageUrl) existing.remove();
  });
  document.querySelectorAll<HTMLElement>("[data-athena-radar-banner]").forEach((existing) => {
    if (existing.dataset.pageUrl !== pageUrl) existing.remove();
  });

  // 1. DOM-only snapshot (instant — no network)
  let snap = evaluateRadarSnapshot(document);
  const parsed = parsePrUrl(currentUrl);
  const needsCompare = snap?.type === "out-of-date" && snap.behindBy === 0;
  let hud = Array.from(document.querySelectorAll<HTMLElement>("[data-athena-security-hud]"))
    .find((candidate) => candidate.dataset.pageUrl === pageUrl) ?? null;
  if (hud?.dataset.scanInflight === "true") return;
  if (!hud) {
    hud = createSecurityHud(getHudTelemetry(snap, needsCompare && !!parsed), pageUrl);
    if (mergeBox) anchor.parentNode?.insertBefore(hud, anchor);
    else anchor.parentNode?.insertBefore(hud, anchor.nextSibling);
  }

  const warningDismissed = isWarningDismissedSync("passive_conflict-radar", currentUrl);
  const warningAlreadyRendered = anchor.getAttribute(RADAR_ATTR) === pageUrl;
  if (snap && !warningDismissed && !warningAlreadyRendered) anchor.setAttribute(RADAR_ATTR, pageUrl);
  if (hud) hud.dataset.scanInflight = needsCompare && !!parsed ? "true" : "false";

  // 2. Optional API enrichment. The HUD's scan state is visible while this
  // request is in flight, then the telemetry is refreshed with the result.
  if (needsCompare && parsed) {
    const compare = await fetchBranchCompare(parsed.owner, parsed.repo, parsed.prNumber);
    if (compare && snap) {
      snap = {
        ...snap,
        behindBy: compare.behindBy,
        aheadBy: compare.aheadBy,
        headBranch: compare.headBranch || snap.headBranch,
        baseBranch: compare.baseBranch || snap.baseBranch,
      };
      if (compare.behindBy >= FAR_BEHIND_THRESHOLD) {
        snap = {
          ...snap,
          type: "far-behind",
          headline: `Branch Far Behind (${compare.behindBy} commits)`,
          summary:
            `'${snap.headBranch || "This branch"}' is ${compare.behindBy} commits behind ` +
            (snap.baseBranch ? `'${snap.baseBranch}'` : "the base branch") +
            `. Merging now risks integrating stale code and making conflicts harder to resolve.`,
        };
      }
    }
    updateSecurityHud(hud, getHudTelemetry(snap, false));
    hud.dataset.scanInflight = "false";
  }

  // A clean PR still gets contextual telemetry, but keeps the warning UI out
  // of the way. Existing dismissal applies to warnings only, not monitoring.
  if (!snap || warningDismissed) {
    if (!needsCompare) updateSecurityHud(hud, getHudTelemetry(snap, false));
    return;
  }

  if (snap.type === "ci-failing") {
    const candidates = Array.from(document.querySelectorAll<HTMLElement>(".merge-status-item, .branch-action-item, [data-testid*=check]"))
      .map((el) => (el.innerText || el.textContent || "").trim().replace(/\s+/g, " "))
      .filter((text) => /fail|error/i.test(text));
    const checkName = (candidates[0] || "Failing CI check").slice(0, 120);
    setTimeout(() => document.dispatchEvent(new CustomEvent("ATHENA_CI_FAILURE_DETECTED", { detail: { checkName } })), 0);
  }

  if (warningAlreadyRendered) return;

  const banner = createRadarBanner(snap, async () => {
    await dismissWarning("passive_conflict-radar", currentUrl);
  });
  banner.dataset.pageUrl = pageUrl;

  if (mergeBox) anchor.parentNode?.insertBefore(banner, anchor);
  else anchor.parentNode?.insertBefore(banner, anchor.nextSibling);
}
