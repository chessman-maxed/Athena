/**
 * Athena – ExplainModal Component (Shadow DOM UI).
 *
 * Renders inside Shadow DOM for:
 *  - First-send privacy notice (text leaves browser to configured endpoint)
 *  - Secret-detected block banner
 *  - Missing API key prompt
 *  - Plain-English LLM explanation display
 */

import { useState, useEffect } from "react";
import {
  processExplainRequest,
  setLLMConsent,
  type ExplainRequestResult,
} from "./explain-this";
import { loadSettings, type LLMSettings } from "../storage/session";

export interface ExplainModalProps {
  selectedText: string;
  isOpen: boolean;
  onClose: () => void;
  onOpenSettings?: () => void;
}

export function ExplainModal({
  selectedText,
  isOpen,
  onClose,
  onOpenSettings,
}: ExplainModalProps) {
  const [result, setResult] = useState<ExplainRequestResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [llmSettings, setLlmSettings] = useState<LLMSettings | null>(null);
  const [copied, setCopied] = useState(false);

  // Fetch settings & initiate explain processing on open
  useEffect(() => {
    if (!isOpen || !selectedText) {
      return;
    }

    let active = true;
    setLoading(true);
    setResult(null);

    loadSettings().then((settings) => {
      if (!active) return;
      setLlmSettings(settings);

      processExplainRequest(selectedText).then((res) => {
        if (!active) return;
        setResult(res);
        setLoading(false);
      });
    });

    return () => {
      active = false;
    };
  }, [isOpen, selectedText]);

  const handleGrantConsentAndProceed = async () => {
    await setLLMConsent(true);
    setLoading(true);
    const res = await processExplainRequest(selectedText, { forceConsent: true });
    setResult(res);
    setLoading(false);
  };

  const handleCopy = () => {
    if (result?.explanation) {
      navigator.clipboard.writeText(result.explanation);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (!isOpen) return null;

  const endpointUrl = llmSettings?.baseUrl ? llmSettings.baseUrl : "https://api.openai.com/v1";

  return (
    <div
      className="athena-modal-backdrop"
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: "var(--overlay)",
        backdropFilter: "blur(8px)",
        WebkitBackdropFilter: "blur(8px)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 2147483647,
        pointerEvents: "auto",
        fontFamily: "var(--font-sans)",
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="athena-explain-modal"
        style={{
          width: "580px",
          maxWidth: "92vw",
          maxHeight: "88vh",
          backgroundColor: "var(--bg-canvas)",
          border: "1px solid var(--border-soft)",
          borderRadius: "14px",
          boxShadow: "0 24px 60px var(--bg-inset), 0 0 30px var(--border-soft)",
          color: "var(--fg-muted)",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
        }}
      >
        {/* Header */}
        <div
          style={{
            padding: "14px 18px",
            borderBottom: "1px solid var(--bg-subtle)",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            background: "var(--bg-canvas)",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <div
              style={{
                width: "26px",
                height: "26px",
                borderRadius: "8px",
                background: "var(--bg-subtle)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "14px",
                boxShadow: "0 0 10px var(--border-soft)",
              }}
            >
              <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="16" height="16"><path d="m12 3 1.6 6.4L20 11l-6.4 1.6L12 19l-1.6-6.4L4 11l6.4-1.6z M19 3v4m-2-2h4" /></svg>
            </div>
            <div>
              <span style={{ fontSize: "13.5px", fontWeight: 700, color: "var(--fg)", letterSpacing: "0.01em" }}>
                Athena "Explain This"
              </span>
              <span style={{ fontSize: "10px", color: "var(--fg-muted)", marginLeft: "8px", fontFamily: "ui-monospace, monospace" }}>
                AI Analysis
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            style={{
              background: "var(--bg-subtle)",
              border: "1px solid var(--bg-subtle)",
              color: "var(--fg-muted)",
              fontSize: "14px",
              cursor: "pointer",
              padding: "4px 8px",
              borderRadius: "6px",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.color = "var(--fg)";
              e.currentTarget.style.borderColor = "var(--fg-muted)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.color = "var(--fg-muted)";
              e.currentTarget.style.borderColor = "var(--bg-subtle)";
            }}
            aria-label="Close"
          >
            ✕
          </button>
        </div>

        {/* Body Content */}
        <div
          style={{
            padding: "16px 18px",
            overflowY: "auto",
            display: "flex",
            flexDirection: "column",
            gap: "14px",
          }}
        >
          {/* Selected Text Preview */}
          <div
            style={{
              background: "var(--bg-canvas)",
              border: "1px solid var(--bg-subtle)",
              borderRadius: "10px",
              padding: "10px 14px",
            }}
          >
            <div
              style={{
                fontSize: "10px",
                fontWeight: 700,
                color: "var(--fg-subtle)",
                textTransform: "uppercase",
                letterSpacing: "0.08em",
                marginBottom: "5px",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <span>Selected Code / Log Excerpt</span>
              <span style={{ fontFamily: "ui-monospace, monospace", color: "var(--fg-muted)" }}>
                {selectedText.length} chars
              </span>
            </div>
            <pre
              style={{
                margin: 0,
                fontSize: "11px",
                lineHeight: "1.5",
                color: "var(--fg-muted)",
                fontFamily: "ui-monospace, monospace",
                maxHeight: "85px",
                overflowY: "auto",
                whiteSpace: "pre-wrap",
                wordBreak: "break-word",
              }}
            >
              {selectedText.slice(0, 300)}
              {selectedText.length > 300 ? " …" : ""}
            </pre>
          </div>

          {/* State 1: Loading */}
          {loading && (
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                padding: "28px 0",
                gap: "12px",
              }}
            >
              <div className="modal-loading-dots" aria-hidden="true">
                <span className="modal-loading-dot" />
                <span className="modal-loading-dot" />
                <span className="modal-loading-dot" />
              </div>
              <p style={{ margin: 0, fontSize: "12px", color: "var(--fg-muted)", fontWeight: 500 }}>
                Synthesizing security & logic explanation with LLM…
              </p>
            </div>
          )}

          {/* State 2: Needs Consent (First Send Notice) */}
          {!loading && result?.status === "needs-consent" && (
            <div
              style={{
                background: "var(--bg-subtle)",
                border: "1px solid var(--border-soft)",
                borderRadius: "10px",
                padding: "14px",
                color: "var(--fg-muted)",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
                <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="16" height="16"><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" /></svg>
                <strong style={{ fontSize: "12.5px", color: "var(--fg-muted)" }}>
                  External Provider Transmission Notice
                </strong>
              </div>
              <p style={{ margin: "0 0 10px 0", fontSize: "12px", color: "var(--fg)", lineHeight: "1.5" }}>
                The selected diff/log text above will leave your browser and be transmitted to your configured
                endpoint (<code style={{ color: "var(--fg-muted)", fontFamily: "ui-monospace, monospace" }}>{endpointUrl}</code>) for plain-English explanation.
              </p>
              <p style={{ margin: "0 0 14px 0", fontSize: "11px", color: "var(--fg-muted)" }}>
                ✓ Athena scanned the selection: <strong>0 secrets detected</strong>.<br />
                ✓ Only the highlighted excerpt is transmitted.
              </p>
              <div style={{ display: "flex", gap: "8px", justifyContent: "flex-end" }}>
                <button
                  type="button"
                  onClick={onClose}
                  style={{
                    background: "transparent",
                    border: "1px solid var(--border-soft)",
                    color: "var(--fg-muted)",
                    borderRadius: "6px",
                    fontSize: "12px",
                    padding: "6px 12px",
                    cursor: "pointer",
                  }}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  className="athena-primary-btn"
                  onClick={handleGrantConsentAndProceed}
                  style={{
                    background: "var(--success-emphasis)",
                    border: "none",
                    color: "var(--fg)",
                    borderRadius: "6px",
                    fontSize: "12px",
                    fontWeight: 600,
                    padding: "6px 16px",
                    cursor: "pointer",
                    boxShadow: "0 2px 10px var(--border-soft)",
                  }}
                >
                  Allow & Transmit
                </button>
              </div>
            </div>
          )}

          {/* State 3: Blocked due to detected secret */}
          {!loading && result?.status === "blocked-secret" && (
            <div
              style={{
                background: "var(--bg-subtle)",
                border: "1px solid var(--border-soft)",
                borderRadius: "10px",
                padding: "14px",
                color: "var(--fg-muted)",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
                <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" width="16" height="16"><circle cx="12" cy="12" r="9" /><path d="m6 6 12 12" /></svg>
                <strong style={{ fontSize: "13px", color: "var(--fg-muted)" }}>
                  Transmission Blocked: Credential Detected
                </strong>
              </div>
              <p style={{ margin: "0 0 10px 0", fontSize: "12px", color: "var(--fg)", lineHeight: "1.5" }}>
                Athena intercepted {result.findings?.length ?? 1} sensitive token(s) in this selection.
                To prevent accidental leakage, outbound requests are strictly blocked until credentials are redacted.
              </p>
              <ul style={{ margin: "0 0 10px 0", paddingLeft: "18px", fontSize: "11px", color: "var(--fg-muted)" }}>
                {result.findings?.map((f, i) => (
                  <li key={i} style={{ marginBottom: "2px" }}>
                    <strong style={{ color: "var(--fg-muted)" }}>{f.type}</strong>: <code style={{ fontFamily: "ui-monospace, monospace", color: "var(--fg-muted)" }}>{f.matchPreview}</code>
                  </li>
                ))}
              </ul>
              <p style={{ margin: 0, fontSize: "11px", color: "var(--fg-muted)" }}>
                Please unselect or redact credentials before requesting an AI explanation.
              </p>
            </div>
          )}

          {/* State 4: Missing API Key */}
          {!loading && result?.status === "missing-key" && (
            <div
              style={{
                background: "var(--bg-subtle)",
                border: "1px solid var(--bg-subtle)",
                borderRadius: "10px",
                padding: "18px",
                textAlign: "center",
              }}
            >
              <div style={{ fontSize: "24px", marginBottom: "8px", color: "var(--fg-muted)" }}><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="24" height="24"><path d="M14 8a5 5 0 1 1-2-4m-1 4 10 10m-4-4 3-3m-1 5 3-3" /></svg></div>
              <h3 style={{ margin: "0 0 6px 0", fontSize: "13px", color: "var(--fg)", fontWeight: 700 }}>
                LLM API Key Required
              </h3>
              <p style={{ margin: "0 0 14px 0", fontSize: "11.5px", color: "var(--fg-muted)", lineHeight: "1.5" }}>
                To use the "Explain this" feature, configure your OpenAI-compatible API key in Athena Settings.
              </p>
              {onOpenSettings && (
                <button
                  type="button"
                  className="athena-primary-btn"
                  onClick={() => {
                    onClose();
                    onOpenSettings();
                  }}
                  style={{
                    background: "var(--success-emphasis)",
                    border: "none",
                    color: "var(--fg)",
                    borderRadius: "6px",
                    fontSize: "12px",
                    fontWeight: 600,
                    padding: "7px 18px",
                    cursor: "pointer",
                    boxShadow: "0 2px 10px var(--border-soft)",
                  }}
                >
                  Configure Athena Settings
                </button>
              )}
            </div>
          )}

          {/* State 5: General Error */}
          {!loading && result?.status === "error" && (
            <div
              style={{
                background: "var(--bg-subtle)",
                border: "1px solid var(--border-soft)",
                borderRadius: "10px",
                padding: "12px 14px",
                color: "var(--fg-muted)",
                fontSize: "12px",
                lineHeight: "1.5",
              }}
            >
              <strong style={{ color: "var(--fg-muted)" }}>Error:</strong> {result.error}
            </div>
          )}

          {/* State 6: Success Explanation Result */}
          {!loading && result?.status === "success" && result.explanation && (
            <div
              style={{
                background: "var(--bg-canvas)",
                border: "1px solid var(--border-soft)",
                borderRadius: "10px",
                padding: "14px",
                boxShadow: "0 4px 16px var(--bg-inset)",
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  marginBottom: "10px",
                  borderBottom: "1px solid var(--bg-subtle)",
                  paddingBottom: "8px",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                  <span style={{ width: "6px", height: "6px", borderRadius: "50%", background: "var(--fg-muted)" }} />
                  <span style={{ fontSize: "11px", fontWeight: 700, color: "var(--fg-muted)", textTransform: "uppercase", letterSpacing: "0.06em" }}>
                    Plain-English Summary
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleCopy}
                  style={{
                    background: copied ? "var(--border-soft)" : "var(--border-soft)",
                    border: `1px solid ${copied ? "var(--border-soft)" : "var(--border-soft)"}`,
                    color: copied ? "var(--fg-muted)" : "var(--fg-muted)",
                    fontSize: "11px",
                    borderRadius: "6px",
                    padding: "3px 10px",
                    cursor: "pointer",
                    fontWeight: 600,
                  }}
                >
                  {copied ? "✓ Copied" : "Copy Explanation"}
                </button>
              </div>

              <div
                style={{
                  fontSize: "12.5px",
                  lineHeight: "1.65",
                  color: "var(--fg)",
                  whiteSpace: "pre-wrap",
                }}
              >
                {result.explanation}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div
          style={{
            padding: "12px 18px",
            borderTop: "1px solid var(--bg-subtle)",
            background: "var(--bg-canvas)",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <span style={{ fontSize: "10px", color: "var(--fg-subtle)" }}>
            Athena Privacy Shield · In-memory processing
          </span>
          <button
            type="button"
            onClick={onClose}
            style={{
              background: "var(--bg-subtle)",
              border: "1px solid var(--bg-subtle)",
              color: "var(--fg-muted)",
              borderRadius: "6px",
              fontSize: "12px",
              fontWeight: 600,
              padding: "6px 14px",
              cursor: "pointer",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = "var(--fg-muted)";
              e.currentTarget.style.color = "var(--fg)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = "var(--bg-subtle)";
              e.currentTarget.style.color = "var(--fg-muted)";
            }}
          >
            Dismiss
          </button>
        </div>
      </div>
    </div>
  );
}
