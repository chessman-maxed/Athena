/**
 * Athena – Beginner Tier: Shadow DOM tooltip UI.
 *
 * Attaches a floating tooltip to a GitHub UI element.
 * The tooltip appears on hover (via mouseenter/focus) and
 * disappears on mouseleave/blur.
 * It is fully isolated inside a Shadow DOM so GitHub's CSS
 * cannot affect it.
 *
 * When the TooltipDef has `showPreview: true` (e.g. Merge, Delete Branch),
 * the tooltip also includes a "what will happen" preview card scraped
 * from DOM data only — no API calls.
 */

import type { TooltipDef } from "./tooltips";
import { primerTokenStyles } from "../ui/tokens";
import { createOcticon } from "../ui/icons";
import { fadeOutAthenaElement } from "../ui/motion";

// ── CSS ──────────────────────────────────────────────────────────────────────
const TOOLTIP_CSS = `
  :host {
    position: absolute;
    z-index: 2147483647;
    pointer-events: none;
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }

  .tt {
    background: var(--bg-subtle);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border: 1px solid var(--border-soft);
    border-radius: 12px;
    padding: 14px 16px;
    width: 310px;
    box-shadow: 0 12px 32px var(--bg-inset), 0 0 16px var(--border-soft);
    color: var(--fg);
    font-size: 12px;
    line-height: 1.55;
    pointer-events: none;
  }

  .tt-header {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
  }

  .tt-icon { display: inline-flex; width: 16px; height: 16px; line-height: 1; }
  .tt-icon svg { width: 100%; height: 100%; }

  .tt-badge {
    font-size: 9px;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: var(--fg-muted);
    background: var(--border-soft);
    border: 1px solid var(--border-soft);
    border-radius: 4px;
    padding: 1px 6px;
  }

  .tt-title {
    font-weight: 700;
    font-size: 13px;
    color: var(--fg);
    letter-spacing: -0.01em;
  }

  .tt-body {
    color: var(--fg-muted);
    font-size: 12px;
    line-height: 1.6;
    margin-bottom: 10px;
  }

  /* ── "What will happen" preview card ───────────── */
  .tt-preview {
    background: var(--bg-subtle);
    border: 1px solid var(--border-soft);
    border-radius: 8px;
    padding: 10px 12px;
    margin-bottom: 10px;
    font-size: 11px;
  }

  .tt-preview-label {
    font-size: 9px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: var(--fg-muted);
    margin-bottom: 6px;
  }

  .tt-preview-row {
    display: flex;
    align-items: center;
    gap: 6px;
    color: var(--fg-muted);
    margin-bottom: 4px;
    font-size: 11px;
  }

  .tt-preview-row:last-child { margin-bottom: 0; }

  .tt-preview-key {
    color: var(--fg-subtle);
    min-width: 68px;
    font-size: 10px;
  }

  .tt-preview-val {
    color: var(--fg);
    font-weight: 600;
    font-family: ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace;
    font-size: 10.5px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    max-width: 160px;
  }

  .tt-preview-arrow {
    color: var(--fg-muted);
    font-weight: 700;
  }

  .tt-preview-tag {
    font-size: 9px;
    font-weight: 600;
    padding: 1px 6px;
    border-radius: 4px;
    letter-spacing: 0.05em;
  }

  .tag-warn  { background: var(--border-soft); color: var(--fg-muted); border: 1px solid var(--border-soft); }
  .tag-ok    { background: var(--border-soft); color: var(--fg-muted); border: 1px solid var(--border-soft); }
  .tag-info  { background: var(--border-soft); color: var(--fg-muted); border: 1px solid var(--border-soft); }

  /* ── Footer ────────────────────────────────────── */
  .tt-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .tt-hint {
    font-size: 10px;
    color: var(--fg-subtle);
    font-style: italic;
  }

  .tt-learn {
    font-size: 10px;
    font-weight: 600;
    color: var(--fg-muted);
    text-decoration: none;
    pointer-events: auto;
  }

  .tt-learn:hover {
    color: var(--fg-muted);
    text-decoration: underline;
  }
`;

// ── DOM-only preview scraping ─────────────────────────────────────────────────

interface PreviewData {
  rows: Array<{ key: string; value: string; tag?: { text: string; cls: "tag-warn" | "tag-ok" | "tag-info" } }>;
}

/** Scrape PR / branch info from the DOM. No API calls. */
function scrapePreview(anchorEl: Element, defId: string): PreviewData | null {
  const rows: PreviewData["rows"] = [];

  // ── Merge / Squash / Rebase ──────────────────────────────────────────────
  if (
    defId === "merge-pr" ||
    defId === "squash-pr" ||
    defId === "rebase-pr"
  ) {
    // Head branch (source)
    const headBranch =
      (document.querySelector(".commit-ref.head-ref, .head-ref .css-truncate-target") as HTMLElement | null)
        ?.textContent?.trim() ??
      (document.querySelector(".gh-header-meta .head-ref") as HTMLElement | null)
        ?.textContent?.trim() ??
      null;

    // Base branch (target)
    const baseBranch =
      (document.querySelector(".commit-ref.base-ref, .base-ref .css-truncate-target") as HTMLElement | null)
        ?.textContent?.trim() ??
      (document.querySelector(".gh-header-meta .base-ref") as HTMLElement | null)
        ?.textContent?.trim() ??
      null;

    if (headBranch && baseBranch) {
      rows.push({ key: "from branch", value: headBranch });
      rows.push({ key: "into branch", value: baseBranch });
    }

    // Commit count — GitHub renders "N commits" in the merge box or PR header
    const commitCount =
      (document.querySelector(".commits-listing .count, .commits-count, .tabnav-tab.selected .Counter") as HTMLElement | null)
        ?.textContent?.trim() ??
      null;

    if (commitCount) {
      const label = defId === "squash-pr" ? "squashed to" : "commits";
      const val   = defId === "squash-pr" ? "1 commit" : `${commitCount} commit${commitCount === "1" ? "" : "s"}`;
      rows.push({ key: label, value: val, tag: { text: "live", cls: "tag-info" } });
    }

    // "Delete branch after merge" checkbox
    const deleteChecked =
      (document.querySelector('input[id*="delete_branch"], input[name*="delete_branch"]') as HTMLInputElement | null)
        ?.checked ?? false;

    rows.push({
      key: "delete branch",
      value: deleteChecked ? "Yes (checked)" : "No",
      tag: deleteChecked
        ? { text: "branch gone", cls: "tag-warn" }
        : { text: "kept", cls: "tag-ok" },
    });

    return rows.length > 0 ? { rows } : null;
  }

  // ── Delete Branch ────────────────────────────────────────────────────────
  if (defId === "delete-branch") {
    // Branch name — often in `.commit-ref` nearby or the PR header
    const branchName =
      (anchorEl.closest("form")?.querySelector(".branch-name, code") as HTMLElement | null)
        ?.textContent?.trim() ??
      (document.querySelector(".head-ref .css-truncate-target, .commit-ref.head-ref") as HTMLElement | null)
        ?.textContent?.trim() ??
      null;

    if (branchName) {
      rows.push({ key: "branch", value: branchName });
    }

    // PR number for context
    const prNumber =
      (document.querySelector(".gh-header-number") as HTMLElement | null)
        ?.textContent?.trim() ??
      window.location.pathname.match(/\/pull\/(\d+)/)?.[1]
        ? `#${window.location.pathname.match(/\/pull\/(\d+)/)![1]}`
        : null;

    if (prNumber) {
      rows.push({ key: "PR", value: prNumber });
    }

    rows.push({
      key: "restorable?",
      value: "Yes (30 days)",
      tag: { text: "safe", cls: "tag-ok" },
    });

    return rows.length > 0 ? { rows } : null;
  }

  return null;
}

// ── Tooltip host management ───────────────────────────────────────────────────
// A single shared floating tooltip element is reused across all triggers.
let sharedHost: HTMLDivElement | null = null;
let sharedShadow: ShadowRoot | null = null;

function getOrCreateSharedHost(): { host: HTMLDivElement; shadow: ShadowRoot } {
  if (!sharedHost) {
    sharedHost = document.createElement("div");
    sharedHost.dataset.athenaThemeHost = "";
    sharedHost.id = "athena-tooltip-host";
    Object.assign(sharedHost.style, {
      position: "fixed",
      top: "0",
      left: "0",
      width: "0",
      height: "0",
      overflow: "visible",
      pointerEvents: "none",
      zIndex: "2147483647",
    });
    document.body.appendChild(sharedHost);
    sharedShadow = sharedHost.attachShadow({ mode: "open" });

    const style = document.createElement("style");
    style.textContent = `${primerTokenStyles}\n${TOOLTIP_CSS}`;
    sharedShadow.appendChild(style);
  }
  return { host: sharedHost, shadow: sharedShadow! };
}

function showTooltip(anchorEl: Element, def: TooltipDef): void {
  const { shadow } = getOrCreateSharedHost();

  // Remove previous tooltip content
  const prev = shadow.querySelector(".tt");
  if (prev) prev.remove();

  const rect = anchorEl.getBoundingClientRect();

  const tt = document.createElement("div");
  tt.className = "tt";
  Object.assign(tt.style, {
    position: "fixed",
    left: `${Math.min(rect.left, window.innerWidth - 320)}px`,
    top: `${rect.bottom + 8}px`,
  });

  // ── Header ──────────────────────────────────────────────────────────────
  const header = document.createElement("div");
  header.className = "tt-header";

  const icon = document.createElement("span");
  icon.className = "tt-icon";
  icon.appendChild(createOcticon(def.icon, 16));

  const badge = document.createElement("span");
  badge.className = "tt-badge";
  badge.textContent = "ATHENA";

  const title = document.createElement("span");
  title.className = "tt-title";
  title.textContent = def.title;

  header.appendChild(icon);
  header.appendChild(badge);
  header.appendChild(title);

  // ── Body ─────────────────────────────────────────────────────────────────
  const body = document.createElement("div");
  body.className = "tt-body";
  body.textContent = def.body;

  tt.appendChild(header);
  tt.appendChild(body);

  // ── "What will happen" preview (DOM-only) ────────────────────────────────
  if (def.showPreview) {
    const preview = scrapePreview(anchorEl, def.id);
    if (preview && preview.rows.length > 0) {
      const previewEl = document.createElement("div");
      previewEl.className = "tt-preview";

      const previewLabel = document.createElement("div");
      previewLabel.className = "tt-preview-label";
      previewLabel.textContent = "✦ What will happen";
      previewEl.appendChild(previewLabel);

      for (const row of preview.rows) {
        const rowEl = document.createElement("div");
        rowEl.className = "tt-preview-row";

        const keyEl = document.createElement("span");
        keyEl.className = "tt-preview-key";
        keyEl.textContent = row.key;

        const valEl = document.createElement("span");
        valEl.className = "tt-preview-val";
        valEl.textContent = row.value;

        rowEl.appendChild(keyEl);
        rowEl.appendChild(valEl);

        if (row.tag) {
          const tagEl = document.createElement("span");
          tagEl.className = `tt-preview-tag ${row.tag.cls}`;
          tagEl.textContent = row.tag.text;
          rowEl.appendChild(tagEl);
        }

        previewEl.appendChild(rowEl);
      }

      tt.appendChild(previewEl);
    }
  }

  // ── Footer ────────────────────────────────────────────────────────────────
  const footer = document.createElement("div");
  footer.className = "tt-footer";

  const hint = document.createElement("span");
  hint.className = "tt-hint";
  hint.textContent = "Hover to learn more";

  footer.appendChild(hint);

  if (def.learnMore) {
    const link = document.createElement("a");
    link.className = "tt-learn";
    link.href = def.learnMore;
    link.target = "_blank";
    link.rel = "noopener";
    link.textContent = "GitHub Docs →";
    footer.appendChild(link);
  }

  tt.appendChild(footer);
  shadow.appendChild(tt);
}

function hideTooltip(): void {
  const { shadow } = getOrCreateSharedHost();
  const tt = shadow.querySelector(".tt");
  if (tt instanceof HTMLElement) fadeOutAthenaElement(tt, () => tt.remove());
}

// ── Attachment ────────────────────────────────────────────────────────────────
const TOOLTIP_ATTR = "data-athena-tooltip";

export function attachTooltip(el: Element, def: TooltipDef): void {
  if (el.getAttribute(TOOLTIP_ATTR) !== null) return;
  el.setAttribute(TOOLTIP_ATTR, def.id);

  el.addEventListener("mouseenter", () => showTooltip(el, def));
  el.addEventListener("focus", () => showTooltip(el, def), { passive: true });
  el.addEventListener("mouseleave", hideTooltip);
  el.addEventListener("blur", hideTooltip, { passive: true });
}
