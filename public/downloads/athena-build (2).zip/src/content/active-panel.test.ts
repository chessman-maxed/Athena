/**
 * Unit tests for keyboard event isolation in active-panel.ts.
 *
 * Covers:
 *  - Keystrokes inside the Shadow DOM are stopped before they reach document
 *  - Alt+A is allowed through so the shortcut handler can toggle the panel
 *  - The Alt+A shortcut is suppressed when focus is inside a text field
 *
 * These tests run in a Node/Vitest environment and use lightweight DOM mocks
 * rather than a full browser to keep the suite fast and dependency-free.
 */

import { describe, it, expect, beforeEach, vi } from "vitest";

// ── Minimal mock ShadowRoot with capture-phase event listener support ─────────

class MockShadowRoot {
  private captureListeners: Map<string, Array<(e: Event) => void>> = new Map();

  addEventListener(
    type: string,
    listener: EventListenerOrEventListenerObject,
    optionsOrCapture?: boolean | AddEventListenerOptions
  ): void {
    const isCapture =
      typeof optionsOrCapture === "boolean"
        ? optionsOrCapture
        : (optionsOrCapture?.capture ?? false);

    if (isCapture) {
      if (!this.captureListeners.has(type)) {
        this.captureListeners.set(type, []);
      }
      this.captureListeners.get(type)!.push(
        typeof listener === "function" ? listener : (listener as EventListenerObject).handleEvent.bind(listener)
      );
    }
  }

  /** Simulate a keyboard event arriving from inside the Shadow DOM. */
  simulateKeydown(init: { key: string; altKey?: boolean }): { wasStopped: boolean } {
    // Use a plain object instead of `new KeyboardEvent()` because KeyboardEvent
    // is not available in the Vitest Node environment.
    let stopped = false;
    const event = {
      key: init.key,
      altKey: init.altKey ?? false,
      bubbles: true,
      cancelable: true,
      stopPropagation: () => { stopped = true; },
    } as unknown as Event;

    const listeners = this.captureListeners.get("keydown") ?? [];
    for (const fn of listeners) fn(event);

    return { wasStopped: stopped };
  }
}


// ── Helper: build the shadow-root keyboard isolation handler ─────────────────
// This mirrors exactly what buildPanel() does in active-panel.ts so we can
// test the behaviour without instantiating the full DOM panel.

function installKeyboardIsolation(shadow: MockShadowRoot) {
  for (const evtType of ["keydown", "keypress", "keyup"] as const) {
    shadow.addEventListener(
      evtType,
      (e: Event) => {
        const ke = e as KeyboardEvent;
        if (ke.altKey && ke.key === "a") return; // let Alt+A pass
        e.stopPropagation();
      },
      true // capture
    );
  }
}

// ── Helper: isFocusInTextField logic (extracted for unit testing) ─────────────

type FakeElement = { tagName: string; type?: string; isContentEditable?: boolean };

function isFocusInTextField(active: FakeElement | null): boolean {
  if (!active) return false;
  const tag = active.tagName.toLowerCase();
  if (tag === "textarea") return true;
  if (tag === "input") {
    const type = (active.type ?? "text").toLowerCase();
    const textTypes = new Set(["text", "search", "url", "email", "password", "number", "tel", ""]);
    return textTypes.has(type);
  }
  if (active.isContentEditable) return true;
  return false;
}

// ── Tests ─────────────────────────────────────────────────────────────────────

describe("active-panel keyboard isolation", () => {
  let shadow: MockShadowRoot;

  beforeEach(() => {
    shadow = new MockShadowRoot();
    installKeyboardIsolation(shadow);
  });

  it("stops regular keystrokes from propagating out of the Shadow DOM", () => {
    const { wasStopped } = shadow.simulateKeydown({ key: "s" });
    expect(wasStopped).toBe(true);
  });

  it("stops the '/' key (GitHub search shortcut) from propagating", () => {
    const { wasStopped } = shadow.simulateKeydown({ key: "/" });
    expect(wasStopped).toBe(true);
  });

  it("stops the 't' key (GitHub file-finder shortcut) from propagating", () => {
    const { wasStopped } = shadow.simulateKeydown({ key: "t" });
    expect(wasStopped).toBe(true);
  });

  it("stops Enter key from propagating (would trigger form submit on GitHub)", () => {
    const { wasStopped } = shadow.simulateKeydown({ key: "Enter" });
    expect(wasStopped).toBe(true);
  });

  it("allows Alt+A through so the panel-toggle shortcut can fire", () => {
    const { wasStopped } = shadow.simulateKeydown({ key: "a", altKey: true });
    expect(wasStopped).toBe(false);
  });

  it("stops Alt+S (not a panel shortcut) from propagating", () => {
    const { wasStopped } = shadow.simulateKeydown({ key: "s", altKey: true });
    expect(wasStopped).toBe(true);
  });
});

describe("isFocusInTextField guard for Alt+A shortcut", () => {
  it("returns false when no element is focused", () => {
    expect(isFocusInTextField(null)).toBe(false);
  });

  it("returns true for a textarea", () => {
    expect(isFocusInTextField({ tagName: "TEXTAREA" })).toBe(true);
  });

  it("returns true for a text input", () => {
    expect(isFocusInTextField({ tagName: "INPUT", type: "text" })).toBe(true);
  });

  it("returns true for a search input", () => {
    expect(isFocusInTextField({ tagName: "INPUT", type: "search" })).toBe(true);
  });

  it("returns true for a password input", () => {
    expect(isFocusInTextField({ tagName: "INPUT", type: "password" })).toBe(true);
  });

  it("returns false for a checkbox input", () => {
    expect(isFocusInTextField({ tagName: "INPUT", type: "checkbox" })).toBe(false);
  });

  it("returns false for a button", () => {
    expect(isFocusInTextField({ tagName: "BUTTON" })).toBe(false);
  });

  it("returns true for a contentEditable element", () => {
    expect(isFocusInTextField({ tagName: "DIV", isContentEditable: true })).toBe(true);
  });

  it("returns false for a non-editable div", () => {
    expect(isFocusInTextField({ tagName: "DIV", isContentEditable: false })).toBe(false);
  });
});

describe("dispatchChatViaBackground", () => {
  it("sends ATHENA_CHAT_REQUEST message and returns assistant reply", async () => {
    const mockSendMessage = vi.fn((msg: { type: string; messages: unknown[] }, callback: (r: { ok: boolean; reply: string }) => void) => {
      expect(msg.type).toBe("ATHENA_CHAT_REQUEST");
      expect(msg.messages).toHaveLength(2);
      callback({ ok: true, reply: "This PR modifies auth handling safely." });
    });

    (globalThis as unknown as { chrome: unknown }).chrome = {
      runtime: {
        sendMessage: mockSendMessage,
      },
    };

    const { dispatchChatViaBackground } = await import("./active-panel");
    const reply = await dispatchChatViaBackground([
      { role: "system", content: "You are Athena." },
      { role: "user", content: "What does this PR do?" },
    ]);

    expect(reply).toBe("This PR modifies auth handling safely.");
    expect(mockSendMessage).toHaveBeenCalledTimes(1);
  });

  it("throws clear error when background returns error", async () => {
    const mockSendMessage = vi.fn((_msg: unknown, callback: (r: { ok: boolean; error: string }) => void) => {
      callback({ ok: false, error: "LLM API key is not configured." });
    });

    (globalThis as unknown as { chrome: unknown }).chrome = {
      runtime: {
        sendMessage: mockSendMessage,
      },
    };

    const { dispatchChatViaBackground } = await import("./active-panel");
    await expect(
      dispatchChatViaBackground([{ role: "user", content: "Hello" }])
    ).rejects.toThrow("LLM API key is not configured.");
  });
});
