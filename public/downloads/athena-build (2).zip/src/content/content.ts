/**
 * Athena – content script entry point (v4).
 *
 * Subsystems
 *  1. Passive Mode      – dangerous-action guardrails (rules engine + banner UI)
 *  2. Beginner Tier     – "Teach & Guide" tooltips on GitHub UI elements
 *  3. Advanced Tier     – real-time secret scanner (delegated, shadow-host banners)
 *  4. Intermediate Tier – Conflict Radar on PR pages
 *  5. Active Mode       – LLM floating panel (FAB + Alt+A)
 *  6. Context Inspector – typed PageContext on every SPA navigation
 *  7. Shadow DOM UI     – single React root for all extension banners
 *  8. Session storage   – toggle cache warmed at startup; rules respect user toggles
 *
 * Built as a single IIFE (no runtime ES imports).
 */

// ── Storage (must init early — other subsystems read from the cache) ──────────
import {
  initToggleCache,
  initDismissedCache,
  initRulesConfigCache,
  isRuleEnabled,
  isWarningDismissedSync,
  logActivity,
} from "../storage/session";

// ── Passive Mode imports ──────────────────────────────────────────────────────
import { RULES } from "./rules";
import { createBannerHost } from "./ui";

// ── Beginner Tier imports ─────────────────────────────────────────────────────
import { TOOLTIP_DEFS } from "./tooltips";
import { attachTooltip } from "./tooltip-ui";

// ── Advanced Tier: delegated secret watcher ───────────────────────────────────
import { initSecretWatcher } from "./secret-watcher";

// ── Intermediate Tier imports ─────────────────────────────────────────────────
import { runConflictRadar } from "./conflict-radar";
import { runWorkflowRadar } from "./workflow-radar";
import { runPreMergeChecklist } from "./pre-merge-checklist";

// ── Active Mode import ────────────────────────────────────────────────────────
import { initActivePanel, openActivePanel } from "./active-panel";
import { initActivityTracker } from "./activity-tracker";

// ── Context Inspector import ──────────────────────────────────────────────────
import { initContextInspector, getCurrentContext, onContextChange } from "./page-context";
import { isRestrictedPage } from "./restricted-pages";
import { observeAthenaTheme } from "../ui/theme";

observeAthenaTheme();

// ── Shadow DOM host + React UI import ─────────────────────────────────────────
import { initShadowHost, addBanner, clearBanners, removeBanner } from "./shadow-host";

// ─────────────────────────────────────────────────────────────────────────────
// PASSIVE MODE: Dangerous-action guardrail
// ─────────────────────────────────────────────────────────────────────────────

const GUARDED_ATTR = "data-athena-guarded";

function getCurrentRepo(): string {
  const match = window.location.pathname.match(/^\/([^/]+)\/([^/]+)/);
  return match ? `${match[1]}/${match[2]}` : "";
}

function placeWarningHost(_el: Element, host: HTMLDivElement, _ruleId: string): void {
  document.body.append(host);
}

function restoreWarningHost(host: Element): void {
  host.remove();
}

async function evaluateDangerousElement(el: Element): Promise<void> {
  if (isRestrictedPage()) return;
  if (el.getAttribute(GUARDED_ATTR) !== null) return;

  for (const rule of RULES) {
    if (!rule.match(el)) continue;

    el.setAttribute(GUARDED_ATTR, rule.id);

    // ── Check rule-toggle: skip if the user disabled this rule ────────────
    const toggleId = `passive_${rule.id}` as Parameters<typeof isRuleEnabled>[0];
    if (!isRuleEnabled(toggleId)) return;

    const url = window.location.href;
    if (isWarningDismissedSync(rule.id, url)) return;

    let bannerHost: HTMLDivElement | null = null;
    let bypassOnce = false;
    const originalClickHandler = (e: Event) => {
      // Continue replays the original element's click. Let exactly that click
      // reach GitHub, then return to guarding subsequent user clicks.
      if (bypassOnce) {
        bypassOnce = false;
        return;
      }
      e.preventDefault();
      e.stopImmediatePropagation();
      if (bannerHost) return;

      bannerHost = createBannerHost({
        rule,
        repository: getCurrentRepo(),
        onProceed: async () => {
          void logActivity({ type: "proceeded", ruleId: rule.id, label: rule.actionType, repo: getCurrentRepo() });
          const host = bannerHost;
          bannerHost = null;
          if (host) restoreWarningHost(host);
          if (el.isConnected) {
            bypassOnce = true;
            try {
              (el as HTMLElement).click();
            } finally {
              // HTMLElement.click() dispatches synchronously. If the browser
              // suppresses it (for example, a now-disabled control), don't
              // leave a future real user click bypassed.
              bypassOnce = false;
            }
          }
        },
        onCancel: () => {
          void logActivity({ type: "cancelled", ruleId: rule.id, label: rule.actionType, repo: getCurrentRepo() });
          if (bannerHost) restoreWarningHost(bannerHost);
          bannerHost = null;
          (el as HTMLElement).focus?.({ preventScroll: true });
        },
      });
      placeWarningHost(el, bannerHost, rule.id);
      void logActivity({ type: "warning-shown", ruleId: rule.id, label: rule.actionType, repo: getCurrentRepo() }, url);
    };
    el.addEventListener("click", originalClickHandler, true);
    break;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// BEGINNER TIER: Teach & Guide tooltips
// ─────────────────────────────────────────────────────────────────────────────

function attachTooltips(root: Element | Document): void {
  for (const def of TOOLTIP_DEFS) {
    if (
      def.id === "delete-branch" &&
      !/^\/[^/]+\/[^/]+\/(?:pull\/|branches(?:\/|$))/.test(window.location.pathname)
    ) continue;
    const elements = root.querySelectorAll(def.selector);
    for (const el of elements) {
      attachTooltip(el, def);
    }
  }
}

// Advanced Tier scanning is fully delegated (see secret-watcher.ts);
// initSecretWatcher() is called once in the INIT section below.

// ─────────────────────────────────────────────────────────────────────────────
// COMBINED SCANNER: runs on a DOM subtree for all passive systems
// ─────────────────────────────────────────────────────────────────────────────

function scanSubtree(root: Element | Document): void {
  if (isRestrictedPage()) return;
  // Passive Mode: dangerous buttons
  const candidates = root.querySelectorAll(
    'button, a[role="button"], input[type="submit"], input[type="button"]'
  );
  for (const el of candidates) {
    void evaluateDangerousElement(el);
  }

  // Beginner Tier: tooltips
  attachTooltips(root);
  // (Advanced Tier secret scanning is event-delegated — no per-element attach needed)
}

// ─────────────────────────────────────────────────────────────────────────────
// MUTATION OBSERVER: react to GitHub SPA navigation
// ─────────────────────────────────────────────────────────────────────────────

const observer = new MutationObserver((mutations) => {
  if (isRestrictedPage()) return;
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType !== Node.ELEMENT_NODE) continue;
      const el = node as Element;
      void evaluateDangerousElement(el);
      scanSubtree(el);
    }
  }

  // GitHub can replace body content during Turbo navigation. Observe the
  // stable document root and restore only Athena mounts that were removed.
  if (!document.getElementById("athena-react-host")) initShadowHost();
  if (!document.getElementById("athena-panel-host") || !document.getElementById("athena-fab-host")) {
    initActivePanel();
  }

  // Re-run Conflict, Workflow Radar, and Pre-Merge Checklist when the merge box appears (lazy)
  void runConflictRadar();
  void runWorkflowRadar();
  runPreMergeChecklist();
});

// ─────────────────────────────────────────────────────────────────────────────
// INIT: warm toggle cache first, then start all subsystems
// ─────────────────────────────────────────────────────────────────────────────

async function boot(): Promise<void> {
  // 1. Warm the rule-toggle, dismissed-warnings, and rules-config cache BEFORE evaluating elements.
  await Promise.all([initToggleCache(), initDismissedCache(), initRulesConfigCache()]);

  initContextInspector();
  initActivityTracker();
  onContextChange(() => {
    if (isRestrictedPage()) {
      observer.disconnect();
      clearBanners();
      document.querySelectorAll(
        "[data-athena-host], [data-athena-merge-warning], [data-athena-checklist-panel], [data-athena-security-hud], [data-athena-radar-banner]"
      ).forEach((host) => {
        restoreWarningHost(host);
        host.remove();
      });
      initShadowHost();
      initActivePanel();
      return;
    }

    observer.observe(document.documentElement, { childList: true, subtree: true });
    scanSubtree(document);
    void runConflictRadar();
    void runWorkflowRadar();
    runPreMergeChecklist();
    initActivePanel();
    initSecretWatcher();
    initShadowHost();
    updateBannersForContext();
  });

  if (isRestrictedPage()) {
    initShadowHost();
    initActivePanel();
    return;
  }

  // 2. Start DOM observation before initial scan so we don't miss mutations
  //    that fire during the async gap.
  observer.observe(document.documentElement, { childList: true, subtree: true });

  // 3. Initial full-page scan + subsystem init.
  scanSubtree(document);
  void runConflictRadar();
  void runWorkflowRadar();
  runPreMergeChecklist();
  initActivePanel();
  initSecretWatcher(); // delegated – one listener covers all current + future fields

  // 4. Shadow DOM UI (must follow initContextInspector so initial context is ready).
  initShadowHost();

  // 5. PR-watching banner driven by page context.
  updateBannersForContext();
  console.log("[Athena] Content script loaded on:", window.location.href);
}

// ─────────────────────────────────────────────────────────────────────────────
// CONTEXT-DRIVEN BANNERS
// ─────────────────────────────────────────────────────────────────────────────

/** Show a context-appropriate banner on each navigation. */
function updateBannersForContext(): void {
  clearBanners();
  if (isRestrictedPage()) return;
  const ctx = getCurrentContext();
  const repo = ctx.owner && ctx.repo ? `${ctx.owner}/${ctx.repo}` : "this GitHub page";
  const page = ctx.type === "pull-request"
    ? `pull request #${ctx.prNumber ?? "?"}`
    : ctx.type === "issue"
      ? `issue #${ctx.issueNumber ?? "?"}`
      : ctx.type === "web-editor" || ctx.type === "new-file"
        ? "file editor"
        : ctx.type === "repo-home"
          ? "repository"
          : "GitHub page";
  const suggestion = ctx.type === "pull-request"
    ? "I can summarize the diff, explain the checks, or help review changes. Dangerous actions are still guarded."
    : ctx.type === "issue"
      ? "I can summarize the discussion, explain labels, or help identify next steps."
      : ctx.type === "web-editor" || ctx.type === "new-file"
        ? "I can explain selected code or help you think through a change. I do not read what you type into the editor."
        : ctx.type === "repo-home"
          ? "I can explain the project, help navigate files, or answer questions about this repository."
          : "I can explain what is on this page or help with your GitHub workflow.";

  addBanner({
    id: "athena-context-assistant",
    severity: "info",
    title: `Need help with this ${page}?`,
    message: `${repo} — ${suggestion}`,
    actions: [{
      label: "Ask Athena",
      variant: "primary",
      onClick: () => {
        removeBanner("athena-context-assistant");
        openActivePanel();
      },
    }],
  });
}

declare global {
  interface Window {
    __ATHENA_CONTENT_SCRIPT_INITIALIZED__?: boolean;
  }
}

// Guard against the content script running twice
if (
  window.__ATHENA_CONTENT_SCRIPT_INITIALIZED__ ||
  (typeof document !== "undefined" && document.documentElement.hasAttribute("data-athena-content-loaded"))
) {
  console.log("[Athena] Content script already initialized; skipping duplicate execution.");
} else {
  window.__ATHENA_CONTENT_SCRIPT_INITIALIZED__ = true;
  if (typeof document !== "undefined") {
    document.documentElement.setAttribute("data-athena-content-loaded", "true");
  }
  // Kick off the async boot sequence.
  void boot();
}
