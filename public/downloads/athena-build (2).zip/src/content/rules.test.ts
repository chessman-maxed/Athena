import { describe, expect, it } from "vitest";
import { RULES } from "./rules";

function button(text: string, path = "/owner/repo/settings", ariaLabel = ""): Element {
  return {
    tagName: "BUTTON",
    textContent: text,
    ownerDocument: { defaultView: { location: { pathname: path } } },
    getAttribute(name: string) {
      return name === "aria-label" ? ariaLabel : null;
    },
    closest() { return null; },
  } as unknown as Element;
}

const rule = (id: string) => RULES.find((candidate) => candidate.id === id)!;

describe("dangerous action rule matching", () => {
  it("guards the repository Danger Zone entry button but leaves GitHub's final confirmation native", () => {
    expect(rule("delete-repository").match(button("Delete this repository"))).toBe(true);
    expect(rule("delete-repository").match(button("I have read and understand these effects"))).toBe(false);
    expect(rule("delete-repository").match(button("I understand the consequences, delete this repository"))).toBe(false);
  });

  it("continues to detect archive, transfer, and branch deletion actions", () => {
    expect(rule("archive-repository").match(button("Archive this repository"))).toBe(true);
    expect(rule("transfer-ownership").match(button("Transfer ownership"))).toBe(true);
    expect(rule("delete-branch").match(button("Delete branch"))).toBe(true);
  });
});
