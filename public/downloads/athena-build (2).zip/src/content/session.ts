/**
 * Athena – content-script session storage re-exports.
 *
 * Delegates to src/storage/session.ts (single source of truth).
 */

export * from "../storage/session";

