/**
 * Unit tests for the enhanced Conflict Radar (v2).
 *
 * Tests cover:
 *  - parseBehindCountFromDom   – extracts commit count from rendered text
 *  - parseBranchNamesFromDom   – reads head/base branch names
 *  - evaluateRadarSnapshot     – priority ordering & type classification
 *  - FAR_BEHIND_THRESHOLD      – constant is accessible and a sensible number
 */

import { describe, it, expect } from "vitest";
import {
  FAR_BEHIND_THRESHOLD,
  parseBehindCountFromDom,
  parseBranchNamesFromDom,
  evaluateRadarSnapshot,
} from "./conflict-radar";

// ── Lightweight Mock Document for Node environment ──────────────────────────

interface MockElement {
  tagName: string;
  className: string;
  id: string;
  attributes: Record<string, string>;
  ownText: string;
  parent: MockElement | null;
  children: MockElement[];
  textContent: string;
  querySelector(selector: string): MockElement | null;
  querySelectorAll(selector: string): MockElement[];
}

function matchesSingleSelectorPart(el: MockElement, part: string): boolean {
  part = part.trim();
  if (!part) return false;

  // tag name like 'svg', 'span', 'div'
  const tagMatch = part.match(/^[a-zA-Z0-9]+/);
  if (tagMatch) {
    if (el.tagName.toLowerCase() !== tagMatch[0].toLowerCase()) return false;
    part = part.slice(tagMatch[0].length);
  }

  // ID match #id
  const idMatch = part.match(/^#([a-zA-Z0-9_-]+)/);
  if (idMatch) {
    if (el.id !== idMatch[1]) return false;
    part = part.slice(idMatch[0].length);
  }

  // Class matches like .commit-ref.head-ref
  const classMatches = Array.from(part.matchAll(/\.([a-zA-Z0-9_-]+)/g));
  for (const m of classMatches) {
    const cls = m[1];
    const classes = el.className.split(/\s+/);
    if (!classes.includes(cls)) return false;
  }

  // Attribute match like [data-check-state="FAILURE"] or [data-check-state]
  const attrMatch = part.match(/\[([a-zA-Z0-9_-]+)(?:=["']?([^"']+)["']?)?\]/);
  if (attrMatch) {
    const attrName = attrMatch[1];
    const attrVal = attrMatch[2];
    if (!(attrName in el.attributes)) return false;
    if (attrVal !== undefined && el.attributes[attrName] !== attrVal) return false;
  }

  return true;
}

function matchesCompoundSelector(el: MockElement, selector: string): boolean {
  const parts = selector.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return false;

  const targetPart = parts[parts.length - 1];
  if (!matchesSingleSelectorPart(el, targetPart)) return false;

  let currentParent = el.parent;
  for (let i = parts.length - 2; i >= 0; i--) {
    const part = parts[i];
    let foundAncestor = false;
    while (currentParent) {
      if (matchesSingleSelectorPart(currentParent, part)) {
        foundAncestor = true;
        currentParent = currentParent.parent;
        break;
      }
      currentParent = currentParent.parent;
    }
    if (!foundAncestor) return false;
  }

  return true;
}

function createMockElement(tagName: string, attributes: Record<string, string> = {}, ownText = ""): MockElement {
  const el: MockElement = {
    tagName,
    className: attributes["class"] ?? "",
    id: attributes["id"] ?? "",
    attributes,
    ownText,
    parent: null,
    children: [],
    get textContent(): string {
      const childTexts = this.children.map((c) => c.textContent).filter(Boolean);
      if (this.ownText && childTexts.length > 0) {
        return `${this.ownText} ${childTexts.join(" ")}`.trim();
      }
      if (this.ownText) return this.ownText.trim();
      return childTexts.join(" ").trim();
    },
    set textContent(val: string) {
      this.ownText = val;
      this.children = [];
    },
    querySelector(selector: string): MockElement | null {
      const alternatives = selector.split(",").map((s) => s.trim());
      const queue: MockElement[] = [...this.children];
      while (queue.length > 0) {
        const node = queue.shift()!;
        if (alternatives.some((alt) => matchesCompoundSelector(node, alt))) return node;
        queue.unshift(...node.children); // pre-order depth-first
      }
      return null;
    },
    querySelectorAll(selector: string): MockElement[] {
      const alternatives = selector.split(",").map((s) => s.trim());
      const results: MockElement[] = [];
      const queue: MockElement[] = [...this.children];
      while (queue.length > 0) {
        const node = queue.shift()!;
        if (alternatives.some((alt) => matchesCompoundSelector(node, alt))) {
          if (!results.includes(node)) results.push(node);
        }
        queue.push(...node.children);
      }
      return results;
    },
  };
  return el;
}

function parseHtmlToMock(html: string): MockElement {
  const root = createMockElement("div");

  if (!html.includes("<")) {
    root.ownText = html;
    return root;
  }

  const tokens = html.match(/<[^>]+>|[^<]+/g) ?? [];
  const stack: MockElement[] = [root];

  for (const token of tokens) {
    if (token.startsWith("</")) {
      if (stack.length > 1) {
        stack.pop();
      }
    } else if (token.startsWith("<")) {
      const tagMatch = token.match(/^<([a-zA-Z0-9]+)([^>]*?)(\/?)>$/);
      if (!tagMatch) continue;
      const tagName = tagMatch[1];
      const attrStr = tagMatch[2];
      const isSelfClosing = tagMatch[3] === "/" || ["svg", "img", "input", "br", "hr"].includes(tagName.toLowerCase());

      const attrs: Record<string, string> = {};
      const attrRegex = /([a-zA-Z0-9_-]+)(?:=["']([^"']*)["'])?/g;
      let m: RegExpExecArray | null;
      while ((m = attrRegex.exec(attrStr)) !== null) {
        attrs[m[1]] = m[2] ?? "";
      }

      const parent = stack[stack.length - 1];
      const elem = createMockElement(tagName, attrs);
      elem.parent = parent;
      parent.children.push(elem);

      if (!isSelfClosing) {
        stack.push(elem);
      }
    } else {
      const text = token.trim();
      if (text) {
        const current = stack[stack.length - 1];
        current.ownText = current.ownText ? `${current.ownText} ${text}` : text;
      }
    }
  }

  return root;
}

function makeDoc(bodyHtml: string): Document {
  const body = parseHtmlToMock(bodyHtml);
  return {
    body: body as unknown as HTMLElement,
    querySelector: (selector: string) => {
      const alternatives = selector.split(",").map((s) => s.trim());
      if (alternatives.some((alt) => matchesCompoundSelector(body, alt))) {
        return body as unknown as Element;
      }
      return body.querySelector(selector) as unknown as Element | null;
    },
    querySelectorAll: (selector: string) => {
      const list = body.querySelectorAll(selector);
      return list as unknown as NodeListOf<Element>;
    },
  } as unknown as Document;
}

// ─────────────────────────────────────────────────────────────────────────────
// FAR_BEHIND_THRESHOLD
// ─────────────────────────────────────────────────────────────────────────────

describe("FAR_BEHIND_THRESHOLD", () => {
  it("is a positive integer", () => {
    expect(typeof FAR_BEHIND_THRESHOLD).toBe("number");
    expect(Number.isInteger(FAR_BEHIND_THRESHOLD)).toBe(true);
    expect(FAR_BEHIND_THRESHOLD).toBeGreaterThan(0);
  });

  it("is at least 3 (avoids false positives on trivially behind branches)", () => {
    expect(FAR_BEHIND_THRESHOLD).toBeGreaterThanOrEqual(3);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// parseBehindCountFromDom
// ─────────────────────────────────────────────────────────────────────────────

describe("parseBehindCountFromDom", () => {
  it("returns 0 when no behind text present", () => {
    const doc = makeDoc("<div>All checks have passed.</div>");
    expect(parseBehindCountFromDom(doc)).toBe(0);
  });

  it('parses "5 commits behind"', () => {
    const doc = makeDoc(
      '<div class="branch-action-item">This branch is 5 commits behind main.</div>'
    );
    expect(parseBehindCountFromDom(doc)).toBe(5);
  });

  it('parses "1 commit behind" (singular)', () => {
    const doc = makeDoc(
      '<div class="branch-action-item">1 commit behind main.</div>'
    );
    expect(parseBehindCountFromDom(doc)).toBe(1);
  });

  it('parses "12 commits behind" from merge-status-list', () => {
    const doc = makeDoc(
      '<div class="merge-status-list">12 commits behind main.</div>'
    );
    expect(parseBehindCountFromDom(doc)).toBe(12);
  });

  it("parses large counts (100 commits behind)", () => {
    const doc = makeDoc(
      '<div class="branch-action-item">100 commits behind main.</div>'
    );
    expect(parseBehindCountFromDom(doc)).toBe(100);
  });

  it("does not confuse 'ahead' commits with 'behind' commits", () => {
    const doc = makeDoc(
      '<div class="branch-action-item">3 commits ahead of main.</div>'
    );
    expect(parseBehindCountFromDom(doc)).toBe(0);
  });

  it("ignores zero-value mentions", () => {
    // "0 commits behind" is unusual but should be treated as not behind
    const doc = makeDoc(
      '<div class="branch-action-item">0 commits behind main.</div>'
    );
    // 0 should NOT be returned as a positive behind count
    expect(parseBehindCountFromDom(doc)).toBe(0);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// parseBranchNamesFromDom
// ─────────────────────────────────────────────────────────────────────────────

describe("parseBranchNamesFromDom", () => {
  it("returns empty strings when no branch info is present", () => {
    const doc = makeDoc("<div>No branch info here.</div>");
    const { headBranch, baseBranch } = parseBranchNamesFromDom(doc);
    expect(headBranch).toBe("");
    expect(baseBranch).toBe("");
  });

  it("reads head-ref and base-ref targets", () => {
    const doc = makeDoc(`
      <span class="commit-ref head-ref">
        <span class="css-truncate-target">feature/auth</span>
      </span>
      <span class="commit-ref base-ref">
        <span class="css-truncate-target">main</span>
      </span>
    `);
    const { headBranch, baseBranch } = parseBranchNamesFromDom(doc);
    expect(headBranch).toBe("feature/auth");
    expect(baseBranch).toBe("main");
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// evaluateRadarSnapshot
// ─────────────────────────────────────────────────────────────────────────────

describe("evaluateRadarSnapshot", () => {
  it("returns null when there is nothing to warn about", () => {
    const doc = makeDoc(`
      <div class="branch-action-item">
        All checks have passed. This branch has no conflicts with the base branch.
      </div>
    `);
    expect(evaluateRadarSnapshot(doc)).toBeNull();
  });

  it("returns type=conflict when merge conflicts exist (highest priority)", () => {
    const doc = makeDoc(`
      <div class="merge-status-list">
        This branch has conflicts with the base branch. Cannot be merged automatically.
      </div>
      <div class="branch-action-item">12 commits behind main.</div>
    `);
    const snap = evaluateRadarSnapshot(doc);
    expect(snap).not.toBeNull();
    expect(snap!.type).toBe("conflict");
  });

  it("returns type=far-behind when behind count >= FAR_BEHIND_THRESHOLD", () => {
    const count = FAR_BEHIND_THRESHOLD; // exactly at threshold
    const doc = makeDoc(`
      <div class="branch-action-item">
        ${count} commits behind main. This branch is out-of-date with the base branch.
      </div>
    `);
    const snap = evaluateRadarSnapshot(doc);
    expect(snap).not.toBeNull();
    expect(snap!.type).toBe("far-behind");
    expect(snap!.behindBy).toBe(count);
  });

  it("returns type=out-of-date when behind < threshold but GitHub says out-of-date", () => {
    const count = FAR_BEHIND_THRESHOLD - 1; // just under threshold
    const doc = makeDoc(`
      <div class="branch-action-item">
        ${count} commits behind main. This branch is out-of-date with the base branch.
      </div>
    `);
    const snap = evaluateRadarSnapshot(doc);
    expect(snap).not.toBeNull();
    expect(snap!.type).toBe("out-of-date");
    expect(snap!.behindBy).toBe(count);
  });

  it("returns type=ci-failing when checks are failing (lowest priority among staleness)", () => {
    const doc = makeDoc(`
      <div class="merge-status-list">
        <div class="merge-status-item">
          <svg class="color-fg-danger"></svg>
          2 failing checks
        </div>
        <div class="branch-action-item">This branch has no conflicts with the base branch.</div>
      </div>
    `);
    const snap = evaluateRadarSnapshot(doc);
    expect(snap).not.toBeNull();
    expect(snap!.type).toBe("ci-failing");
  });

  it("conflict beats far-behind in priority", () => {
    const count = FAR_BEHIND_THRESHOLD + 5;
    const doc = makeDoc(`
      <div class="merge-status-list">
        <div class="merge-status-item">${count} commits behind. conflicts with the base branch</div>
      </div>
    `);
    const snap = evaluateRadarSnapshot(doc);
    expect(snap).not.toBeNull();
    expect(snap!.type).toBe("conflict");
  });

  it("snapshot includes ci, review, conflict sub-statuses", () => {
    const doc = makeDoc(`
      <div class="merge-status-list">
        <div class="merge-status-item">conflicts with the base branch</div>
      </div>
      <div class="branch-action-item">
        <svg class="color-fg-success"></svg> All checks passed
      </div>
    `);
    const snap = evaluateRadarSnapshot(doc);
    expect(snap).not.toBeNull();
    // conflict type is set
    expect(snap!.type).toBe("conflict");
    // ci may be unknown/passing — just verify the field exists
    expect(["passing", "failing", "pending", "unknown"]).toContain(snap!.ci);
    expect(["approved", "changes-requested", "no-approval", "unknown"]).toContain(snap!.review);
  });
});
