/**
 * Athena – Page Context Inspector
 *
 * Detects the current GitHub page type from the URL and DOM on every
 * navigation (initial load + Turbo / pjax SPA transitions).
 *
 * Exports:
 *   PageContext           – typed object describing the current page
 *   PageType              – union of recognised page types
 *   getCurrentContext()   – returns the latest snapshot synchronously
 *   onContextChange(fn)   – subscribe to context changes
 *   initContextInspector()– wire up all event listeners (call once)
 */

// ── Types ─────────────────────────────────────────────────────────────────────

export type PageType =
  | "pull-request"
  | "issue"
  | "new-file"
  | "web-editor"
  | "repo-home"
  | "other";

export interface PageContext {
  /** Discriminated page type. */
  readonly type: PageType;
  /** Full href at the moment of detection. */
  readonly url: string;
  /** GitHub repository owner (login), if on a repo page. */
  readonly owner: string | null;
  /** Repository name (without owner), if on a repo page. */
  readonly repo: string | null;
  /** Pull-request number, if type === "pull-request". */
  readonly prNumber: number | null;
  /** Issue number, if type === "issue". */
  readonly issueNumber: number | null;
  /** ISO-8601 timestamp of when this context was detected. */
  readonly detectedAt: string;
}

// ── URL-pattern regexes ───────────────────────────────────────────────────────

/**
 * github.com/<owner>/<repo>/pull/<n>[/...]
 * Capture groups: 1 = owner, 2 = repo, 3 = pr number
 */
const RE_PR =
  /^\/([^/]+)\/([^/]+)\/pull\/(\d+)/;

/**
 * github.com/<owner>/<repo>/issues/<n>[/...]
 * Capture groups: 1 = owner, 2 = repo, 3 = issue number
 */
const RE_ISSUE =
  /^\/([^/]+)\/([^/]+)\/issues\/(\d+)/;

/**
 * github.com/<owner>/<repo>/new/<branch>[/path]
 * New-file page via "Create new file" button.
 * Capture groups: 1 = owner, 2 = repo
 */
const RE_NEW_FILE =
  /^\/([^/]+)\/([^/]+)\/new\//;

/**
 * github.com/<owner>/<repo>/edit/<branch>/path  (single-file editor)
 *   OR
 * github.com/<owner>/<repo>/blob/<branch>/path  with CodeMirror present
 * Capture groups: 1 = owner, 2 = repo
 */
const RE_EDIT =
  /^\/([^/]+)\/([^/]+)\/(edit|blob)\//;

/**
 * github.com/<owner>/<repo>  (repo root — no further path segment or just /)
 * Capture groups: 1 = owner, 2 = repo
 */
const RE_REPO_HOME =
  /^\/([^/]+)\/([^/]+)\/?$/;

/**
 * Fallback: any repo path just to extract owner + repo
 * Capture groups: 1 = owner, 2 = repo
 */
const RE_REPO_ANY =
  /^\/([^/]+)\/([^/]+)/;

// ── DOM-based heuristics ──────────────────────────────────────────────────────

/**
 * Returns true when a CodeMirror / Monaco editor (web editor) is present.
 * Handles both the legacy CodeMirror editor and the newer Monaco editor.
 */
function hasEditorInDom(): boolean {
  return !!(
    document.querySelector(".CodeMirror") ||
    document.querySelector(".monaco-editor") ||
    document.querySelector("[data-target=\"code-editor.body\"]")
  );
}

// ── Core detection ────────────────────────────────────────────────────────────

function detect(): PageContext {
  const url = window.location.href;
  const path = window.location.pathname;
  const now = new Date().toISOString();

  // PR page
  const prMatch = RE_PR.exec(path);
  if (prMatch) {
    return {
      type: "pull-request",
      url,
      owner: prMatch[1],
      repo: prMatch[2],
      prNumber: parseInt(prMatch[3], 10),
      issueNumber: null,
      detectedAt: now,
    };
  }

  // Issue page
  const issueMatch = RE_ISSUE.exec(path);
  if (issueMatch) {
    return {
      type: "issue",
      url,
      owner: issueMatch[1],
      repo: issueMatch[2],
      prNumber: null,
      issueNumber: parseInt(issueMatch[3], 10),
      detectedAt: now,
    };
  }

  // New-file page
  const newFileMatch = RE_NEW_FILE.exec(path);
  if (newFileMatch) {
    return {
      type: "new-file",
      url,
      owner: newFileMatch[1],
      repo: newFileMatch[2],
      prNumber: null,
      issueNumber: null,
      detectedAt: now,
    };
  }

  // Edit / blob web-editor page — confirm with DOM heuristic
  const editMatch = RE_EDIT.exec(path);
  if (editMatch && hasEditorInDom()) {
    return {
      type: "web-editor",
      url,
      owner: editMatch[1],
      repo: editMatch[2],
      prNumber: null,
      issueNumber: null,
      detectedAt: now,
    };
  }

  // Repo home
  const repoHomeMatch = RE_REPO_HOME.exec(path);
  // Exclude the github.com root itself (path === "/" gives empty owner)
  if (repoHomeMatch && repoHomeMatch[1] && repoHomeMatch[2]) {
    return {
      type: "repo-home",
      url,
      owner: repoHomeMatch[1],
      repo: repoHomeMatch[2],
      prNumber: null,
      issueNumber: null,
      detectedAt: now,
    };
  }

  // Fallback — still try to extract owner/repo if possible
  const anyMatch = RE_REPO_ANY.exec(path);
  return {
    type: "other",
    url,
    owner: anyMatch?.[1] ?? null,
    repo: anyMatch?.[2] ?? null,
    prNumber: null,
    issueNumber: null,
    detectedAt: now,
  };
}

// ── State + subscribers ───────────────────────────────────────────────────────

let _current: PageContext = detect(); // initialised at import time
const _listeners = new Set<(ctx: PageContext) => void>();

/** Returns the most-recently detected PageContext synchronously. */
export function getCurrentContext(): PageContext {
  return _current;
}

/**
 * Subscribe to page-context changes.
 * Returns an unsubscribe function.
 */
export function onContextChange(
  fn: (ctx: PageContext) => void
): () => void {
  _listeners.add(fn);
  return () => _listeners.delete(fn);
}

// ── Debounced runner ──────────────────────────────────────────────────────────

const DEBOUNCE_MS = 150;
let _debounceTimer: ReturnType<typeof setTimeout> | null = null;

function scheduleDetection(source: string): void {
  if (_debounceTimer !== null) clearTimeout(_debounceTimer);
  _debounceTimer = setTimeout(() => {
    _debounceTimer = null;
    const ctx = detect();

    // Only update + notify when the URL actually changed (dedup same-page fires)
    if (ctx.url === _current.url && ctx.type === _current.type) return;

    _current = ctx;
    console.log(`[Athena] PageContext (${source}):`, ctx);

    for (const fn of _listeners) {
      try {
        fn(ctx);
      } catch (err) {
        console.error("[Athena] PageContext listener threw:", err);
      }
    }
  }, DEBOUNCE_MS);
}

// ── Public initialiser ────────────────────────────────────────────────────────

/**
 * Wire up all GitHub SPA navigation event listeners.
 * Safe to call multiple times — guards against double-init.
 */
let _initialised = false;

export function initContextInspector(): void {
  if (_initialised) return;
  _initialised = true;

  // Log the initial page load context immediately (no debounce needed)
  console.log("[Athena] PageContext (initial):", _current);

  // Turbo Drive (used since ~2022 on github.com)
  document.addEventListener("turbo:load",   () => scheduleDetection("turbo:load"));
  document.addEventListener("turbo:render", () => scheduleDetection("turbo:render"));

  // Older pjax navigation (still fired on some github.com pages)
  document.addEventListener("pjax:end",     () => scheduleDetection("pjax:end"));

  // Cover browser history restores and non-Turbo GitHub transitions too.
  window.addEventListener("popstate", () => scheduleDetection("popstate"));
  window.addEventListener("hashchange", () => scheduleDetection("hashchange"));
  window.addEventListener("pageshow", () => scheduleDetection("pageshow"));
}
