/**
 * Athena – deterministic rules engine.
 *
 * Each Rule describes:
 *  - id          : stable identifier stored in session log
 *  - actionType  : human-readable action label shown in the warning
 *  - severity    : "critical" | "danger" — controls banner color
 *  - match()     : given a candidate Element, returns true if it is a
 *                  dangerous button that Athena should intercept
 *  - consequence : one-line description shown to the user
 */

export type Severity = "critical" | "danger";

export interface Rule {
  id: string;
  actionType: string;
  severity: Severity;
  consequence: string;
  match(el: Element): boolean;
}

// ─── Helper: case-insensitive text content test ──────────────────────────────
function hasText(el: Element, ...phrases: string[]): boolean {
  const text = (el.textContent ?? "").trim().toLowerCase();
  return phrases.some((p) => text.includes(p.toLowerCase()));
}

// ─── Helper: button or button-like element ───────────────────────────────────
function isButton(el: Element): boolean {
  const tag = el.tagName.toLowerCase();
  return (
    tag === "button" ||
    (tag === "a" && el.getAttribute("role") === "button") ||
    (tag === "input" &&
      ["submit", "button"].includes(
        (el as HTMLInputElement).type?.toLowerCase()
      ))
  );
}

// ─── Rule definitions ────────────────────────────────────────────────────────

export const RULES: Rule[] = [
  // 1. Delete this repository
  {
    id: "delete-repository",
    actionType: "Delete Repository",
    severity: "critical",
    consequence:
      "Permanently deletes the repository, all its code, issues, pull requests, and history. This cannot be undone.",
    match(el) {
      if (!isButton(el)) return false;
      // Repository deletion is only offered from that repository's Settings > Danger Zone.
      // Keep similarly named delete controls elsewhere in GitHub untouched.
      const path = el.ownerDocument.defaultView?.location.pathname ?? "";
      if (!/^\/[^/]+\/[^/]+\/settings(?:\/|$)/.test(path)) return false;

      const buttonText = (el.textContent ?? "").replace(/\s+/g, " ").trim().toLowerCase();
      // Guard only the initial Danger Zone action. GitHub's own confirmation
      // dialog must remain fully native after Athena's Continue click.
      return buttonText === "delete this repository";
    },
  },

  // 2. Archive this repository
  {
    id: "archive-repository",
    actionType: "Archive Repository",
    severity: "danger",
    consequence:
      "Makes the repository read-only for everyone. Contributors will no longer be able to push code or open issues.",
    match(el) {
      if (!isButton(el)) return false;
      return hasText(el, "archive this repository");
    },
  },

  // 3. Transfer repository ownership
  {
    id: "transfer-ownership",
    actionType: "Transfer Repository Ownership",
    severity: "critical",
    consequence:
      "Transfers the repository to another user or organisation. You may lose admin access permanently.",
    match(el) {
      if (!isButton(el)) return false;
      return (
        hasText(el, "transfer") &&
        (hasText(el, "ownership") ||
          !!el.closest('[aria-label*="Transfer"]') ||
          !!el.closest('form[action*="transfer"]'))
      );
    },
  },

  // 4. Delete a branch
  {
    id: "delete-branch",
    actionType: "Delete Branch",
    severity: "danger",
    consequence:
      "Deletes the branch reference. Any unmerged commits on this branch will become unreachable.",
    match(el) {
      if (!isButton(el)) return false;
      // Branches list page – "Delete branch" button
      if (hasText(el, "delete branch")) return true;
      // PR page – "Delete branch" after merge
      if (
        hasText(el, "delete branch") &&
        !!el.closest(".merge-branch-successfully-merged")
      )
        return true;
      // Icon-only button with aria-label
      const label = (el.getAttribute("aria-label") ?? "").toLowerCase();
      if (label.includes("delete branch")) return true;
      return false;
    },
  },

  // 5. Abandon / discard a pull request
  {
    id: "close-pull-request",
    actionType: "Close Pull Request",
    severity: "danger",
    consequence:
      "Closes and discards the pull request. All review comments and change requests will be marked as outdated.",
    match(el) {
      if (!isButton(el)) return false;
      return (
        hasText(el, "close pull request") ||
        hasText(el, "abandon pull request")
      );
    },
  },
];
