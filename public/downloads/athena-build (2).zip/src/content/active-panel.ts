/**
 * Athena – Active Mode: LLM-powered floating panel.
 *
 * Architecture:
 *  - A Shadow DOM floating panel (fixed position, right side of viewport)
 *  - Triggered by floating action button (FAB) + Alt+A keyboard shortcut
 *  - On open, scrapes GitHub page context (PR title, diff summary,
 *    error messages, CI status, branch info) and feeds it to the LLM
 *    as a system message
 *  - User can ask questions; conversation is kept in module state (not
 *    persisted to storage — session only)
 *  - LLM settings (base URL + API key) are read through loadSettings/saveSettings
 *
 * The LLM endpoint must be OpenAI-compatible:
 *   POST {baseUrl}/chat/completions
 *   Authorization: Bearer {apiKey}
 */

import { isRestrictedPage } from "./restricted-pages";
import { getRecentActivity } from "./activity-tracker";
import { primerTokenStyles } from "../ui/tokens";
import { ATHENA_WARNING_SHOWN_EVENT } from "../ui/motion";
import { logActivity } from "../storage/session";

// ── Page context scraper ──────────────────────────────────────────────────────

interface PageContext {
  pageType: string;
  title: string;
  extracts: string[];
}

interface ProposedFixFile { path: string; patch: string; isNewFile: boolean }
interface SecretFinding { path: string; line: number; type: string; maskedPreview: "•••" }
interface ConflictHunk { id: string; path: string; mine: string[]; theirs: string[]; ancestor: string[]; context: string[] }
interface ConflictResolution { choice: "mine" | "theirs" | "both" | "edit"; text?: string }
interface ConflictSuggestion { resolved: string; explanation: string; confidence: "high" | "low" }
interface ConflictSuggestionState { phase: "consent" | "busy" | "suggested" | "error"; endpoint?: string; suggestion?: ConflictSuggestion; message?: string }
interface ConflictFlowState {
  phase: "gathering" | "first-confirm" | "resolve" | "previewing" | "second-confirm" | "ready";
  owner: string; repo: string; pullNumber: number; headRef: string; baseRef: string;
  hunks: ConflictHunk[]; resolutions: Record<string, ConflictResolution>; protectedPaths: string[];
  confirmedOnce: boolean; confirmedTwice: boolean;
}
interface PendingFix { summary: string; diff: string; files: ProposedFixFile[]; ciRequestId?: string; secretRequest?: { findings: SecretFinding[]; confirmWorkflow: boolean }; conflictRequest?: { resolutions: Record<string, ConflictResolution>; confirmedOnce: boolean; confirmedTwice: boolean } }
interface FixActionResponse { ok: boolean; message?: string; error?: string; url?: string }
let pendingFix: PendingFix | null = null;
let fixPreviewStatus = "";
let fixPreviewBusy = false;
let fixPreviewEl: HTMLDivElement | null = null;
let createFixButton: HTMLButtonElement | null = null;
let ciRequest: { checkName: string; id?: string; phase: "choice" | "consent" | "protected" | "busy"; protectedPaths?: string[] } | null = null;
let secretFindings: SecretFinding[] = [];
let secretFork = false;
let secretWorkflowConfirmation: SecretFinding[] | null = null;
let lastSecretScanPath = "";
let conflictFlow: ConflictFlowState | null = null;
let conflictSuggestions = new Map<string, ConflictSuggestionState>();
const SECRET_HISTORY_WARNING = "Removing a key from code does NOT remove it from git history. Revoke or rotate this key NOW. Consider git filter-repo or BFG to clean history.";
const SECRET_REVOKE_URLS: Record<string, string> = {
  "AWS Access Key ID": "https://console.aws.amazon.com/iam/home#/security_credentials",
  "GitHub Personal Access Token": "https://github.com/settings/tokens",
  "GitHub Fine-Grained PAT": "https://github.com/settings/personal-access-tokens",
  "Slack Token": "https://api.slack.com/apps", "Google API Key": "https://console.cloud.google.com/apis/credentials",
  "OpenAI API Key": "https://platform.openai.com/api-keys", "Stripe Secret Key": "https://dashboard.stripe.com/apikeys",
  "Stripe Publishable Key": "https://dashboard.stripe.com/apikeys",
};

function sendCiMessage(payload: Record<string, unknown>): Promise<any> {
  return new Promise((resolve, reject) => chrome.runtime.sendMessage(payload, (response: any) => {
    if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
    else if (!response) reject(new Error("No response from the extension worker."));
    else if (!response.ok) reject(new Error(response.error || "CI fix request failed."));
    else resolve(response);
  }));
}

async function loadPrSecretFindings(): Promise<void> {
  const match = window.location.pathname.match(/^\/([^/]+)\/([^/]+)\/pull\/(\d+)/);
  if (!match || lastSecretScanPath === window.location.pathname) return;
  lastSecretScanPath = window.location.pathname;
  try {
    const result = await sendCiMessage({ type: "ATHENA_SECRET_PR_SCAN", owner: match[1], repo: match[2], pullNumber: Number(match[3]) });
    secretFindings = Array.isArray(result.findings) ? result.findings : [];
    secretFork = !!result.fork;
    renderMessages();
  } catch (error) {
    state.messages.push({ role: "assistant", content: `Could not scan the added PR lines: ${error instanceof Error ? error.message : "GitHub request failed."}` });
    renderMessages();
  }
}

function renderSecretCards(): void {
  if (!messagesEl || !secretFindings.length) return;
  const groups = new Map<string, SecretFinding[]>();
  for (const finding of secretFindings) groups.set(finding.path, [...(groups.get(finding.path) ?? []), finding]);
  for (const items of groups.values()) {
    const group = document.createElement("div"); group.className = "msg assistant secret-pr-card";
    const title = document.createElement("div"); title.className = "msg-content";
    title.textContent = items.map(f => `Possible ${f.type} in ${f.path}:${f.line} ${f.maskedPreview}`).join("\n");
    group.appendChild(title);
    if (secretFork) {
      const note = document.createElement("div"); note.className = "fix-preview-status"; note.textContent = "I can't push to forks"; group.appendChild(note);
    } else {
      const actions = document.createElement("div"); actions.className = "fix-preview-actions";
      items.forEach(finding => {
        const button = document.createElement("button"); button.type = "button"; button.className = "fix-it-btn"; button.textContent = "Fix it for me";
        button.addEventListener("click", () => void requestSecretPreview([finding])); actions.appendChild(button);
      });
      if (items.length > 1) {
        const all = document.createElement("button"); all.type = "button"; all.className = "fix-it-btn"; all.textContent = "Fix all in this file";
        all.addEventListener("click", () => void requestSecretPreview(items)); actions.appendChild(all);
      }
      group.appendChild(actions);
    }
    messagesEl.appendChild(group);
  }
  if (secretWorkflowConfirmation) {
    const box = document.createElement("div"); box.className = "msg assistant";
    const text = document.createElement("div"); text.className = "msg-content"; text.textContent = `This fix touches ${[...new Set(secretWorkflowConfirmation.map(f=>f.path))].join(", ")} under .github/workflows/. Confirm to continue.`;
    const actions = document.createElement("div"); actions.className = "fix-preview-actions";
    const confirm = document.createElement("button"); confirm.className = "fix-it-btn"; confirm.textContent = "Confirm"; confirm.addEventListener("click", () => { const selected = secretWorkflowConfirmation!; secretWorkflowConfirmation = null; void requestSecretPreview(selected, true); });
    const cancel = document.createElement("button"); cancel.className = "fix-cancel-btn"; cancel.textContent = "Cancel"; cancel.addEventListener("click", () => { secretWorkflowConfirmation = null; renderMessages(); });
    actions.append(confirm, cancel); box.append(text, actions); messagesEl.appendChild(box);
  }
}

async function requestSecretPreview(findings: SecretFinding[], confirmWorkflow = false): Promise<void> {
  try {
    const repo = getCurrentRepo(); if (!repo) throw new Error("Open the pull request page to fix a finding.");
    const result = await sendCiMessage({ type: "ATHENA_SECRET_PR_PREVIEW", ...repo, secretFindings: findings, confirmWorkflow });
    if (result.confirmPaths?.length) { secretWorkflowConfirmation = findings; renderMessages(); return; }
    pendingFix = { summary: result.summary, diff: result.diff, files: [], secretRequest: { findings, confirmWorkflow } };
    fixPreviewStatus = result.reviewManually ? "Review manually before merging." : "Deterministic secret removal. Review before merging.";
    renderMessages();
  } catch (error) {
    state.messages.push({ role: "assistant", content: error instanceof Error ? error.message : "Could not prepare the secret fix." }); renderMessages();
  }
}

function invalidateConflictPreview(): void {
  if (!conflictFlow) return;
  pendingFix = null;
  fixPreviewStatus = "";
  conflictFlow.phase = "resolve";
  conflictFlow.confirmedTwice = false;
}

function renderConflictFlow(): void {
  if (!messagesEl || !conflictFlow) return;
  const flow = conflictFlow;
  const box = document.createElement("div"); box.className = "msg assistant";
  const heading = document.createElement("div"); heading.className = "msg-content";
  heading.textContent = flow.phase === "gathering" ? "Checking the two branch histories…" : `Resolve conflicts between ${flow.headRef} and ${flow.baseRef}.`;
  box.appendChild(heading);
  if (flow.phase === "first-confirm") {
    const note = document.createElement("div"); note.className = "fix-preview-status"; note.textContent = `This merge changes protected files: ${flow.protectedPaths.join(", ")}. Confirm once to continue.`; box.appendChild(note);
    const confirm = document.createElement("button"); confirm.className = "fix-it-btn"; confirm.textContent = "Confirm protected changes";
    confirm.addEventListener("click", () => { flow.confirmedOnce = true; flow.phase = "resolve"; renderMessages(); }); box.appendChild(confirm);
  } else if (flow.phase !== "gathering") {
    for (const hunk of flow.hunks) {
      const card = document.createElement("div"); card.className = "resolve-conflict-card";
      const title = document.createElement("div"); title.className = "resolve-conflict-title"; title.textContent = `${hunk.path} · conflict ${hunk.id.split("::").at(-1)}`; card.appendChild(title);
      const sides = document.createElement("div"); sides.className = "resolve-sides";
      for (const [label, text] of [["Mine", hunk.mine.join("\n")], ["Theirs", hunk.theirs.join("\n")]] as const) {
        const side = document.createElement("div"); side.className = "resolve-side";
        const sideTitle = document.createElement("div"); sideTitle.className = "resolve-side-label"; sideTitle.textContent = label;
        const pre = document.createElement("pre"); pre.textContent = text;
        side.append(sideTitle, pre); sides.appendChild(side);
      }
      card.appendChild(sides);
      const suggestionState = conflictSuggestions.get(hunk.id);
      if (suggestionState?.phase === "suggested" && suggestionState.suggestion) {
        const suggestionSide = document.createElement("div"); suggestionSide.className = "resolve-side resolve-suggestion";
        const suggestionTitle = document.createElement("div"); suggestionTitle.className = "resolve-side-label"; suggestionTitle.textContent = "AI suggestion";
        const suggestionText = document.createElement("pre"); suggestionText.textContent = suggestionState.suggestion.resolved;
        const explanation = document.createElement("div"); explanation.className = "fix-preview-status"; explanation.textContent = `${suggestionState.suggestion.explanation}${suggestionState.suggestion.confidence === "low" ? " — I'm not sure, please review carefully" : ""}`;
        const useSuggestion = document.createElement("button"); useSuggestion.className = "fix-it-btn"; useSuggestion.textContent = "Use suggestion";
        useSuggestion.addEventListener("click", () => { flow.resolutions[hunk.id] = { choice: "edit", text: suggestionState.suggestion!.resolved }; invalidateConflictPreview(); renderMessages(); });
        suggestionSide.append(suggestionTitle, suggestionText, explanation, useSuggestion); sides.appendChild(suggestionSide);
      }
      const selected = flow.resolutions[hunk.id];
      const actions = document.createElement("div"); actions.className = "fix-preview-actions";
      const choices: Array<[ConflictResolution["choice"], string]> = [["mine", "Keep mine"], ["theirs", "Keep theirs"], ["both", "Keep both"], ["edit", "Edit manually"]];
      for (const [choice, label] of choices) {
        const button = document.createElement("button"); button.className = "fix-it-btn"; button.type = "button"; button.textContent = selected?.choice === choice ? `✓ ${label}` : label;
        button.addEventListener("click", () => {
          if (choice === "edit") { flow.resolutions[hunk.id] = { choice: "edit", text: selected?.choice === "edit" ? selected.text : hunk.mine.join("\n") }; }
          else flow.resolutions[hunk.id] = { choice };
          invalidateConflictPreview(); renderMessages();
        }); actions.appendChild(button);
      }
      if (selected?.choice === "edit") {
        const textarea = document.createElement("textarea"); textarea.className = "resolve-edit"; textarea.setAttribute("aria-label", `Manual resolution for ${hunk.path}`); textarea.value = selected.text ?? "";
        textarea.addEventListener("input", () => { flow.resolutions[hunk.id] = { choice: "edit", text: textarea.value }; });
        const save = document.createElement("button"); save.className = "fix-it-btn"; save.textContent = "Use this edit"; save.addEventListener("click", () => { flow.resolutions[hunk.id] = { choice: "edit", text: textarea.value }; invalidateConflictPreview(); renderMessages(); });
        card.append(textarea, save);
      }
      const suggest = document.createElement("button"); suggest.className = "fix-it-btn"; suggest.type = "button";
      suggest.textContent = suggestionState?.phase === "busy" ? "Thinking…" : "AI suggestion";
      suggest.disabled = suggestionState?.phase === "busy";
      suggest.addEventListener("click", () => void requestConflictSuggestion(hunk));
      actions.appendChild(suggest);
      if (suggestionState?.phase === "consent") {
        const consent = document.createElement("div"); consent.className = "fix-preview-status"; consent.textContent = `This conflict hunk, its file name, and up to 10 surrounding lines will be sent to your configured endpoint (${suggestionState.endpoint}). Allow this one-time sharing?`;
        const allow = document.createElement("button"); allow.className = "fix-it-btn"; allow.textContent = "Allow"; allow.addEventListener("click", () => void requestConflictSuggestion(hunk, true));
        card.append(consent, allow);
      }
      if (suggestionState?.phase === "error" && suggestionState.message) { const error = document.createElement("div"); error.className = "fix-preview-status"; error.textContent = suggestionState.message; card.appendChild(error); }
      card.appendChild(actions); box.appendChild(card);
    }
    const allResolved = flow.hunks.every(hunk => !!flow.resolutions[hunk.id]);
    if (flow.phase === "second-confirm") {
      const note = document.createElement("div"); note.className = "fix-preview-status"; note.textContent = `Protected paths still included: ${flow.protectedPaths.join(", ")}. Confirm a second time before creating the PR.`; box.appendChild(note);
      const confirm = document.createElement("button"); confirm.className = "fix-it-btn"; confirm.textContent = "Confirm a second time";
      confirm.addEventListener("click", () => { flow.confirmedTwice = true; flow.phase = "ready"; if (pendingFix?.conflictRequest) pendingFix.conflictRequest.confirmedTwice = true; renderMessages(); renderFixPreview(); }); box.appendChild(confirm);
    } else if (allResolved && flow.phase === "resolve") {
      const preview = document.createElement("button"); preview.className = "fix-it-btn"; preview.textContent = "Preview merge"; preview.addEventListener("click", () => void previewConflictMerge()); box.appendChild(preview);
    } else if (flow.hunks.length === 0 && flow.phase === "resolve") {
      const preview = document.createElement("button"); preview.className = "fix-it-btn"; preview.textContent = "Preview merge"; preview.addEventListener("click", () => void previewConflictMerge()); box.appendChild(preview);
    }
  }
  messagesEl.appendChild(box);
}

async function startConflictResolution(): Promise<void> {
  if (conflictFlow?.phase === "gathering") return;
  const repo = getCurrentRepo();
  if (!repo) return;
  void openPanel();
  conflictFlow = { phase: "gathering", owner: repo.owner, repo: repo.name, pullNumber: repo.pullNumber, headRef: "", baseRef: "", hunks: [], resolutions: {}, protectedPaths: [], confirmedOnce: false, confirmedTwice: false };
  conflictSuggestions = new Map();
  pendingFix = null; renderMessages();
  try {
    const result = await sendCiMessage({ type: "ATHENA_CONFLICT_GATHER", owner: repo.owner, repo: repo.name, pullNumber: repo.pullNumber });
    if (result.blocked) {
      state.messages.push({ role: "assistant", content: result.blocked }); conflictFlow = null; renderMessages(); return;
    }
    conflictFlow.headRef = result.headRef; conflictFlow.baseRef = result.baseRef;
    conflictFlow.hunks = result.hunks ?? []; conflictFlow.protectedPaths = result.protectedPaths ?? [];
    conflictFlow.phase = conflictFlow.protectedPaths.length ? "first-confirm" : "resolve";
    renderMessages();
    if (!conflictFlow.hunks.length && !conflictFlow.protectedPaths.length) void previewConflictMerge();
  } catch (error) {
    state.messages.push({ role: "assistant", content: error instanceof Error ? error.message : "Could not gather conflict context." }); conflictFlow = null; renderMessages();
  }
}

async function requestConflictSuggestion(hunk: ConflictHunk, allowConsent = false): Promise<void> {
  if (!conflictFlow) return;
  conflictSuggestions.set(hunk.id, { phase: "busy" }); renderMessages();
  try {
    const result = await sendCiMessage({ type: "ATHENA_CONFLICT_SUGGEST", hunk: { path: hunk.path, mine: hunk.mine, theirs: hunk.theirs, ancestor: hunk.ancestor, context: hunk.context }, allowConsent });
    if (result.blocked) conflictSuggestions.set(hunk.id, { phase: "error", message: result.blocked });
    else if (result.needsConsent) conflictSuggestions.set(hunk.id, { phase: "consent", endpoint: result.endpoint });
    else if (result.suggestion) conflictSuggestions.set(hunk.id, { phase: "suggested", suggestion: result.suggestion });
    else conflictSuggestions.set(hunk.id, { phase: "error", message: "The AI did not return a suggestion." });
  } catch (error) {
    conflictSuggestions.set(hunk.id, { phase: "error", message: error instanceof Error ? error.message : "Could not get an AI suggestion." });
  }
  renderMessages();
}

async function previewConflictMerge(): Promise<void> {
  if (!conflictFlow) return;
  const flow = conflictFlow; flow.phase = "previewing"; renderMessages();
  try {
    const result = await sendCiMessage({ type: "ATHENA_CONFLICT_PREVIEW", owner: flow.owner, repo: flow.repo, pullNumber: flow.pullNumber, resolutions: flow.resolutions, confirmProtectedOnce: flow.confirmedOnce });
    if (result.confirmPaths?.length) { flow.protectedPaths = result.confirmPaths; flow.phase = "first-confirm"; renderMessages(); return; }
    flow.protectedPaths = result.protectedPaths ?? flow.protectedPaths;
    pendingFix = { summary: result.summary, diff: result.diff, files: [], conflictRequest: { resolutions: flow.resolutions, confirmedOnce: flow.confirmedOnce, confirmedTwice: flow.confirmedTwice } };
    fixPreviewStatus = "Final merge result. Review before creating the PR.";
    flow.phase = flow.protectedPaths.length ? "second-confirm" : "ready";
    renderMessages(); renderFixPreview();
  } catch (error) {
    flow.phase = "resolve"; state.messages.push({ role: "assistant", content: error instanceof Error ? error.message : "Could not preview the merge." }); renderMessages();
  }
}

function renderCiPrompt(): void {
  if (!messagesEl || !ciRequest || ciRequest.phase === "busy") return;
  const box = document.createElement("div"); box.className = "msg assistant";
  const content = document.createElement("div"); content.className = "msg-content";
  content.textContent = ciRequest.phase === "choice" ? `A check is failing: ${ciRequest.checkName}. Want me to try to fix it?` :
    ciRequest.phase === "consent" ? `This log and these files (${ciRequest.protectedPaths?.join(", ") || "fetched CI context"}) will be sent to your configured AI endpoint. Allow Athena to continue?` :
    `This fix changes protected files: ${ciRequest.protectedPaths?.join(", ")}. Confirm again to continue.`;
  const actions = document.createElement("div"); actions.className = "fix-preview-actions";
  const yes = document.createElement("button"); yes.className = "fix-it-btn"; yes.textContent = ciRequest.phase === "choice" ? "Yes" : ciRequest.phase === "consent" ? "Allow" : "Confirm";
  const no = document.createElement("button"); no.className = "fix-cancel-btn"; no.textContent = ciRequest.phase === "choice" ? "No" : "Cancel";
  yes.addEventListener("click", () => void handleCiApproval());
  no.addEventListener("click", () => {
    const requestId = ciRequest?.id;
    ciRequest = null; renderMessages();
    if (requestId) void sendCiMessage({ type: "ATHENA_CI_FIX_CANCEL", requestId }).catch(() => undefined);
  });
  actions.append(yes, no); box.append(content, actions); messagesEl.appendChild(box);
}

async function handleCiApproval(): Promise<void> {
  if (!ciRequest) return;
  try {
    if (ciRequest.phase === "choice") {
      ciRequest.phase = "busy"; renderMessages();
      const repo = getCurrentRepo(); if (!repo) throw new Error("Open the pull request page to request a CI fix.");
      const gathered = await sendCiMessage({ type: "ATHENA_CI_FIX_GATHER", ...repo });
      if (gathered.blocked) { state.messages.push({ role: "assistant", content: gathered.blocked }); ciRequest = null; renderMessages(); return; }
      ciRequest.id = gathered.id; ciRequest.phase = "consent"; ciRequest.protectedPaths = gathered.files;
      state.messages.push({ role: "assistant", content: `I found the failing check and ${gathered.files.length} relevant file${gathered.files.length === 1 ? "" : "s"}.` });
      renderMessages(); return;
    }
    if (!ciRequest.id) throw new Error("CI fix request expired. Start again from the prompt.");
    const wasProtected = ciRequest.phase === "protected";
    if (ciRequest.phase === "consent") ciRequest.phase = "busy";
    const result = await sendCiMessage({ type: "ATHENA_CI_FIX_PROPOSE", requestId: ciRequest.id, confirmProtected: wasProtected });
    if (result.confirmPaths?.length) { ciRequest.phase = "protected"; ciRequest.protectedPaths = result.confirmPaths; renderMessages(); return; }
    pendingFix = { summary: result.summary, diff: result.diff, files: result.files, ciRequestId: ciRequest.id };
    fixPreviewStatus = "AI-generated, review before merging. Nothing is written until you create the PR.";
    ciRequest = null; renderMessages();
  } catch (error) {
    state.messages.push({ role: "assistant", content: error instanceof Error ? error.message : "Could not prepare a CI fix." });
    ciRequest = null; renderMessages();
  }
}

function scrapePageContext(includeDiff = false): PageContext {
  const url = window.location.pathname;
  const extracts: string[] = [];

  // Common: page title
  const h1 = document.querySelector("h1.gh-header-title, h1.js-issue-title");
  const title = (h1?.textContent ?? document.title).trim().slice(0, 200);

  // PR page
  if (url.match(/\/pull\/\d+/)) {
    // PR description
    const body = document.querySelector(".comment-body p");
    if (body) extracts.push("PR Description: " + body.textContent?.slice(0, 400));

    // Branch names
    const base = document.querySelector(".base-ref")?.textContent?.trim();
    const head = document.querySelector(".head-ref")?.textContent?.trim();
    if (base && head)
      extracts.push(`Branches: ${head} → ${base}`);

    // CI status
    const checks = document.querySelectorAll(".merge-status-item");
    checks.forEach((c) => {
      const text = c.textContent?.trim().slice(0, 120);
      if (text) extracts.push("CI Check: " + text);
    });

    // Files changed count
    const filesTab = document.querySelector("#files_tab .counter");
    if (filesTab)
      extracts.push("Files changed: " + filesTab.textContent?.trim());

    if (includeDiff) {
      const fileBlocks = Array.from(document.querySelectorAll<HTMLElement>(".js-file, .file"));
      const renderedDiff = fileBlocks.map((file) => {
        const path = file.dataset.tagsearchPath
          || file.querySelector<HTMLElement>(".file-info a[title], .file-header .Truncate-text")?.getAttribute("title")
          || file.querySelector(".file-info")?.textContent?.trim()
          || "unknown file";
        const rows = Array.from(file.querySelectorAll<HTMLElement>(".blob-code-inner"));
        const lines = rows.map((node) => {
          const row = node.closest("tr");
          const marker = row?.classList.contains("blob-code-addition") || row?.querySelector(".blob-code-addition") ? "+"
            : row?.classList.contains("blob-code-deletion") || row?.querySelector(".blob-code-deletion") ? "-" : " ";
          return marker + (node.textContent ?? "");
        });
        return `File: ${path}\n${lines.join("\n")}`;
      }).filter((block) => block.length > 6).join("\n\n").slice(0, 12000);
      if (renderedDiff) extracts.push("Visible pull request diff (may be partial):\n" + renderedDiff);
    }

    return { pageType: "Pull Request", title, extracts };
  }

  // Repository page
  if (url.match(/^\/[^/]+\/[^/]+\/?$/)) {
    const readme = document.querySelector("#readme article");
    if (readme)
      extracts.push("README (excerpt): " + readme.textContent?.slice(0, 600));
    return { pageType: "Repository", title, extracts };
  }

  // Issue page
  if (url.match(/\/issues\/\d+/)) {
    const issueBody = document.querySelector(".comment-body");
    if (issueBody)
      extracts.push("Issue body: " + issueBody.textContent?.slice(0, 500));
    return { pageType: "Issue", title, extracts };
  }

  // Commit page
  if (url.match(/\/commit\//)) {
    const commitMsg = document.querySelector(".commit-title");
    if (commitMsg)
      extracts.push("Commit message: " + commitMsg.textContent?.trim());
    const diffStats = document.querySelector(".diffstat");
    if (diffStats)
      extracts.push("Diff stats: " + diffStats.textContent?.trim());
    return { pageType: "Commit", title, extracts };
  }

  return { pageType: "GitHub page", title, extracts };
}

function buildSystemPrompt(ctx: PageContext): string {
  const recentActivity = getRecentActivity().slice(-8);
  return [
    `You are Athena, a proactive safety and learning assistant embedded inside GitHub.`,
    `You help developers understand what they're looking at and avoid mistakes.`,
    ``,
    `Current page context:`,
    `- Page type: ${ctx.pageType}`,
    `- Title: ${ctx.title}`,
    `- URL: ${window.location.href}`,
    ...(ctx.extracts.length ? [``, `Extracted context:`, ...ctx.extracts.map((e) => `  • ${e}`)] : []),
    ...(recentActivity.length ? [
      ``,
      `Recent GitHub activity from this page session (short control labels only; typed text is not collected):`,
      ...recentActivity.map((entry) => `  • ${new Date(entry.at).toLocaleTimeString()} — ${entry.page}: ${entry.action}`),
      `Use this trail to offer relevant next steps when useful. Do not claim to know actions outside this list.`,
    ] : []),
    ``,
    `Answer concisely and helpfully. If the user asks about something not visible in the page context, say so honestly.`,
    `When asked to propose a code fix, do not claim to apply it. Return a brief one-line summary followed by exactly one fenced diff block marked diff. Include a standard unified diff for each changed file (diff --git, ---/+++, and valid @@ hunks). Only use files and context visible in this pull request; do not invent file contents. Do not include secrets.`,
  ].join("\n");
}

// ── Chat types & Background client ───────────────────────────────────────────

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export async function dispatchChatViaBackground(
  messages: ChatMessage[]
): Promise<string> {
  type BgResponse =
    | { ok: true; explanation?: string; reply?: string }
    | { ok: false; error: string };

  const response = await new Promise<BgResponse>((resolve, reject) => {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) {
      reject(new Error("Extension runtime not available."));
      return;
    }
    chrome.runtime.sendMessage(
      { type: "ATHENA_CHAT_REQUEST", messages },
      (resp: BgResponse | undefined) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message ?? "Background message failed"));
          return;
        }
        if (!resp) {
          reject(new Error("No response received from Athena background worker."));
          return;
        }
        resolve(resp);
      }
    );
  });

  if (!response.ok) {
    throw new Error(response.error);
  }
  return response.reply ?? response.explanation ?? "(no response)";
}

// ── Panel CSS (Shadow DOM) ────────────────────────────────────────────────────
const PANEL_CSS = `
  :host {
    position: fixed;
    right: 0;
    top: 0;
    height: 100vh;
    width: 400px;
    max-width: 90vw;
    z-index: 2147483646;
    display: flex;
    align-items: stretch;
    pointer-events: none;
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }

  .panel {
    pointer-events: none;
    position: fixed;
    right: 20px;
    bottom: 20px;
    width: min(400px, calc(100vw - 24px), calc(100vh - 32px));
    height: auto;
    min-width: min(280px, calc(100vw - 24px));
    min-height: min(300px, calc(100vh - 32px));
    max-width: calc(100vw - 24px);
    max-height: calc(100vh - 32px);
    aspect-ratio: 1 / 1;
    overflow: hidden;
    background: var(--bg-subtle);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    border: 1px solid var(--border);
    border-radius: 12px;
    display: flex;
    flex-direction: column;
    transform: translateY(8px);
    opacity: 0;
    box-shadow: -12px 0 36px rgba(0, 0, 0, 0.42);
    background-image: linear-gradient(to right, rgba(255, 255, 255, 0.018) 1px, transparent 1px), linear-gradient(to bottom, rgba(255, 255, 255, 0.018) 1px, transparent 1px);
    background-size: 24px 24px;
    transition: transform 200ms cubic-bezier(0.2, 0, 0, 1), opacity 200ms ease, box-shadow 200ms ease;
  }

  .panel.open {
    transform: translateY(0);
    opacity: 1;
    pointer-events: auto;
  }

  /* Header */
  .panel-header {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 14px 18px;
    border-bottom: 1px solid var(--border-soft);
    background: var(--bg-canvas);
    flex-shrink: 0;
  }

  .panel-icon-wrap {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    background: var(--bg-subtle);
    border: 1px solid var(--accent-subtle);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    box-shadow: 0 0 8px var(--color-cyan-glow);
    flex-shrink: 0;
  }

  .panel-title {
    font-size: 14px;
    font-weight: 700;
    color: var(--fg);
    letter-spacing: -0.01em;
    display: flex;
    align-items: center;
    gap: 6px;
  }

  .panel-status-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--accent);
    box-shadow: 0 0 5px var(--color-cyan-glow);
    animation: athena-live-pulse 2s ease-in-out infinite;
  }

  .panel-subtitle {
    font-size: 10.5px;
    color: var(--fg-muted);
    margin-top: 1px;
  }

  .panel-close {
    background: var(--border-soft);
    border: 1px solid var(--border-soft);
    cursor: pointer;
    color: var(--fg-muted);
    font-size: 14px;
    width: 26px;
    height: 26px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 6px;
  }

  .panel-close:hover {
    color: var(--fg);
    background: var(--border-soft);
    border-color: var(--border-soft);
  }

  .panel-close:focus-visible {
    outline: 2px solid var(--accent);
    outline-offset: 2px;
  }

  /* Context strip */
  .ctx-strip {
    padding: 10px 18px;
    border-bottom: 1px solid var(--border-soft);
    flex-shrink: 0;
    background: var(--bg-subtle);
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .ctx-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .ctx-label {
    font-size: 9.5px;
    font-weight: 700;
    color: var(--accent);
    text-transform: uppercase;
    letter-spacing: 0.08em;
  }

  .ctx-badge {
    font-size: 9.5px;
    font-weight: 600;
    color: var(--fg-muted);
    background: var(--border-soft);
    padding: 1px 6px;
    border-radius: 4px;
    border: 1px solid var(--border-soft);
    font-family: var(--font-mono);
    transition: border-color 200ms ease, box-shadow 200ms ease;
  }

  .ctx-badge:hover {
    border-color: var(--accent);
    box-shadow: 0 0 7px var(--color-cyan-glow);
  }

  .ctx-title {
    font-size: 11.5px;
    color: var(--fg-muted);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: var(--font-mono);
  }

  /* Messages */
  .messages {
    flex: 1;
    overflow-y: auto;
    padding: 16px 18px;
    display: flex;
    flex-direction: column;
    gap: 14px;
    scrollbar-width: thin;
    scrollbar-color: var(--border-soft) transparent;
  }

  .messages::-webkit-scrollbar {
    width: 6px;
  }

  .messages::-webkit-scrollbar-thumb {
    background: var(--border-soft);
    border-radius: 999px;
  }

  .msg {
    display: flex;
    flex-direction: column;
    gap: 4px;
    animation: athena-message-in 200ms cubic-bezier(0.2, 0, 0, 1) both;
  }

  .msg-role {
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    display: flex;
    align-items: center;
    gap: 5px;
  }

  .msg-brand-logo { width: 14px; height: 14px; object-fit: contain; }

  .msg.user .msg-role { color: var(--accent); }
  .msg.assistant .msg-role { color: var(--success); }

  .msg-content {
    font-size: 12.5px;
    line-height: 1.6;
    white-space: pre-wrap;
    word-break: break-word;
    border-radius: 10px;
    padding: 10px 14px;
  }

  .msg.user .msg-content {
    background: var(--bg-subtle);
    border: 1px solid var(--accent-subtle);
    color: var(--fg);
  }

  .msg.assistant .msg-content {
    background: var(--bg-subtle);
    border: 1px solid var(--border-soft);
    color: var(--fg-muted);
  }

  /* Thinking wave */
  .thinking {
    position: relative;
    overflow: hidden;
    font-size: 12px;
    color: var(--accent);
    background: var(--accent-subtle);
    border: 1px solid var(--accent-subtle);
    border-radius: 10px;
    padding: 10px 14px;
    display: flex;
    align-items: center;
    gap: 8px;
    animation: athena-thinking-glow 2s ease-in-out infinite;
  }

  .thinking::after {
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    width: 24%;
    height: 1px;
    background: linear-gradient(90deg, transparent, var(--accent), transparent);
    opacity: .55;
    pointer-events: none;
    animation: athena-scanline 1800ms linear infinite;
  }

  .thinking-dots {
    display: inline-flex;
    gap: 4px;
  }

  .thinking-dot {
    width: 5px;
    height: 5px;
    border-radius: 50%;
    background: var(--accent);
  }

  /* Input row */
  .input-row {
    display: flex;
    gap: 8px;
    padding: 14px 18px;
    border-top: 1px solid var(--border-soft);
    background: var(--bg-subtle);
    flex-shrink: 0;
  }

  .chat-input {
    flex: 1;
    background: var(--bg-subtle);
    border: 1px solid var(--border-soft);
    border-radius: 8px;
    padding: 8px 12px;
    font-size: 12.5px;
    color: var(--fg);
    resize: none;
    height: 38px;
    max-height: 120px;
    outline: none;
    font-family: inherit;
    line-height: 1.4;
    overflow-y: auto;
  }

  .chat-input:focus {
    border-color: var(--accent);
    box-shadow: 0 0 0 2px var(--accent-subtle);
    transition: border-color 0.2s ease, box-shadow 0.2s ease;
  }

  .chat-input::placeholder { color: var(--fg-subtle); }

  .send-btn {
    background: var(--success-emphasis);
    border: 1px solid var(--border-soft);
    border-radius: 8px;
    padding: 0 16px;
    font-size: 12px;
    font-weight: 600;
    color: var(--fg);
    cursor: pointer;
    flex-shrink: 0;
    box-shadow: 0 2px 8px var(--accent-subtle);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: filter 180ms ease, box-shadow 180ms ease, background-color 180ms ease, border-color 180ms ease;
  }

  .send-btn:hover:not(:disabled) {
    background: var(--success);
    box-shadow: 0 4px 12px var(--accent-subtle);
    filter: brightness(1.08);
  }

  .send-btn:active:not(:disabled) { filter: brightness(0.96); }

  .send-btn:focus-visible {
    outline: 2px solid var(--accent);
    outline-offset: 2px;
  }

  .send-btn:disabled {
    background: var(--border-soft);
    border-color: var(--border-soft);
    color: var(--fg-subtle);
    box-shadow: none;
    cursor: not-allowed;
  }

  .fix-preview {
    flex-shrink: 0;
    margin: 0 14px 10px;
    padding: 12px;
    border: 1px solid var(--border);
    border-radius: 10px;
    background: var(--bg-canvas);
    box-shadow: 0 0 14px var(--accent-subtle);
  }
  .fix-preview[hidden] { display: none; }
  .fix-preview-title { color: var(--fg); font-size: 12px; font-weight: 700; margin-bottom: 8px; }
  .fix-preview-diff {
    max-height: 190px; overflow: auto; margin: 0; padding: 9px;
    border: 1px solid var(--border-soft); border-radius: 7px;
    background: var(--bg-subtle); color: var(--fg-muted);
    font: 10px/1.5 ui-monospace, SFMono-Regular, Consolas, monospace;
    white-space: pre; scrollbar-width: thin;
  }
  .fix-preview-actions { display: flex; align-items: center; gap: 8px; margin-top: 9px; }
  .fix-preview-status { flex: 1; min-width: 0; color: var(--fg-muted); font-size: 10px; overflow-wrap: anywhere; }
  .fix-create-btn { min-height: 30px; padding: 0 11px; }
  .fix-cancel-btn, .fix-it-btn {
    min-height: 30px; padding: 0 10px; border: 1px solid var(--border-soft);
    border-radius: 7px; background: var(--bg-subtle); color: var(--fg);
    font: 600 11px system-ui, sans-serif; cursor: pointer;
  }
  .fix-it-btn { flex-shrink: 0; }
  .fix-cancel-btn:disabled { opacity: .6; cursor: wait; }
  .resolve-conflict-card { margin: 8px 0; padding: 10px; border: 1px solid var(--border-soft); border-radius: 8px; background: var(--bg-canvas); }
  .resolve-conflict-title { color: var(--fg); font-size: 11px; font-weight: 700; margin-bottom: 7px; overflow-wrap: anywhere; }
  .resolve-sides { display: grid; grid-template-columns: 1fr 1fr; gap: 7px; }
  .resolve-side { min-width: 0; border: 1px solid var(--border-soft); border-radius: 6px; padding: 7px; }
  .resolve-suggestion { grid-column: 1 / -1; }
  .resolve-side-label { font-size: 10px; font-weight: 700; color: var(--fg-muted); margin-bottom: 5px; }
  .resolve-side pre { max-height: 140px; overflow: auto; white-space: pre-wrap; overflow-wrap: anywhere; margin: 0; font: 10px/1.4 ui-monospace, monospace; }
  .resolve-edit { width: 100%; min-height: 70px; box-sizing: border-box; margin-top: 7px; background: var(--bg-subtle); color: var(--fg); border: 1px solid var(--border-soft); border-radius: 6px; font: 10px/1.4 ui-monospace, monospace; }

  .panel {
    border: 1px solid var(--border);
    border-radius: 12px;
    background: var(--bg-canvas);
    box-shadow: var(--shadow);
  }

  .panel-header,
  .ctx-strip,
  .input-row {
    border-color: var(--border-muted);
    background: var(--bg-canvas);
  }

  .panel-header { padding: 16px; cursor: grab; touch-action: none; user-select: none; }
  .panel-header:active { cursor: grabbing; }

  .panel-resize-handle {
    position: absolute;
    right: 3px;
    bottom: 3px;
    z-index: 2;
    width: 18px;
    height: 18px;
    border-radius: 0 0 8px 0;
    background: linear-gradient(135deg, transparent 44%, var(--fg-subtle) 47% 51%, transparent 54% 64%, var(--fg-subtle) 67% 71%, transparent 74% 84%, var(--fg-subtle) 87% 91%, transparent 94%);
    opacity: 0.65;
    cursor: nwse-resize;
    touch-action: none;
  }
  .panel-resize-handle:hover { opacity: 1; }

  .panel-icon-wrap {
    border: 1px solid var(--border);
    border-radius: 6px;
    background: var(--bg-subtle);
    box-shadow: none;
  }

  .panel-icon-wrap img { width: 24px; height: 24px; object-fit: contain; }

  .ctx-badge {
    border-color: var(--border);
    border-radius: 2em;
    background: transparent;
  }

  .messages { padding: 16px; }

  .msg.user { align-items: flex-end; }
  .msg.user .msg-content {
    max-width: 88%;
    border: 1px solid var(--accent-emphasis);
    border-radius: 12px 12px 2px 12px;
    background: var(--accent-emphasis);
    color: var(--on-emphasis);
  }
  .msg.assistant .msg-content {
    align-self: flex-start;
    border: 1px solid var(--border);
    border-radius: 12px 12px 12px 2px;
    background: var(--bg-subtle);
    color: var(--fg);
  }

  .thinking {
    border: 1px solid var(--border);
    border-radius: 6px;
    background: var(--bg-subtle);
    color: var(--accent);
  }

  .chat-input {
    min-width: 0;
    border: 1px solid var(--border);
    border-radius: 6px;
    background: var(--bg-inset);
    color: var(--fg);
  }

  .chat-input:focus {
    border-color: var(--accent);
    box-shadow: 0 0 0 2px var(--accent-subtle);
  }

  .send-btn {
    border: 1px solid var(--success-emphasis);
    border-radius: 6px;
    background: var(--success-emphasis);
    color: var(--on-emphasis);
    box-shadow: none;
  }

  .send-btn:hover:not(:disabled) {
    border-color: var(--success);
    background: var(--success);
    box-shadow: none;
  }

  @keyframes athena-live-pulse { 0%, 100% { opacity: 1; box-shadow: 0 0 5px rgba(0,240,255,.25); } 50% { opacity: .75; box-shadow: 0 0 7px rgba(0,240,255,.4); } }
  @keyframes athena-message-in { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }
  @keyframes athena-thinking-glow {
    0%, 100% { border-color: var(--accent-subtle); box-shadow: 0 0 0 rgba(0, 240, 255, 0); }
    50% { border-color: rgba(0,240,255,.25); box-shadow: 0 0 4px var(--color-cyan-glow); }
  }
  @keyframes athena-scanline {
    from { transform: translateX(-110%); }
    to { transform: translateX(520%); }
  }
  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after { animation:none !important; transition:none !important; scroll-behavior:auto !important; }
  }
`;

const PANEL_POSITION_KEY = "athena-chat-position";

function constrainPanelPosition(x: number, y: number): { x: number; y: number } {
  if (!panelEl) return { x, y };
  const maxX = Math.max(0, window.innerWidth - panelEl.offsetWidth);
  const maxY = Math.max(0, window.innerHeight - panelEl.offsetHeight);
  return {
    x: Math.min(maxX, Math.max(0, x)),
    y: Math.min(maxY, Math.max(0, y)),
  };
}

function setPanelPosition(x: number, y: number): { x: number; y: number } {
  if (!panelEl) return { x, y };
  const position = constrainPanelPosition(x, y);
  panelEl.style.left = `${position.x}px`;
  panelEl.style.top = `${position.y}px`;
  panelEl.style.right = "auto";
  panelEl.style.bottom = "auto";
  return position;
}

function setPanelSize(width: number, height: number): { width: number; height: number } {
  if (!panelEl) return { width, height };
  const rect = panelEl.getBoundingClientRect();
  const left = panelEl.style.left ? Number.parseFloat(panelEl.style.left) : rect.left;
  const top = panelEl.style.top ? Number.parseFloat(panelEl.style.top) : window.innerHeight - panelEl.offsetHeight - 20;
  const maxWidth = Math.max(1, panelEl.style.left ? window.innerWidth - Math.max(0, left) - 8 : window.innerWidth - 32);
  const maxHeight = Math.max(1, panelEl.style.top ? window.innerHeight - Math.max(0, top) - 8 : window.innerHeight - 32);
  const minWidth = Math.min(280, maxWidth);
  const minHeight = Math.min(300, maxHeight);
  const size = {
    width: Math.min(maxWidth, Math.max(minWidth, width)),
    height: Math.min(maxHeight, Math.max(minHeight, height)),
  };
  panelEl.style.width = `${size.width}px`;
  panelEl.style.height = `${size.height}px`;
  panelEl.style.aspectRatio = "auto";
  return size;
}

function restorePanelPosition(): void {
  chrome.storage.local.get(PANEL_POSITION_KEY, (values) => {
    const saved = values[PANEL_POSITION_KEY] as { x?: unknown; y?: unknown; width?: unknown; height?: unknown } | undefined;
    if (typeof saved?.width === "number" && typeof saved.height === "number") setPanelSize(saved.width, saved.height);
    if (typeof saved?.x === "number" && typeof saved.y === "number") setPanelPosition(saved.x, saved.y);
  });
}

function enablePanelResizing(handle: HTMLElement): void {
  let resize: { pointerId: number; startX: number; startY: number; width: number; height: number } | null = null;

  handle.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || !panelEl) return;
    const rect = panelEl.getBoundingClientRect();
    panelEl.style.left = `${rect.left}px`;
    panelEl.style.top = `${rect.top}px`;
    panelEl.style.right = "auto";
    panelEl.style.bottom = "auto";
    resize = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      width: panelEl.offsetWidth,
      height: panelEl.offsetHeight,
    };
    handle.setPointerCapture(event.pointerId);
    event.preventDefault();
    event.stopPropagation();
  });

  handle.addEventListener("pointermove", (event) => {
    if (!resize || event.pointerId !== resize.pointerId || !panelEl) return;
    panelEl.style.transition = "none";
    setPanelSize(resize.width + event.clientX - resize.startX, resize.height + event.clientY - resize.startY);
    event.preventDefault();
  });

  const finishResize = (event: PointerEvent) => {
    if (!resize || event.pointerId !== resize.pointerId || !panelEl) return;
    resize = null;
    panelEl.style.transition = "";
    const rect = panelEl.getBoundingClientRect();
    chrome.storage.local.set({ [PANEL_POSITION_KEY]: { x: rect.left, y: rect.top, width: rect.width, height: rect.height } });
    if (handle.hasPointerCapture(event.pointerId)) handle.releasePointerCapture(event.pointerId);
  };

  handle.addEventListener("pointerup", finishResize);
  handle.addEventListener("pointercancel", finishResize);
}

function enablePanelDragging(handle: HTMLElement): void {
  let drag: { pointerId: number; startX: number; startY: number; originX: number; originY: number; moved: boolean } | null = null;

  handle.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || !panelEl || (event.target instanceof Element && event.target.closest("button"))) return;
    const rect = panelEl.getBoundingClientRect();
    drag = { pointerId: event.pointerId, startX: event.clientX, startY: event.clientY, originX: rect.left, originY: rect.top, moved: false };
    handle.setPointerCapture(event.pointerId);
    event.preventDefault();
  });

  handle.addEventListener("pointermove", (event) => {
    if (!drag || event.pointerId !== drag.pointerId) return;
    const dx = event.clientX - drag.startX;
    const dy = event.clientY - drag.startY;
    if (Math.abs(dx) + Math.abs(dy) > 3) drag.moved = true;
    if (!drag.moved) return;
    if (panelEl) panelEl.style.transition = "none";
    setPanelPosition(drag.originX + dx, drag.originY + dy);
    event.preventDefault();
  });

  const finishDrag = (event: PointerEvent) => {
    if (!drag || event.pointerId !== drag.pointerId) return;
    const completed = drag;
    drag = null;
    if (panelEl) panelEl.style.transition = "";
    if (completed.moved && panelEl) {
      const rect = panelEl.getBoundingClientRect();
      chrome.storage.local.set({ [PANEL_POSITION_KEY]: { x: rect.left, y: rect.top, width: rect.width, height: rect.height } });
    }
    if (handle.hasPointerCapture(event.pointerId)) handle.releasePointerCapture(event.pointerId);
  };

  handle.addEventListener("pointerup", finishDrag);
  handle.addEventListener("pointercancel", finishDrag);
}

// ── FAB CSS ───────────────────────────────────────────────────────────────────
const FAB_CSS = `
  :host {
    position: fixed;
    right: 20px;
    bottom: 24px;
    z-index: 2147483645;
    pointer-events: auto;
    font-family: var(--font-sans);
  }

  .fab {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: var(--bg-subtle);
    border: 1px solid var(--border);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0;
    box-shadow: var(--shadow);
    color: var(--fg);
    line-height: 1;
  }

  .fab:focus-visible {
    outline: 2px solid var(--accent);
    outline-offset: 2px;
  }

  .fab-tooltip {
    position: absolute;
    right: 58px;
    bottom: 12px;
    background: var(--bg-subtle);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 6px 12px;
    font-size: 11px;
    color: var(--fg-muted);
    box-shadow: var(--shadow);
    white-space: nowrap;
    pointer-events: none;
    opacity: 0;
    transform: translateX(6px);
  }

  :host(:hover) .fab-tooltip {
    opacity: 1;
    transform: translateX(0);
  }
`;

// ── Panel state ───────────────────────────────────────────────────────────────
interface State {
  isOpen: boolean;
  messages: { role: "user" | "assistant"; content: string }[];
  systemPrompt: string | null;
  loading: boolean;
}

const state: State = {
  isOpen: false,
  messages: [],
  systemPrompt: null,
  loading: false,
};

// ── Panel DOM references ──────────────────────────────────────────────────────
let panelHost: HTMLDivElement | null = null;
let fabHost: HTMLDivElement | null = null;
let panelShadow: ShadowRoot | null = null;
let panelEl: HTMLDivElement | null = null;
let messagesEl: HTMLDivElement | null = null;
let inputEl: HTMLTextAreaElement | null = null;
let sendBtnEl: HTMLButtonElement | null = null;
let ctxTitleEl: HTMLDivElement | null = null;

function scrollMessagesToBottom() {
  if (messagesEl) messagesEl.scrollTop = messagesEl.scrollHeight;
}

function renderMessages() {
  if (!messagesEl || !panelShadow) return;

  // Clear all message nodes
  const existing = panelShadow.querySelectorAll(".msg, .thinking");
  existing.forEach((el) => el.remove());

  for (const msg of state.messages) {
    const div = document.createElement("div");
    div.className = `msg ${msg.role}`;

    const role = document.createElement("div");
    role.className = "msg-role";
    if (msg.role === "assistant") {
      const logo = document.createElement("img");
      logo.className = "msg-brand-logo";
      logo.src = chrome.runtime.getURL("icons/athena-32.png");
      logo.alt = "";
      logo.setAttribute("aria-hidden", "true");
      role.appendChild(logo);
    }
    role.appendChild(document.createTextNode(msg.role === "user" ? "You" : "Athena"));

    const content = document.createElement("div");
    content.className = "msg-content";
    content.textContent = msg.content;

    div.appendChild(role);
    div.appendChild(content);
    messagesEl.appendChild(div);
  }

  if (state.loading) {
    const thinking = document.createElement("div");
    thinking.className = "thinking";

    const dotsWrap = document.createElement("span");
    dotsWrap.className = "thinking-dots";
    for (let i = 0; i < 3; i++) {
      const dot = document.createElement("span");
      dot.className = "thinking-dot";
      dotsWrap.appendChild(dot);
    }

    thinking.appendChild(dotsWrap);
    messagesEl.appendChild(thinking);
  }

  renderFixPreview();
  renderSecretCards();
  renderConflictFlow();
  renderCiPrompt();

  scrollMessagesToBottom();
}

function setInputEnabled(enabled: boolean) {
  if (inputEl) inputEl.disabled = !enabled;
  if (sendBtnEl) sendBtnEl.disabled = !enabled;
}

async function handleSend(isFixRequest = false) {
  if (!inputEl || state.loading) return;
  const text = inputEl.value.trim();
  if (!text) return;

  inputEl.value = "";
  state.messages.push({ role: "user", content: text });
  state.loading = true;
  setInputEnabled(false);
  renderMessages();

  try {
    const apiMessages: ChatMessage[] = [
      { role: "system", content: buildSystemPrompt(scrapePageContext(isFixRequest)) },
      ...state.messages.slice(0, -1).map((m) => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      })),
      { role: "user", content: text },
    ];
    const reply = await dispatchChatViaBackground(apiMessages);
    state.messages.push({ role: "assistant", content: reply });
    if (isFixRequest) {
      pendingFix = extractFix(reply);
      fixPreviewStatus = pendingFix ? "Nothing is written to GitHub until you create the PR." : "Athena did not return a usable unified diff. Ask for a specific change.";
      if (pendingFix) void logActivity({ type: "fix-action", ruleId: "fix-it", label: "Fix preview shown", repo: getCurrentRepo()?.name ?? "unknown" });
      if (!pendingFix) void logActivity({ type: "fix-action", ruleId: "fix-it", label: "Fix proposal unavailable", repo: getCurrentRepo()?.name ?? "unknown" });
    }
  } catch (err) {
    state.messages.push({
      role: "assistant",
      content: `Error: ${err instanceof Error ? err.message : "Request failed."}`,
    });
  } finally {
    state.loading = false;
    setInputEnabled(true);
    if (createFixButton) createFixButton.disabled = false;
    renderMessages();
    inputEl?.focus();
  }
}

function extractFix(reply: string): PendingFix | null {
  const block = reply.match(/```diff\s*\n([\s\S]*?)```/i);
  if (!block) return null;
  const diff = block[1].trim();
  const sections = diff.split(/(?=^diff --git )/m).filter((part) => part.startsWith("diff --git "));
  if (!sections.length || sections.length > 8) return null;
  const files: ProposedFixFile[] = [];
  for (const section of sections) {
    const header = section.match(/^diff --git a\/(.+) b\/(.+)$/m);
    const newFile = /^new file mode /m.test(section) || /^--- \/dev\/null$/m.test(section);
    const path = newFile
      ? section.match(/^\+\+\+ b\/(.+)$/m)?.[1]
      : header?.[2];
    if (!path || path.length > 240 || path.startsWith("/") || path.includes("..") || path.includes("\\") || /[\u0000-\u001f`]/.test(path)) return null;
    const sectionLines = section.split("\n");
    const firstHunk = sectionLines.findIndex((line) => line.startsWith("@@ "));
    if (firstHunk < 0) return null;
    const patch = sectionLines.slice(firstHunk).filter((line) => line.startsWith("@@ ") || line.startsWith("+") || line.startsWith("-") || line.startsWith(" ") || line.startsWith("\\ No newline")).join("\n");
    files.push({ path, patch, isNewFile: newFile });
  }
  const summary = reply.slice(0, block.index).replace(/[`#*_\n]/g, " ").trim().slice(0, 300) || "Proposed pull request fix";
  return { summary, diff, files };
}

function renderFixPreview(): void {
  if (!fixPreviewEl) return;
  fixPreviewEl.replaceChildren();
  fixPreviewEl.hidden = !pendingFix;
  if (!pendingFix) return;
  const title = document.createElement("div");
  title.className = "fix-preview-title";
  title.textContent = "Review proposed changes";
  const pre = document.createElement("pre");
  pre.className = "fix-preview-diff";
  pre.textContent = pendingFix.diff;
  const actions = document.createElement("div");
  actions.className = "fix-preview-actions";
  if (fixPreviewStatus) {
    const status = document.createElement("span");
    status.className = "fix-preview-status";
    status.textContent = fixPreviewStatus;
    actions.appendChild(status);
  }
  const create = document.createElement("button");
  create.type = "button";
  create.className = "send-btn fix-create-btn";
  create.textContent = fixPreviewBusy ? "Creating…" : "Create PR";
  create.disabled = fixPreviewBusy || (!!pendingFix.conflictRequest && conflictFlow?.phase !== "ready");
  create.addEventListener("click", () => void submitFixPreview());
  const cancel = document.createElement("button");
  cancel.type = "button";
  cancel.className = "fix-cancel-btn";
  cancel.textContent = "Cancel";
  cancel.disabled = fixPreviewBusy;
  cancel.addEventListener("click", () => {
    const repo = getCurrentRepo();
    void logActivity({ type: "fix-action", ruleId: "fix-it", label: "Fix preview cancelled", repo: repo?.name ?? "unknown" });
    pendingFix = null;
    fixPreviewStatus = "";
    renderFixPreview();
  });
  actions.append(create, cancel);
  const summary = document.createElement("div"); summary.className = "fix-preview-title"; summary.textContent = `${pendingFix.summary} · ${pendingFix.conflictRequest ? "Athena-generated merge result, review before creating PR" : "AI-generated, review before merging"}`;
  if (pendingFix.secretRequest) {
    const warning = document.createElement("div"); warning.className = "fix-preview-status"; warning.textContent = SECRET_HISTORY_WARNING;
    const revoke = document.createElement("div"); revoke.className = "fix-preview-status";
    const urls = [...new Set(pendingFix.secretRequest.findings.map(f => SECRET_REVOKE_URLS[f.type]).filter(Boolean))];
    if (urls.length) {
      for (const url of urls) { const link = document.createElement("a"); link.href = url; link.target = "_blank"; link.rel = "noopener noreferrer"; link.textContent = "Open provider revoke page"; revoke.appendChild(link); revoke.appendChild(document.createTextNode(" ")); }
    }
    fixPreviewEl.append(title, summary, warning, revoke, pre, actions);
  } else fixPreviewEl.append(title, summary, pre, actions);
}

function getCurrentRepo(): { owner: string; name: string; pullNumber: number } | null {
  const match = window.location.pathname.match(/^\/([^/]+)\/([^/]+)\/pull\/(\d+)/);
  return match ? { owner: match[1], name: match[2], pullNumber: Number(match[3]) } : null;
}

function requestFixProposal(): void {
  const repo = getCurrentRepo();
  if (!repo || state.loading || !inputEl) return;
  inputEl.value = "Propose a safe fix for this pull request. Return only a short summary and a unified diff for the change.";
  void logActivity({ type: "fix-action", ruleId: "fix-it", label: "Requested AI fix proposal", repo: `${repo.owner}/${repo.name}` });
  void handleSend(true);
}

async function submitFixPreview(): Promise<void> {
  if (!pendingFix || fixPreviewBusy) return;
  const repo = getCurrentRepo();
  if (!repo) { fixPreviewStatus = "Open a pull request page to create a fix."; renderFixPreview(); return; }
  fixPreviewBusy = true;
  fixPreviewStatus = "Creating a draft pull request…";
  const isSecretFix = !!pendingFix.secretRequest;
  const isConflictFix = !!pendingFix.conflictRequest;
  const secretRequest = pendingFix.secretRequest;
  const conflictRequest = pendingFix.conflictRequest;
  renderFixPreview();
  try {
    const result = await new Promise<FixActionResponse>((resolve, reject) => {
      chrome.runtime.sendMessage({
        type: isConflictFix ? "ATHENA_CONFLICT_CREATE_PR" : secretRequest ? "ATHENA_SECRET_PR_CREATE" : pendingFix!.ciRequestId ? "ATHENA_CI_FIX_CREATE_PR" : "ATHENA_CREATE_FIX_PR",
        requestId: pendingFix!.ciRequestId, secretFindings: secretRequest?.findings,
        confirmWorkflow: secretRequest?.confirmWorkflow,
        resolutions: conflictRequest?.resolutions, confirmProtectedOnce: conflictRequest?.confirmedOnce, confirmProtectedTwice: conflictRequest?.confirmedTwice,
        owner: repo.owner, repo: repo.name,
        pullNumber: repo.pullNumber, summary: pendingFix!.summary, files: pendingFix!.files,
      }, (response: FixActionResponse | undefined) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else if (!response) reject(new Error("No response from the extension worker."));
        else resolve(response);
      });
    });
    if (!result.ok) throw new Error(result.error || "Could not create the pull request.");
    fixPreviewStatus = result.url ? `Draft PR created: ${result.url}` : (result.message ?? "Draft PR created.");
    const summary = pendingFix.summary;
    pendingFix = null;
    if (isConflictFix) conflictFlow = null;
    if (!isSecretFix && !isConflictFix) await logActivity({ type: "fix-action", ruleId: "fix-it", label: "Created AI fix pull request", repo: `${repo.owner}/${repo.name}` });
    // Keep a compact completion message in the conversation; no diff or file contents are logged.
    state.messages.push({ role: "assistant", content: fixPreviewStatus });
    void summary;
  } catch (error) {
    fixPreviewStatus = error instanceof Error ? error.message : "Could not create the pull request.";
    if (!isSecretFix && !isConflictFix) await logActivity({ type: "fix-action", ruleId: "fix-it", label: "AI fix pull request failed", repo: `${repo.owner}/${repo.name}` });
  } finally {
    fixPreviewBusy = false;
    renderMessages();
  }
}

// ── Build the panel DOM ───────────────────────────────────────────────────────
function buildPanel(): void {
  panelHost = document.createElement("div");
  panelHost.dataset.athenaThemeHost = "";
  panelHost.id = "athena-panel-host";
  Object.assign(panelHost.style, {
    position: "fixed",
    top: "0",
    right: "0",
    width: "400px",
    maxWidth: "90vw",
    height: "100vh",
    zIndex: "2147483646",
    pointerEvents: "none",
  });
  document.body.appendChild(panelHost);

  panelShadow = panelHost.attachShadow({ mode: "open" });

  // ── Keyboard isolation ─────────────────────────────────────────────────
  // Stop ALL keyboard events that originate inside the Shadow DOM from
  // bubbling out to GitHub's document-level shortcut listeners.
  // Because Shadow DOM events are "re-targeted" at the host boundary we
  // must capture them at the shadow root itself.
  for (const evtType of ["keydown", "keypress", "keyup"] as const) {
    panelShadow.addEventListener(
      evtType,
      (e: Event) => {
        // Let Alt+A pass through so our own shortcut handler can close the
        // panel, but stop everything else from reaching GitHub.
        const ke = e as KeyboardEvent;
        if (ke.altKey && (ke.key === "a" || ke.key === "A")) return;
        e.stopPropagation();
      },
      true // capture phase – runs before the event reaches any child
    );
  }

  const style = document.createElement("style");
  style.textContent = `${primerTokenStyles}\n${PANEL_CSS}`;
  panelShadow.appendChild(style);

  panelEl = document.createElement("div");
  panelEl.className = "panel";
  panelEl.style.pointerEvents = "auto";

  // Header
  const header = document.createElement("div");
  header.className = "panel-header";

  const iconWrap = document.createElement("div");
  iconWrap.className = "panel-icon-wrap";
  const brandLogo = document.createElement("img");
  brandLogo.src = chrome.runtime.getURL("icons/athena-128.png");
  brandLogo.alt = "";
  brandLogo.setAttribute("aria-hidden", "true");
  iconWrap.appendChild(brandLogo);

  const titleWrap = document.createElement("div");
  titleWrap.style.flex = "1";

  const titleEl = document.createElement("div");
  titleEl.className = "panel-title";
  titleEl.textContent = "Athena";

  const statusDot = document.createElement("span");
  statusDot.className = "panel-status-dot";
  titleEl.appendChild(statusDot);

  const subtitle = document.createElement("div");
  subtitle.className = "panel-subtitle";
  subtitle.textContent = "AI Security Guardrail · Alt+A";

  titleWrap.appendChild(titleEl);
  titleWrap.appendChild(subtitle);

  const closeBtn = document.createElement("button");
  closeBtn.className = "panel-close";
  closeBtn.type = "button";
  closeBtn.textContent = "✕";
  closeBtn.setAttribute("aria-label", "Close panel");
  closeBtn.addEventListener("click", closePanel);

  header.appendChild(iconWrap);
  header.appendChild(titleWrap);
  header.appendChild(closeBtn);

  // Context strip
  const ctxStrip = document.createElement("div");
  ctxStrip.className = "ctx-strip";

  const ctxHeader = document.createElement("div");
  ctxHeader.className = "ctx-header";

  const ctxLabel = document.createElement("div");
  ctxLabel.className = "ctx-label";
  ctxLabel.textContent = "Page Context";

  const ctxBadge = document.createElement("span");
  ctxBadge.className = "ctx-badge";
  ctxBadge.textContent = "Live";

  ctxHeader.appendChild(ctxLabel);
  ctxHeader.appendChild(ctxBadge);

  ctxTitleEl = document.createElement("div");
  ctxTitleEl.className = "ctx-title";
  ctxTitleEl.textContent = "Scanning active tab…";

  ctxStrip.appendChild(ctxHeader);
  ctxStrip.appendChild(ctxTitleEl);

  // Messages area
  messagesEl = document.createElement("div");
  messagesEl.className = "messages";

  // Input row
  const inputRow = document.createElement("div");
  inputRow.className = "input-row";

  inputEl = document.createElement("textarea");
  inputEl.className = "chat-input";
  inputEl.placeholder = "Ask Athena about this page…";
  inputEl.setAttribute("aria-label", "Ask Athena about this page");
  inputEl.rows = 1;

  // Isolate textarea keystrokes from GitHub shortcuts while preserving Enter / Shift+Enter / Alt+A
  for (const evtType of ["keydown", "keypress", "keyup"] as const) {
    inputEl.addEventListener(evtType, (e: KeyboardEvent) => {
      // Allow Alt+A through for global toggle
      if (e.altKey && (e.key === "a" || e.key === "A")) {
        return;
      }
      // Handle Enter to send
      if (evtType === "keydown" && e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        e.stopPropagation();
        void handleSend();
        return;
      }
      // Stop all other typing events from bubbling to GitHub shortcut listeners
      e.stopPropagation();
    });
  }

  sendBtnEl = document.createElement("button");
  sendBtnEl.type = "button";
  sendBtnEl.className = "send-btn";
  sendBtnEl.textContent = "Send";
  sendBtnEl.addEventListener("click", () => void handleSend());

  if (getCurrentRepo()) {
    createFixButton = document.createElement("button");
    createFixButton.type = "button";
    createFixButton.className = "fix-it-btn";
    createFixButton.textContent = "Fix it for me";
    createFixButton.title = "Ask Athena to propose a fix for review";
    createFixButton.addEventListener("click", () => {
      if (createFixButton) createFixButton.disabled = true;
      requestFixProposal();
    });
    inputRow.appendChild(createFixButton);
  }

  inputRow.appendChild(inputEl);
  inputRow.appendChild(sendBtnEl);

  fixPreviewEl = document.createElement("div");
  fixPreviewEl.className = "fix-preview";
  fixPreviewEl.hidden = true;

  panelEl.appendChild(header);
  panelEl.appendChild(ctxStrip);
  panelEl.appendChild(messagesEl);
  panelEl.appendChild(fixPreviewEl);
  panelEl.appendChild(inputRow);
  const resizeHandle = document.createElement("div");
  resizeHandle.className = "panel-resize-handle";
  resizeHandle.setAttribute("role", "separator");
  resizeHandle.setAttribute("aria-label", "Resize chat window");
  panelEl.appendChild(resizeHandle);
  panelShadow.appendChild(panelEl);
  enablePanelDragging(header);
  enablePanelResizing(resizeHandle);
  restorePanelPosition();
}

// ── Build the FAB ─────────────────────────────────────────────────────────────
function buildFab(): void {
  fabHost = document.createElement("div");
  fabHost.dataset.athenaThemeHost = "";
  fabHost.id = "athena-fab-host";
  Object.assign(fabHost.style, {
    position: "fixed",
    right: "20px",
    bottom: "24px",
    zIndex: "2147483647",
  });
  document.body.appendChild(fabHost);

  const fabShadow = fabHost.attachShadow({ mode: "open" });

  const style = document.createElement("style");
  style.textContent = `${primerTokenStyles}\n${FAB_CSS}`;
  fabShadow.appendChild(style);

  const fab = document.createElement("button");
  fab.type = "button";
  fab.className = "fab";
  fab.setAttribute("aria-label", "Open Athena Security Assistant");
  fab.setAttribute("aria-expanded", "false");
  const fabLogo = document.createElement("img");
  fabLogo.src = chrome.runtime.getURL("icons/athena-48.png");
  fabLogo.alt = "";
  fabLogo.setAttribute("aria-hidden", "true");
  fabLogo.width = 24;
  fabLogo.height = 24;
  fab.appendChild(fabLogo);
  fab.addEventListener("click", togglePanel);

  const tooltip = document.createElement("div");
  tooltip.className = "fab-tooltip";
  tooltip.textContent = "Athena (Alt+A)";

  fabShadow.appendChild(fab);
  fabShadow.appendChild(tooltip);
}

// ── Panel open/close ──────────────────────────────────────────────────────────
async function openPanel(): Promise<void> {
  if (!panelEl) return;
  state.isOpen = true;
  panelEl.classList.add("open");
  const fab = document.getElementById("athena-fab-host")?.shadowRoot?.querySelector<HTMLButtonElement>(".fab");
  fab?.setAttribute("aria-label", "Close Athena Security Assistant");
  fab?.setAttribute("aria-expanded", "true");

  // Scrape page context on open
  const ctx = scrapePageContext();
  state.systemPrompt = buildSystemPrompt(ctx);
  if (ctxTitleEl) ctxTitleEl.textContent = `${ctx.pageType}: ${ctx.title}`;

  // Show a welcome message on first open
  if (state.messages.length === 0) {
    state.messages.push({
      role: "assistant",
      content: `Hi! I've read the context of this ${ctx.pageType} page. What would you like to know?`,
    });
    renderMessages();
  }

  setTimeout(() => inputEl?.focus(), 250);
}

/** Open the assistant from a contextual in-page prompt. */
export function openActivePanel(): void {
  void openPanel();
}

function closePanel(): void {
  if (!panelEl) return;
  state.isOpen = false;
  panelEl.classList.remove("open");
  const fab = document.getElementById("athena-fab-host")?.shadowRoot?.querySelector<HTMLButtonElement>(".fab");
  fab?.setAttribute("aria-label", "Open Athena Security Assistant");
  fab?.setAttribute("aria-expanded", "false");
}

function togglePanel(): void {
  if (isRestrictedPage()) return;
  if (state.isOpen) {
    closePanel();
  } else {
    void openPanel();
  }
}

// ── Keyboard shortcut ─────────────────────────────────────────────────────────
let _keyboardShortcutSet = false;
let _warningPulseSet = false;
let _ciFailureListenerSet = false;
let _conflictResolutionListenerSet = false;

function setupWarningPulse(): void {
  if (_warningPulseSet) return;
  _warningPulseSet = true;
  document.addEventListener(ATHENA_WARNING_SHOWN_EVENT, () => {
    const fab = document.getElementById("athena-fab-host")?.shadowRoot?.querySelector<HTMLButtonElement>(".fab");
    if (!fab) return;
    fab.classList.remove("warning-pulse");
    fab.classList.add("warning-pulse");
    window.setTimeout(() => fab.classList.remove("warning-pulse"), 220);
  });
}

/** Returns true when the active element is a GitHub text-entry field. */
export function isFocusInTextField(): boolean {
  const active = document.activeElement;
  if (!active) return false;

  // Focus inside Athena Shadow DOM or panel host should NOT be considered a GitHub text field
  if (active.id === "athena-panel-host" || active.id === "athena-react-host" || active.closest?.("#athena-panel-host") || active.closest?.("#athena-react-host")) {
    return false;
  }
  const host = document.getElementById("athena-panel-host");
  if (host?.shadowRoot && (host.shadowRoot.activeElement || host.shadowRoot.contains(active))) {
    return false;
  }

  const tag = active.tagName.toLowerCase();
  if (tag === "textarea") return true;
  if (tag === "input") {
    const type = (active as HTMLInputElement).type?.toLowerCase() ?? "text";
    // Only block for text-entry input types
    const textTypes = new Set(["text", "search", "url", "email", "password", "number", "tel", ""]);
    return textTypes.has(type);
  }
  if ((active as HTMLElement).isContentEditable) return true;
  return false;
}

function setupKeyboardShortcut(): void {
  if (_keyboardShortcutSet) return;
  _keyboardShortcutSet = true;
  document.addEventListener("keydown", (e) => {
    if (e.altKey && (e.key === "a" || e.key === "A")) {
      // Don't steal Alt+A when user is typing in a GitHub text field
      if (isFocusInTextField()) return;
      e.preventDefault();
      togglePanel();
    }
  });
}

// ── Initialise ────────────────────────────────────────────────────────────────
export function initActivePanel(): void {
  if (!document.body) return;
  if (isRestrictedPage()) {
    document.getElementById("athena-panel-host")?.remove();
    document.getElementById("athena-fab-host")?.remove();
    panelHost = null;
    fabHost = null;
    panelShadow = null;
    panelEl = null;
    messagesEl = null;
    inputEl = null;
    sendBtnEl = null;
    ctxTitleEl = null;
    return;
  }
  void loadPrSecretFindings();
  if (!panelHost?.isConnected || !panelEl?.isConnected) {
    document.getElementById("athena-panel-host")?.remove();
    panelHost = null;
    panelShadow = null;
    panelEl = null;
    messagesEl = null;
    inputEl = null;
    sendBtnEl = null;
    ctxTitleEl = null;
    buildPanel();
    renderMessages();
  }
  if (!fabHost?.isConnected) {
    document.getElementById("athena-fab-host")?.remove();
    fabHost = null;
    buildFab();
  }
  setupKeyboardShortcut();
  setupWarningPulse();
  if (!_ciFailureListenerSet) {
    _ciFailureListenerSet = true;
    document.addEventListener("ATHENA_CI_FAILURE_DETECTED", ((event: CustomEvent<{ checkName: string }>) => {
      if (ciRequest?.checkName === event.detail.checkName) return;
      ciRequest = { checkName: event.detail.checkName || "Failing CI check", phase: "choice" };
      void openPanel().then(() => { renderMessages(); });
    }) as EventListener);
  }
  if (!_conflictResolutionListenerSet) {
    _conflictResolutionListenerSet = true;
    document.addEventListener("ATHENA_CONFLICT_RESOLUTION_REQUESTED", () => { void startConflictResolution(); });
  }
}
