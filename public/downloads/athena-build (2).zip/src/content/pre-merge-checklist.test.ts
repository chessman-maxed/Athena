/**
 * Unit tests for src/content/pre-merge-checklist.ts
 *
 * Tests DOM inspection logic for:
 *  - CI / Checks status (passing, failing, pending)
 *  - Review approval status (approved, changes-requested, no-approval)
 *  - Merge conflict status (clean, conflicts, out-of-date)
 *  - PR health evaluation
 */

import { describe, it, expect } from "vitest";
import {
  getCIStatus,
  getReviewStatus,
  getConflictStatus,
  evaluatePRHealth,
  getBaseBranchName,
  getRepoKeyFromUrl,
  evaluateUnsafeMergeReasons,
} from "./pre-merge-checklist";
import { DEFAULT_REPO_POLICY } from "../storage/session";

// ── Lightweight Mock Element & Document for Node environment ─────────────────

interface MockElement {
  textContent: string;
  attributes: Record<string, string>;
  className: string;
}

function createMockDoc(elements: MockElement[], bodyText = ""): Document {
  const queryAll = (selector: string) => {
    return elements.filter((el) => {
      if (selector.includes(".merge-status-item") && el.className.includes("merge-status-item")) return true;
      if (selector.includes(".branch-action-item") && el.className.includes("branch-action-item")) return true;
      if (selector.includes(".discussion-sidebar-item") && el.className.includes("discussion-sidebar-item")) return true;
      if (selector.includes("[data-check-state]") && "data-check-state" in el.attributes) return true;
      return false;
    }) as unknown as NodeListOf<Element>;
  };

  const queryOne = (selector: string) => {
    for (const el of elements) {
      if (selector.includes("FAILURE") && el.attributes["data-check-state"] === "FAILURE") return el as unknown as Element;
      if (selector.includes("PENDING") && el.attributes["data-check-state"] === "PENDING") return el as unknown as Element;
      if (selector.includes("SUCCESS") && el.attributes["data-check-state"] === "SUCCESS") return el as unknown as Element;
      if (selector.includes("color-fg-danger") && el.className.includes("color-fg-danger")) return el as unknown as Element;
      if (selector.includes("color-fg-success") && el.className.includes("color-fg-success")) return el as unknown as Element;
      if (selector.includes("State--red") && el.className.includes("State--red")) return el as unknown as Element;
      if (selector.includes("base-ref") && el.className.includes("base-ref")) return el as unknown as Element;
    }
    return null;
  };

  return {
    querySelectorAll: queryAll,
    querySelector: queryOne,
    body: { textContent: bodyText },
  } as unknown as Document;
}

describe("Pre-Merge Checklist DOM Inspection", () => {
  describe("CI Status Detection", () => {
    it("detects passing CI status", () => {
      const doc = createMockDoc([
        {
          className: "merge-status-item color-fg-success",
          textContent: "All checks have passed",
          attributes: { "data-check-state": "SUCCESS" },
        },
      ]);
      expect(getCIStatus(doc)).toBe("passing");
    });

    it("detects failing CI status", () => {
      const doc = createMockDoc([
        {
          className: "merge-status-item color-fg-danger",
          textContent: "1 check failed",
          attributes: { "data-check-state": "FAILURE" },
        },
      ]);
      expect(getCIStatus(doc)).toBe("failing");
    });

    it("detects pending CI status", () => {
      const doc = createMockDoc([
        {
          className: "merge-status-item anim-rotate",
          textContent: "Checks in progress",
          attributes: { "data-check-state": "PENDING" },
        },
      ]);
      expect(getCIStatus(doc)).toBe("pending");
    });

    it("returns unknown when no CI indicators are found", () => {
      const doc = createMockDoc([]);
      expect(getCIStatus(doc)).toBe("unknown");
    });
  });

  describe("Review Status Detection", () => {
    it("detects approved reviews", () => {
      const doc = createMockDoc([
        {
          className: "discussion-sidebar-item color-fg-success",
          textContent: "Review approved",
          attributes: {},
        },
      ]);
      expect(getReviewStatus(doc)).toBe("approved");
    });

    it("detects changes requested", () => {
      const doc = createMockDoc([
        {
          className: "discussion-sidebar-item color-fg-danger",
          textContent: "Changes requested",
          attributes: {},
        },
      ]);
      expect(getReviewStatus(doc)).toBe("changes-requested");
    });

    it("detects review required / no approval", () => {
      const doc = createMockDoc([
        {
          className: "discussion-sidebar-item",
          textContent: "Review required",
          attributes: {},
        },
      ]);
      expect(getReviewStatus(doc)).toBe("no-approval");
    });
  });

  describe("Conflict Status Detection", () => {
    it("detects merge conflicts", () => {
      const doc = createMockDoc(
        [
          {
            className: "branch-action-item State--red",
            textContent: "This branch has conflicts with the base branch",
            attributes: {},
          },
        ],
        "This branch has conflicts with the base branch"
      );
      expect(getConflictStatus(doc)).toBe("conflicts");
    });

    it("detects out-of-date branch", () => {
      const doc = createMockDoc(
        [
          {
            className: "branch-action-item",
            textContent: "This branch is out-of-date with the base branch",
            attributes: {},
          },
        ],
        "This branch is out-of-date with the base branch"
      );
      expect(getConflictStatus(doc)).toBe("out-of-date");
    });

    it("detects clean merge status", () => {
      const doc = createMockDoc(
        [
          {
            className: "branch-action-item color-fg-success",
            textContent: "This branch has no conflicts with the base branch",
            attributes: {},
          },
        ],
        "This branch has no conflicts with the base branch"
      );
      expect(getConflictStatus(doc)).toBe("clean");
    });
  });

  describe("PR Health Evaluation", () => {
    it("evaluates overall health correctly", () => {
      const doc = createMockDoc(
        [
          {
            className: "merge-status-item color-fg-success",
            textContent: "All checks have passed",
            attributes: { "data-check-state": "SUCCESS" },
          },
          {
            className: "discussion-sidebar-item color-fg-success",
            textContent: "Review approved",
            attributes: {},
          },
          {
            className: "branch-action-item color-fg-success",
            textContent: "This branch has no conflicts",
            attributes: {},
          },
        ],
        "This branch has no conflicts"
      );

      const health = evaluatePRHealth(doc);
      expect(health).toEqual({
        ci: "passing",
        review: "approved",
        conflict: "clean",
      });
    });
  });

  describe("Branch & Repo Key Detection", () => {
    it("extracts repo key from GitHub URL", () => {
      expect(getRepoKeyFromUrl("https://github.com/facebook/react/pull/42")).toBe("facebook/react");
      expect(getRepoKeyFromUrl("https://github.com/Google/Athena/issues/10")).toBe("google/athena");
      expect(getRepoKeyFromUrl("https://example.com/invalid")).toBe("");
    });

    it("extracts base branch name from DOM", () => {
      const doc = createMockDoc([
        {
          className: "commit-ref base-ref",
          textContent: "main",
          attributes: {},
        },
      ]);
      expect(getBaseBranchName(doc)).toBe("main");
    });
  });

  describe("Per-Repo Policy Merge Reasons", () => {
    it("blocks merge to main when blockMergeToMain is true", () => {
      const doc = createMockDoc([
        {
          className: "commit-ref base-ref",
          textContent: "main",
          attributes: {},
        },
        {
          className: "merge-status-item color-fg-success",
          textContent: "All checks have passed",
          attributes: { "data-check-state": "SUCCESS" },
        },
        {
          className: "discussion-sidebar-item color-fg-success",
          textContent: "Review approved",
          attributes: {},
        },
        {
          className: "branch-action-item color-fg-success",
          textContent: "This branch has no conflicts",
          attributes: {},
        },
      ]);

      const reasons = evaluateUnsafeMergeReasons(doc, "https://github.com/owner/repo/pull/1", {
        ...DEFAULT_REPO_POLICY,
        blockMergeToMain: true,
      });

      expect(reasons).toContain("Merging directly to 'main' is blocked by repository policy");
    });

    it("requires passing CI checks when requirePassingChecks is true", () => {
      const doc = createMockDoc([
        {
          className: "commit-ref base-ref",
          textContent: "feature-branch",
          attributes: {},
        },
        {
          className: "merge-status-item color-fg-attention",
          textContent: "Checks in progress",
          attributes: { "data-check-state": "PENDING" },
        },
        {
          className: "discussion-sidebar-item color-fg-success",
          textContent: "Review approved",
          attributes: {},
        },
        {
          className: "branch-action-item color-fg-success",
          textContent: "This branch has no conflicts",
          attributes: {},
        },
      ]);

      const reasons = evaluateUnsafeMergeReasons(doc, "https://github.com/owner/repo/pull/1", {
        ...DEFAULT_REPO_POLICY,
        requirePassingChecks: true,
      });

      expect(reasons.some((r) => r.includes("Repository policy requires all CI checks to pass before merging"))).toBe(true);
    });
  });
});
