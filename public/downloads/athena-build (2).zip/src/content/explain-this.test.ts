/**
 * Unit tests for "Explain this" LLM feature (src/content/explain-this.ts).
 *
 * Covers:
 *  - Secret Guardrail: scanText() MUST run first and block if any secret is detected
 *  - API Key Requirement: prompts when API key is missing
 *  - First-Send Privacy Notice: returns needs-consent on first invocation
 *  - Request Dispatch: sends only the selected text to configured LLM endpoint
 *  - Error handling: handles non-200 responses gracefully
 */

import { describe, it, expect, vi } from "vitest";
import { processExplainRequest } from "./explain-this";
import type { LLMSettings } from "../storage/session";

describe("Explain This - processExplainRequest", () => {
  const cleanSnippet = `
diff --git a/src/auth.ts b/src/auth.ts
--- a/src/auth.ts
+++ b/src/auth.ts
@@ -10,2 +10,4 @@
+  if (!user.verified) {
+    throw new Error("User email unverified");
+  }
`;

  const validSettings: LLMSettings = {
    baseUrl: "https://api.openai.com/v1",
    apiKey: "sk-test-valid-key-12345",
    model: "gpt-4o-mini",
  };

  it("blocks request if selected text contains an AWS access key", async () => {
    const textWithSecret = `const awsKey = "AKIAIOSFODNN7EXAMPLE"; // test key`;
    const mockFetch = vi.fn();

    const result = await processExplainRequest(textWithSecret, {
      customFetch: mockFetch,
    });

    expect(result.status).toBe("blocked-secret");
    expect(result.findings && result.findings.length).toBeGreaterThan(0);
    expect(result.findings?.[0].type).toBe("AWS Access Key ID");
    // CRITICAL: Fetch must NEVER be called if a secret is present
    expect(mockFetch).not.toHaveBeenCalled();
  });

  it("blocks request if selected text contains a GitHub PAT or OpenAI Key", async () => {
    const textWithPAT = `Authorization: token ghp_1234567890abcdefghijklmnopqrstuvwxyzAB`;
    const mockFetch = vi.fn();

    const result = await processExplainRequest(textWithPAT, {
      customFetch: mockFetch,
    });

    expect(result.status).toBe("blocked-secret");
    expect(mockFetch).not.toHaveBeenCalled();
  });

  it("returns missing-key status when user has not supplied an API key", async () => {
    const mockFetch = vi.fn();

    const result = await processExplainRequest(cleanSnippet, {
      customLoadSettings: async () => ({ baseUrl: "", apiKey: "", model: "gpt-4o-mini" }),
      customFetch: mockFetch,
    });

    expect(result.status).toBe("missing-key");
    expect(result.error).toContain("API key is required");
    expect(mockFetch).not.toHaveBeenCalled();
  });

  it("requires consent notice on first send before text leaves browser", async () => {
    const mockFetch = vi.fn();

    const result = await processExplainRequest(cleanSnippet, {
      customLoadSettings: async () => validSettings,
      customHasConsent: async () => false, // Not yet consented
      customFetch: mockFetch,
    });

    expect(result.status).toBe("needs-consent");
    expect(mockFetch).not.toHaveBeenCalled();
  });

  it("sends only the selected text to LLM when consent is granted and returns explanation", async () => {
    const mockResponse = {
      choices: [
        {
          message: {
            content: "This change adds an email verification check before allowing the user to proceed.",
          },
        },
      ],
    };

    const mockFetch = vi.fn().mockResolvedValue({
      ok: true,
      json: async () => mockResponse,
    });

    const result = await processExplainRequest(cleanSnippet, {
      customLoadSettings: async () => validSettings,
      customHasConsent: async () => true, // Consented
      customFetch: mockFetch as unknown as typeof fetch,
    });

    expect(result.status).toBe("success");
    expect(result.explanation).toContain("email verification check");

    expect(mockFetch).toHaveBeenCalledTimes(1);
    const [url, req] = mockFetch.mock.calls[0];
    expect(url).toBe("https://api.openai.com/v1/chat/completions");
    expect(req.headers["Authorization"]).toBe("Bearer sk-test-valid-key-12345");

    const body = JSON.parse(req.body);
    expect(body.model).toBe("gpt-4o-mini");
    expect(body.messages).toHaveLength(2);
    expect(body.messages[1].content).toBe(cleanSnippet.trim());
  });

  it("handles non-200 API error responses gracefully", async () => {
    const mockFetch = vi.fn().mockResolvedValue({
      ok: false,
      status: 401,
      text: async () => "Incorrect API key provided",
    });

    const result = await processExplainRequest(cleanSnippet, {
      customLoadSettings: async () => validSettings,
      forceConsent: true,
      customFetch: mockFetch as unknown as typeof fetch,
    });

    expect(result.status).toBe("error");
    expect(result.error).toContain("401");
    expect(result.error).toContain("Incorrect API key");
  });
});
