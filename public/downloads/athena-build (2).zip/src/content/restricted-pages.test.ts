import { describe, expect, it } from "vitest";
import { isRestrictedPage } from "./restricted-pages";

describe("Athena availability on supported GitHub routes", () => {
  it.each([
    "/",
    "/owner/repo",
    "/owner/repo/tree/main",
    "/owner/repo/blob/main/README.md",
    "/owner/repo/pull/123",
    "/owner/repo/issues",
    "/owner/repo/actions",
    "/owner/repo/settings",
    "/org/repo/security",
  ])("keeps Athena enabled on %s", (path) => {
    expect(isRestrictedPage(path)).toBe(false);
  });
});
