import { getCurrentContext, onContextChange, type PageContext } from "./page-context";
import { isRestrictedPage } from "./restricted-pages";

export interface ActivityEntry {
  at: number;
  page: string;
  action: string;
}

const MAX_ENTRIES = 12;
const activity: ActivityEntry[] = [];
let initialized = false;

function pageLabel(ctx: PageContext): string {
  const repo = ctx.owner && ctx.repo ? `${ctx.owner}/${ctx.repo}` : "GitHub";
  if (ctx.type === "pull-request") return `${repo} PR #${ctx.prNumber}`;
  if (ctx.type === "issue") return `${repo} issue #${ctx.issueNumber}`;
  if (ctx.type === "repo-home") return `${repo} repository`;
  if (ctx.type === "new-file") return `${repo} new file`;
  if (ctx.type === "web-editor") return `${repo} editor`;
  return repo;
}

function record(action: string, ctx = getCurrentContext()): void {
  if (isRestrictedPage()) return;
  activity.push({ at: Date.now(), page: pageLabel(ctx), action });
  if (activity.length > MAX_ENTRIES) activity.splice(0, activity.length - MAX_ENTRIES);
}

function controlLabel(el: Element): string | null {
  const tag = el.tagName.toLowerCase();
  if (tag === "input" || tag === "textarea" || (el as HTMLElement).isContentEditable) return null;

  const label = (
    el.getAttribute("aria-label") ||
    el.getAttribute("title") ||
    el.textContent ||
    ""
  ).replace(/\s+/g, " ").trim();
  if (!label) return null;

  // Only record short UI labels, never arbitrary page prose or document text.
  return label.length <= 70 ? label : null;
}

function onClick(event: MouseEvent): void {
  if (isRestrictedPage()) return;
  const target = event.target;
  if (!(target instanceof Element) || target.closest("[data-athena-theme-host], #athena-panel-host, #athena-fab-host")) return;

  const control = target.closest("button, a[href], summary, [role='tab'], [role='button']");
  if (!control) return;
  const label = controlLabel(control);
  if (!label) return;

  const tag = control.tagName.toLowerCase();
  const kind = tag === "a" ? "Opened" : tag === "summary" || control.getAttribute("role") === "tab" ? "Viewed" : "Used";
  record(`${kind}: ${label}`);
}

export function initActivityTracker(): void {
  if (initialized) return;
  initialized = true;
  if (isRestrictedPage()) return;

  record("Opened this GitHub page");
  document.addEventListener("click", onClick, true);
  onContextChange((ctx) => record("Navigated to this page", ctx));
}

/** Recent, concise activity context for Athena; kept in memory for this page session. */
export function getRecentActivity(): ActivityEntry[] {
  return activity.slice(-MAX_ENTRIES);
}
