/**
 * Unit tests for Athena Rules & Policy Settings modal lifecycle and guardrails.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";

vi.mock("react-dom/client", () => ({
  createRoot: vi.fn(() => ({
    render: vi.fn(),
    unmount: vi.fn(),
  })),
}));

import {
  openSettingsPanel,
  closeSettingsPanel,
  initShadowHost,
} from "./shadow-host";

describe("Athena Policy Settings modal lifecycle & Shadow Host guards", () => {
  let fakeBodyChildren: Array<{ id: string; remove: () => void }> = [];

  beforeEach(() => {
    fakeBodyChildren = [];

    // Mock document and document.body
    const fakeBody = {
      appendChild: (el: any) => {
        fakeBodyChildren.push(el);
        return el;
      },
    };

    (globalThis as any).document = {
      body: fakeBody,
      getElementById: (id: string) => fakeBodyChildren.find((el) => el.id === id) ?? null,
      querySelectorAll: (selector: string) => {
        if (selector === "#athena-react-host") {
          return fakeBodyChildren.filter((el) => el.id === "athena-react-host");
        }
        return [];
      },
      createElement: (tag: string) => {
        const el: any = {
          nodeType: 1,
          tagName: tag.toUpperCase(),
          id: "",
          style: {},
          setAttribute: vi.fn(),
          appendChild: vi.fn(),
          addEventListener: vi.fn(),
          removeEventListener: vi.fn(),
          attachShadow: vi.fn(() => ({
            nodeType: 11,
            appendChild: vi.fn(),
            addEventListener: vi.fn(),
            removeEventListener: vi.fn(),
          })),
          remove: () => {
            const index = fakeBodyChildren.indexOf(el);
            if (index !== -1) {
              fakeBodyChildren.splice(index, 1);
            }
          },
        };
        el.ownerDocument = (globalThis as any).document;
        return el;
      },
    };
    (globalThis as any).document.nodeType = 9;
    (globalThis as any).document.addEventListener = vi.fn();
    (globalThis as any).document.removeEventListener = vi.fn();
  });

  afterEach(() => {
    closeSettingsPanel();
    delete (globalThis as any).document;
  });

  it("modal is closed by default and opens only on openSettingsPanel", () => {
    // Start closed
    closeSettingsPanel();

    // Opening sets state
    openSettingsPanel("owner/repo");
    // Closing resets state
    closeSettingsPanel();
  });

  it("removes any existing #athena-react-host elements before mounting to ensure only one host exists", () => {
    // Simulate pre-existing duplicate hosts
    const preExisting1 = (globalThis as any).document.createElement("div");
    preExisting1.id = "athena-react-host";
    (globalThis as any).document.body.appendChild(preExisting1);

    const preExisting2 = (globalThis as any).document.createElement("div");
    preExisting2.id = "athena-react-host";
    (globalThis as any).document.body.appendChild(preExisting2);

    expect((globalThis as any).document.querySelectorAll("#athena-react-host").length).toBe(2);

    // Call initShadowHost
    initShadowHost();

    // Old hosts must be removed, exactly one host must remain
    const hostsAfter = (globalThis as any).document.querySelectorAll("#athena-react-host");
    expect(hostsAfter.length).toBe(1);
    expect(hostsAfter[0]).not.toBe(preExisting1);
    expect(hostsAfter[0]).not.toBe(preExisting2);
  });

  it("guards against double execution when content script initialized flag or DOM attribute exists", () => {
    const mockWindow: { __ATHENA_CONTENT_SCRIPT_INITIALIZED__?: boolean } = {};
    let executed = 0;

    function runContentScript(win: typeof mockWindow) {
      if (win.__ATHENA_CONTENT_SCRIPT_INITIALIZED__) {
        return;
      }
      win.__ATHENA_CONTENT_SCRIPT_INITIALIZED__ = true;
      executed++;
    }

    runContentScript(mockWindow);
    expect(executed).toBe(1);

    // Second run must be ignored
    runContentScript(mockWindow);
    expect(executed).toBe(1);
  });
});
