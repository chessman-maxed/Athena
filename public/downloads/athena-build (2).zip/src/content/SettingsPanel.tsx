/**
 * Athena – Rules & Policy Settings Panel (Shadow DOM UI).
 *
 * Provides an in-DOM configuration panel for per-repo rules policies:
 *  - Block merging directly to main/master from UI warning layer
 *  - Require passing CI checks before merge
 *  - Toggle individual secret scanner detector patterns
 *
 * Saves credentials through the shared loadSettings/saveSettings helpers.
 */

import { useState, useEffect, useCallback, useRef } from "react";
import {
  ALL_SECRET_PATTERNS,
  DEFAULT_REPO_POLICY,
  getRepoPolicySync,
  loadRulesConfig,
  saveRepoPolicy,
  normalizeRepoKey,
  loadSettings,
  saveSettings,
  maskCredential,
  normalizeBaseUrl,
  type RepoPolicy,
  type RulesConfig,
  type SecretPatternId,
  type LLMSettings,
} from "../storage/session";

export interface SettingsPanelProps {
  initialRepoKey?: string;
  isOpen: boolean;
  onClose: () => void;
}

export function SettingsPanel({ initialRepoKey = "", isOpen, onClose }: SettingsPanelProps) {
  const [currentRepoKey, setCurrentRepoKey] = useState<string>(normalizeRepoKey(initialRepoKey));
  const [policy, setPolicy] = useState<RepoPolicy>(getRepoPolicySync(initialRepoKey));
  const [config, setConfig] = useState<RulesConfig | null>(null);
  const [llm, setLlm] = useState<LLMSettings>({ baseUrl: "", apiKey: "", model: "gpt-4o-mini" });
  const [hasApiKey, setHasApiKey] = useState(false);
  const [maskedApiKey, setMaskedApiKey] = useState("");
  const [editingApiKey, setEditingApiKey] = useState(false);
  const [permissionStatus, setPermissionStatus] = useState<"idle" | "granted" | "denied" | "error">("idle");
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  // Keep keyboard navigation inside the settings dialog and prevent GitHub
  // single-key shortcuts from intercepting text typed while it is open.
  useEffect(() => {
    if (!isOpen) return;
    const dialog = dialogRef.current;
    if (!dialog) return;

    closeButtonRef.current?.focus();
    const getFocusable = (): HTMLElement[] => Array.from(dialog.querySelectorAll<HTMLElement>(
      'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
    )).filter((element) => element.getClientRects().length > 0);

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        onClose();
        return;
      }
      if (!event.composedPath().includes(dialog)) return;
      if (event.key === "Tab") {
        const focusable = getFocusable();
        if (!focusable.length) {
          event.preventDefault();
          return;
        }
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        const active = dialog.getRootNode() instanceof ShadowRoot
          ? (dialog.getRootNode() as ShadowRoot).activeElement
          : document.activeElement;
        if (event.shiftKey && (active === first || !dialog.contains(active))) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && (active === last || !dialog.contains(active))) {
          event.preventDefault();
          first.focus();
        }
      }
      event.stopPropagation();
    };

    document.addEventListener("keydown", handleKeyDown, true);
    return () => document.removeEventListener("keydown", handleKeyDown, true);
  }, [isOpen, onClose]);

  // Sync with storage on open
  useEffect(() => {
    if (!isOpen) return;

    let active = true;
    Promise.all([loadRulesConfig(), loadSettings()]).then(([cfg, llmCfg]) => {
      if (!active) return;
      setConfig(cfg);
      setLlm({ ...llmCfg, apiKey: "" });
      setHasApiKey(!!llmCfg.apiKey);
      setMaskedApiKey(maskCredential(llmCfg.apiKey));
      setEditingApiKey(!llmCfg.apiKey);
      const norm = normalizeRepoKey(currentRepoKey);
      const activePolicy = norm && cfg.repos[norm] ? cfg.repos[norm] : cfg.defaultPolicy;
      setPolicy({
        blockMergeToMain: activePolicy.blockMergeToMain ?? DEFAULT_REPO_POLICY.blockMergeToMain,
        requirePassingChecks: activePolicy.requirePassingChecks ?? DEFAULT_REPO_POLICY.requirePassingChecks,
        secretToggles: {
          ...DEFAULT_REPO_POLICY.secretToggles,
          ...(activePolicy.secretToggles ?? {}),
        },
      });
    });

    return () => {
      active = false;
    };
  }, [isOpen, currentRepoKey]);

  const handleRepoChange = useCallback((newRepoKey: string) => {
    const norm = normalizeRepoKey(newRepoKey);
    setCurrentRepoKey(norm);
    if (config) {
      const activePolicy = norm && config.repos[norm] ? config.repos[norm] : config.defaultPolicy;
      setPolicy({
        blockMergeToMain: activePolicy.blockMergeToMain ?? DEFAULT_REPO_POLICY.blockMergeToMain,
        requirePassingChecks: activePolicy.requirePassingChecks ?? DEFAULT_REPO_POLICY.requirePassingChecks,
        secretToggles: {
          ...DEFAULT_REPO_POLICY.secretToggles,
          ...(activePolicy.secretToggles ?? {}),
        },
      });
    }
  }, [config]);

  const toggleSecretPattern = (patternId: SecretPatternId) => {
    setPolicy((prev) => ({
      ...prev,
      secretToggles: {
        ...prev.secretToggles,
        [patternId]: !prev.secretToggles[patternId],
      },
    }));
  };

  const setAllSecrets = (enabled: boolean) => {
    const updated: Record<SecretPatternId, boolean> = { ...policy.secretToggles };
    ALL_SECRET_PATTERNS.forEach((p) => {
      updated[p.id] = enabled;
    });
    setPolicy((prev) => ({ ...prev, secretToggles: updated }));
  };

  const handleSave = async (e?: React.MouseEvent) => {
    e?.stopPropagation();
    // Close modal FIRST synchronously before any async storage work
    onClose();

    // Wrap async storage work in try/catch so a storage error can never keep the modal open
    try {
      const normalizedBase = normalizeBaseUrl(llm.baseUrl);
      const normalizedLlm = { ...llm, baseUrl: normalizedBase };
      setLlm(normalizedLlm);
      await Promise.all([
        saveRepoPolicy(currentRepoKey || "default", policy),
        saveSettings({ baseUrl: normalizedBase, model: normalizedLlm.model, ...(normalizedLlm.apiKey.trim() ? { apiKey: normalizedLlm.apiKey.trim() } : {}) }),
      ]);
      await loadRulesConfig();
      if (normalizedLlm.apiKey.trim()) {
        setMaskedApiKey(maskCredential(normalizedLlm.apiKey.trim()));
        setHasApiKey(true);
        setEditingApiKey(false);
        setLlm((current) => ({ ...current, apiKey: "" }));
      }

      // Request optional host permission for the LLM endpoint if configured
      if (normalizedBase && typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
        chrome.runtime.sendMessage(
          { type: "ATHENA_REQUEST_LLM_PERMISSION", baseUrl: normalizedBase },
          (resp: { ok: boolean; granted?: boolean; error?: string } | undefined) => {
            if (chrome.runtime?.lastError || !resp || !resp.ok) {
              setPermissionStatus("error");
            } else if (resp.granted) {
              setPermissionStatus("granted");
            } else {
              setPermissionStatus("denied");
            }
          }
        );
      }
    } catch {
      console.error("[Athena] Failed to save settings.");
    }
  };

  const handleReset = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    const defaults = currentRepoKey ? config?.defaultPolicy ?? DEFAULT_REPO_POLICY : DEFAULT_REPO_POLICY;
    setPolicy({
      blockMergeToMain: defaults.blockMergeToMain,
      requirePassingChecks: defaults.requirePassingChecks,
      secretToggles: { ...defaults.secretToggles },
    });
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div
      ref={dialogRef}
      role="dialog"
      aria-modal="true"
      aria-labelledby="athena-settings-title"
      className="athena-modal-backdrop"
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: "var(--overlay)",
        backdropFilter: "blur(6px)",
        WebkitBackdropFilter: "blur(6px)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 2147483647,
        pointerEvents: "auto",
        fontFamily: "var(--font-sans)",
      }}
      onClick={(e) => {
        e.stopPropagation();
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <style>{`
        .athena-btn:focus-visible, .athena-input:focus-visible, .athena-checkbox:focus-visible {
          outline: 2px solid var(--accent) !important;
          outline-offset: 2px !important;
        }
      `}</style>
      <div
        className="athena-settings-modal"
        onClick={(e) => {
          e.stopPropagation();
        }}
        style={{
          width: "580px",
          maxWidth: "94vw",
          maxHeight: "88vh",
          backgroundColor: "var(--bg-subtle)",
          border: "1px solid var(--border-soft)",
          borderRadius: "14px",
          boxShadow: "0 24px 48px -12px var(--bg-inset), 0 0 24px var(--border-soft)",
          color: "var(--fg)",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
        }}
      >
        {/* Header */}
        <div
          style={{
            padding: "16px 20px",
            borderBottom: "1px solid var(--border-soft)",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            background: "var(--bg-canvas)",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
            <div
              style={{
                width: "36px",
                height: "36px",
                borderRadius: "10px",
                background: "var(--bg-subtle)",
                border: "1px solid var(--border-soft)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "18px",
                boxShadow: "0 0 12px var(--border-soft)",
              }}
            >
              <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="18" height="18">
                <path d="M12 2.5 20 5v5.8c0 5.2-3.4 8.8-8 10.7-4.6-1.9-8-5.5-8-10.7V5z" />
              </svg>
            </div>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                <h2 id="athena-settings-title" style={{ margin: 0, fontSize: "15px", fontWeight: 700, color: "var(--fg)", letterSpacing: "-0.01em" }}>
                  Athena Rules & Policy Settings
                </h2>
                <span
                  style={{
                    fontSize: "10px",
                    fontWeight: 700,
                    textTransform: "uppercase",
                    letterSpacing: "0.06em",
                    padding: "2px 6px",
                    borderRadius: "4px",
                    background: "var(--border-soft)",
                    border: "1px solid var(--border-soft)",
                    color: "var(--fg-muted)",
                  }}
                >
                  Guardrails
                </span>
              </div>
              <p style={{ margin: "2px 0 0", fontSize: "11.5px", color: "var(--fg-muted)" }}>
                Configure repository safety guardrails and detector patterns
              </p>
            </div>
          </div>
          <button
            ref={closeButtonRef}
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            className="athena-btn"
            style={{
              background: "var(--border-soft)",
              border: "1px solid var(--border-soft)",
              color: "var(--fg-muted)",
              fontSize: "15px",
              cursor: "pointer",
              width: "28px",
              height: "28px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              borderRadius: "8px",
            }}
            aria-label="Close"
          >
            ✕
          </button>
        </div>

        {/* Body Content */}
        <div style={{ padding: "18px 20px", overflowY: "auto", display: "flex", flexDirection: "column", gap: "18px" }}>
          {/* Target Repo Scope */}
          <div
            style={{
              background: "var(--bg-subtle)",
              border: "1px solid var(--border-soft)",
              borderRadius: "10px",
              padding: "14px",
              boxShadow: "inset 0 1px 0 var(--border-soft)",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "8px" }}>
              <label
                style={{
                  display: "block",
                  fontSize: "11px",
                  fontWeight: 700,
                  color: "var(--fg-muted)",
                  textTransform: "uppercase",
                  letterSpacing: "0.06em",
                }}
              >
                Policy Scope / Target Repository
              </label>
              <span style={{ fontSize: "11px", color: "var(--fg-subtle)" }}>
                {currentRepoKey ? "Custom policy active" : "Global fallback active"}
              </span>
            </div>
            <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
              <input
                type="text"
                className="athena-input"
                placeholder="e.g. owner/repo or leave blank for default"
                value={currentRepoKey}
                onChange={(e) => handleRepoChange(e.target.value)}
                style={{
                  flex: 1,
                  background: "var(--bg-subtle)",
                  border: "1px solid var(--border-soft)",
                  borderRadius: "8px",
                  color: "var(--fg)",
                  fontSize: "12px",
                  padding: "7px 12px",
                  fontFamily: "ui-monospace, monospace",
                }}
              />
              <button
                type="button"
                className="athena-btn"
                onClick={() => handleRepoChange("")}
                style={{
                  background: !currentRepoKey ? "var(--border-soft)" : "var(--border-soft)",
                  color: !currentRepoKey ? "var(--fg-muted)" : "var(--fg-muted)",
                  border: !currentRepoKey ? "1px solid var(--border-soft)" : "1px solid var(--border-soft)",
                  borderRadius: "8px",
                  fontSize: "11.5px",
                  fontWeight: 600,
                  padding: "7px 14px",
                  cursor: "pointer",
                  whiteSpace: "nowrap",
                }}
              >
                Default / Global
              </button>
            </div>
            <p style={{ margin: "7px 0 0", fontSize: "11px", color: "var(--fg-subtle)", lineHeight: "1.4" }}>
              {currentRepoKey
                ? `Editing custom rules policy for ${currentRepoKey}`
                : "Editing global default rules policy (applied to repos without custom rules)"}
            </p>
          </div>

          {/* Merge Protection Policies */}
          <div>
            <h3
              style={{
                fontSize: "11px",
                fontWeight: 700,
                color: "var(--fg-muted)",
                textTransform: "uppercase",
                letterSpacing: "0.06em",
                margin: "0 0 10px 0",
                display: "flex",
                alignItems: "center",
                gap: "6px",
              }}
            >
              <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" width="14" height="14"><path d="m13 2-9 12h7l-1 8 10-13h-7z" /></svg> PR & Merge Guardrails
            </h3>
            <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
              {/* Block merge to main */}
              <label
                style={{
                  display: "flex",
                  alignItems: "flex-start",
                  gap: "12px",
                  background: "var(--bg-subtle)",
                  border: "1px solid var(--border-soft)",
                  borderRadius: "10px",
                  padding: "12px 14px",
                  cursor: "pointer",
                }}
              >
                <input
                  type="checkbox"
                  className="athena-checkbox"
                  checked={policy.blockMergeToMain}
                  onChange={(e) =>
                    setPolicy((prev) => ({ ...prev, blockMergeToMain: e.target.checked }))
                  }
                  style={{ marginTop: "2px", cursor: "pointer", accentColor: "var(--accent)", width: "16px", height: "16px" }}
                />
                <div>
                  <div style={{ fontSize: "13px", fontWeight: 600, color: "var(--fg)" }}>
                    Block merging directly to main / master
                  </div>
                  <div style={{ fontSize: "11.5px", color: "var(--fg-muted)", marginTop: "2px", lineHeight: "1.4" }}>
                    Warns and intercepts standard merge button if the base branch is main or master without override.
                  </div>
                </div>
              </label>

              {/* Require passing checks */}
              <label
                style={{
                  display: "flex",
                  alignItems: "flex-start",
                  gap: "12px",
                  background: "var(--bg-subtle)",
                  border: "1px solid var(--border-soft)",
                  borderRadius: "10px",
                  padding: "12px 14px",
                  cursor: "pointer",
                }}
              >
                <input
                  type="checkbox"
                  className="athena-checkbox"
                  checked={policy.requirePassingChecks}
                  onChange={(e) =>
                    setPolicy((prev) => ({ ...prev, requirePassingChecks: e.target.checked }))
                  }
                  style={{ marginTop: "2px", cursor: "pointer", accentColor: "var(--accent)", width: "16px", height: "16px" }}
                />
                <div>
                  <div style={{ fontSize: "13px", fontWeight: 600, color: "var(--fg)" }}>
                    Require passing CI checks before merge
                  </div>
                  <div style={{ fontSize: "11.5px", color: "var(--fg-muted)", marginTop: "2px", lineHeight: "1.4" }}>
                    Warns if any CI checks are failing or still in progress before merging.
                  </div>
                </div>
              </label>
            </div>
          </div>

          {/* Secret Scanner Detector Patterns */}
          <div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: "10px",
              }}
            >
              <h3
                style={{
                  fontSize: "11px",
                  fontWeight: 700,
                  color: "var(--fg-muted)",
                  textTransform: "uppercase",
                  letterSpacing: "0.06em",
                  margin: 0,
                  display: "flex",
                  alignItems: "center",
                  gap: "6px",
                }}
              >
                <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" width="14" height="14"><circle cx="10.5" cy="10.5" r="6.5" /><path d="m15.5 15.5 5 5" /></svg> Secret Scanner Patterns
              </h3>
              <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
                <button
                  type="button"
                  className="athena-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    setAllSecrets(true);
                  }}
                  style={{
                    background: "var(--border-soft)",
                    border: "1px solid var(--border-soft)",
                    color: "var(--fg-muted)",
                    fontSize: "11px",
                    fontWeight: 600,
                    cursor: "pointer",
                    padding: "3px 8px",
                    borderRadius: "5px",
                  }}
                >
                  Enable All
                </button>
                <button
                  type="button"
                  className="athena-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    setAllSecrets(false);
                  }}
                  style={{
                    background: "var(--border-soft)",
                    border: "1px solid var(--border-soft)",
                    color: "var(--fg-muted)",
                    fontSize: "11px",
                    fontWeight: 600,
                    cursor: "pointer",
                    padding: "3px 8px",
                    borderRadius: "5px",
                  }}
                >
                  Disable All
                </button>
              </div>
            </div>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
                gap: "8px",
              }}
            >
              {ALL_SECRET_PATTERNS.map((pattern) => {
                const isEnabled = policy.secretToggles[pattern.id] !== false;
                return (
                  <label
                    key={pattern.id}
                    style={{
                      display: "flex",
                      alignItems: "flex-start",
                      gap: "9px",
                      background: isEnabled ? "var(--bg-subtle)" : "var(--bg-subtle)",
                      border: isEnabled ? "1px solid var(--border-soft)" : "1px solid var(--border-soft)",
                      borderRadius: "8px",
                      padding: "9px 11px",
                      cursor: "pointer",
                      opacity: isEnabled ? 1 : 0.65,
                    }}
                  >
                    <input
                      type="checkbox"
                      className="athena-checkbox"
                      checked={isEnabled}
                      onChange={() => toggleSecretPattern(pattern.id)}
                      style={{ marginTop: "2px", cursor: "pointer", accentColor: "var(--accent)" }}
                    />
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: "12px", fontWeight: 600, color: "var(--fg)" }}>
                        {pattern.label}
                      </div>
                      <div
                        style={{
                          fontSize: "10.5px",
                          color: "var(--fg-muted)",
                          marginTop: "2px",
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                        }}
                      >
                        {pattern.description}
                      </div>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>

          {/* LLM Configuration (for "Explain this" & Active Panel) */}
          <div
            style={{
              background: "var(--bg-subtle)",
              border: "1px solid var(--border-soft)",
              borderRadius: "10px",
              padding: "14px",
              boxShadow: "0 0 16px var(--border-soft)",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
              <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="16" height="16"><path d="m12 3 1.6 6.4L20 11l-6.4 1.6L12 19l-1.6-6.4L4 11l6.4-1.6z M19 3v4m-2-2h4" /></svg>
              <h3
                style={{
                  fontSize: "11.5px",
                  fontWeight: 700,
                  color: "var(--fg-muted)",
                  textTransform: "uppercase",
                  letterSpacing: "0.06em",
                  margin: 0,
                }}
              >
                LLM Configuration ("Explain this" & Active Panel)
              </h3>
            </div>
            <p style={{ margin: "0 0 12px 0", fontSize: "11.5px", color: "var(--fg-muted)", lineHeight: "1.4" }}>
              Saved locally in your browser until you remove it. Sent only to the endpoint you configure.
            </p>

            <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
              <div>
                <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--fg-muted)", marginBottom: "4px" }}>
                  API Key (Required for AI features)
                </label>
                {!editingApiKey && hasApiKey ? <div style={{ display: "flex", alignItems: "center", gap: "8px" }}><span style={{ flex: 1, fontFamily: "ui-monospace, monospace", fontSize: "12px" }}>{maskedApiKey}</span><button type="button" onClick={() => setEditingApiKey(true)} className="athena-btn">Change</button><button type="button" onClick={async () => { await saveSettings({ apiKey: undefined }); setHasApiKey(false); setMaskedApiKey(""); setEditingApiKey(true); }} className="athena-btn">Remove saved key</button></div> : <input
                  type="password"
                  className="athena-input"
                  placeholder="sk-... or sk-proj-..."
                  value={llm.apiKey}
                  onChange={(e) => setLlm((prev) => ({ ...prev, apiKey: e.target.value }))}
                  style={{
                    width: "100%",
                    boxSizing: "border-box",
                    background: "var(--bg-subtle)",
                    border: "1px solid var(--border-soft)",
                    borderRadius: "8px",
                    color: "var(--fg)",
                    fontSize: "12px",
                    padding: "7px 12px",
                    fontFamily: "ui-monospace, monospace",
                  }}
                />}
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "10px" }}>
                <div>
                  <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--fg-muted)", marginBottom: "4px" }}>
                    Base URL (Optional, default OpenAI)
                  </label>
                  <input
                    type="text"
                    className="athena-input"
                    placeholder="https://api.openai.com/v1"
                    value={llm.baseUrl}
                    onChange={(e) => setLlm((prev) => ({ ...prev, baseUrl: e.target.value }))}
                    style={{
                      width: "100%",
                      boxSizing: "border-box",
                      background: "var(--bg-subtle)",
                      border: "1px solid var(--border-soft)",
                      borderRadius: "8px",
                      color: "var(--fg)",
                      fontSize: "12px",
                      padding: "7px 12px",
                      fontFamily: "ui-monospace, monospace",
                    }}
                  />
                  <p style={{ margin: "4px 0 0 0", fontSize: "10.5px", color: "var(--fg-subtle)" }}>
                    OpenAI or Ollama (http://localhost:11434/v1)
                  </p>
                </div>

                <div>
                  <label style={{ display: "block", fontSize: "11px", fontWeight: 600, color: "var(--fg-muted)", marginBottom: "4px" }}>
                    Model
                  </label>
                  <input
                    type="text"
                    className="athena-input"
                    placeholder="gpt-4o-mini"
                    value={llm.model}
                    onChange={(e) => setLlm((prev) => ({ ...prev, model: e.target.value }))}
                    style={{
                      width: "100%",
                      boxSizing: "border-box",
                      background: "var(--bg-subtle)",
                      border: "1px solid var(--border-soft)",
                      borderRadius: "8px",
                      color: "var(--fg)",
                      fontSize: "12px",
                      padding: "7px 12px",
                      fontFamily: "ui-monospace, monospace",
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div
          style={{
            padding: "14px 20px",
            borderTop: "1px solid var(--border-soft)",
            background: "var(--bg-subtle)",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleReset(e);
              }}
              className="athena-btn"
              style={{
                background: "var(--border-soft)",
                border: "1px solid var(--border-soft)",
                color: "var(--fg-muted)",
                borderRadius: "8px",
                fontSize: "11.5px",
                fontWeight: 600,
                padding: "6px 12px",
                cursor: "pointer",
              }}
            >
              Reset
            </button>
            {permissionStatus === "granted" && (
              <span style={{ fontSize: "11px", color: "var(--fg-muted)", fontWeight: 600 }}>
                ✓ LLM endpoint access granted
              </span>
            )}
            {permissionStatus === "denied" && (
              <span style={{ fontSize: "11px", color: "var(--fg-muted)", fontWeight: 600 }}>
                LLM endpoint access denied — "Explain this" will not work
              </span>
            )}
            {permissionStatus === "error" && (
              <span style={{ fontSize: "11px", color: "var(--fg-muted)", fontWeight: 600 }}>
                ✕ Could not request endpoint permission
              </span>
            )}
          </div>

          <div style={{ display: "flex", gap: "8px" }}>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onClose();
              }}
              className="athena-btn"
              style={{
                background: "var(--border-soft)",
                border: "1px solid var(--border-soft)",
                color: "var(--fg-muted)",
                borderRadius: "8px",
                fontSize: "12px",
                fontWeight: 600,
                padding: "7px 14px",
                cursor: "pointer",
              }}
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                void handleSave(e);
              }}
              className="athena-btn"
              style={{
                background: "var(--success-emphasis)",
                border: "1px solid var(--border-soft)",
                color: "var(--fg)",
                borderRadius: "8px",
                fontSize: "12px",
                fontWeight: 600,
                padding: "7px 18px",
                cursor: "pointer",
                boxShadow: "0 2px 8px var(--border-soft)",
              }}
            >
              Save Policy
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

