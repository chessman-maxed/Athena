/**
 * Athena – Shadow DOM UI layer.
 *
 * Creates an inline warning banner injected ABOVE the intercepted button.
 * All styles live inside a Shadow DOM so GitHub's CSS cannot bleed in.
 */

import type { Rule } from "./rules";
import { primerTokenStyles } from "../ui/tokens";
import { createOcticon } from "../ui/icons";
import { announceAthenaWarning, fadeOutAthenaHost } from "../ui/motion";

// ─── CSS for the Shadow DOM ───────────────────────────────────────────────────
const SHADOW_CSS = `
  :host{position:fixed;inset:0;z-index:2147483647;display:grid;place-items:center;padding:16px;font-family:var(--font-sans);color:var(--fg)}
  .athena-backdrop{position:absolute;inset:0;display:grid;place-items:center;padding:16px;background:rgba(0,0,0,.68);backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px)}
  .athena-dialog{position:relative;width:min(100%,420px);max-height:min(90vh,560px);overflow:auto;padding:18px;border:1px solid rgba(239,68,68,.48);border-left:3px solid #ef4444;border-radius:10px;background:#0a0a0a;box-shadow:0 0 28px rgba(239,68,68,.12),0 20px 70px rgba(0,0,0,.65);outline:none}
  .athena-header{display:flex;align-items:center;gap:10px;padding-bottom:12px;border-bottom:1px solid rgba(255,255,255,.08)}
  .athena-icon{display:grid;place-items:center;width:34px;height:34px;flex:0 0 34px;border:1px solid rgba(239,68,68,.35);border-radius:7px;background:rgba(239,68,68,.1);color:#f87171}
  .athena-icon svg{width:19px;height:19px}.athena-heading{min-width:0;flex:1}.athena-title{display:block;color:#fff;font:700 12px/1.3 var(--font-mono);letter-spacing:.08em}.athena-subtitle{display:block;margin-top:3px;color:#f87171;font:700 9px/1.2 var(--font-mono);letter-spacing:.1em}
  .athena-badge{padding:4px 6px;border:1px solid rgba(239,68,68,.4);border-radius:4px;color:#f87171;font:700 8px/1 var(--font-mono);letter-spacing:.08em}
  .athena-intro{margin:12px 0 10px;color:#a3a3a3;font-size:11px;line-height:1.45}
  .athena-details{display:grid;gap:8px;margin:0}.athena-detail{padding:9px 10px;border:1px solid rgba(255,255,255,.07);border-radius:6px;background:#121212}.athena-detail dt{margin-bottom:4px;color:#737373;font:700 8px/1 var(--font-mono);letter-spacing:.1em}.athena-detail dd{margin:0;color:#fff;font-size:12px;font-weight:600;overflow-wrap:anywhere}.athena-detail dd.technical{color:#fca5a5;font:11px/1.4 var(--font-mono)}
  .athena-warning{display:flex;gap:8px;align-items:flex-start;margin-top:10px;padding:9px 10px;border:1px solid rgba(239,68,68,.24);border-radius:6px;background:rgba(239,68,68,.08);color:#fca5a5;font-size:10px;line-height:1.4}.athena-warning svg{width:14px;height:14px;flex:0 0 14px}
  .athena-confirm-row{display:flex;align-items:center;justify-content:flex-end;gap:10px;flex-wrap:wrap;margin-top:12px;padding-top:11px;border-top:1px solid rgba(255,255,255,.08)}
  .athena-actions{display:flex;gap:7px;margin-left:auto}.athena-actions button{min-height:32px;padding:7px 11px;border:1px solid rgba(255,255,255,.12);border-radius:5px;font:700 9px/1 var(--font-mono);letter-spacing:.06em;cursor:pointer;transition:background .15s ease,border-color .15s ease,transform .15s ease}.athena-actions button:hover:enabled{transform:translateY(-1px)}
  .athena-cancel{background:#171717;color:#d4d4d4}.athena-cancel:hover{border-color:rgba(255,255,255,.26);background:#222}
  .athena-proceed-btn{border-color:rgba(239,68,68,.58)!important;background:rgba(127,29,29,.5);color:#fecaca}.athena-proceed-btn:disabled{opacity:.38;cursor:not-allowed}.athena-proceed-btn:enabled:hover{border-color:#ef4444!important;background:#7f1d1d}
  .athena-actions button:focus-visible{outline:2px solid #00f0ff;outline-offset:2px}
  @media(max-width:480px){.athena-dialog{padding:14px}.athena-actions{width:100%;margin:0}.athena-actions button{flex:1}}
  @media(prefers-reduced-motion:reduce){.athena-actions button{transition:none}}
`;

// ─── Severity display helpers ─────────────────────────────────────────────────
function severityIcon(severity: Rule["severity"]): "alert" | "warning" {
  return severity === "critical" ? "alert" : "warning";
}

function severityLabel(severity: Rule["severity"]): string {
  return severity === "critical" ? "CRITICAL" : "DANGER";
}

// ─── Banner creation ──────────────────────────────────────────────────────────

interface BannerOptions {
  rule: Rule;
  repository: string;
  onProceed: () => void;
  onCancel: () => void;
}

/**
 * Create a host <div> that holds a Shadow DOM containing the Athena banner.
 * Returns the host element so the caller can inject it into the real DOM.
 */
export function createBannerHost({ rule, repository, onProceed, onCancel }: BannerOptions): HTMLDivElement {
  const host = document.createElement("div");
  host.dataset.athenaHost = rule.id;
  host.dataset.athenaThemeHost = "";

  const shadow = host.attachShadow({ mode: "open" });

  // Inject styles
  const style = document.createElement("style");
  style.textContent = `${primerTokenStyles}\n${SHADOW_CSS}`;
  shadow.appendChild(style);

  const backdrop = document.createElement("div");
  backdrop.className = "athena-backdrop";
  const dialog = document.createElement("section");
  dialog.className = "athena-dialog";
  dialog.setAttribute("role", "alertdialog");
  dialog.setAttribute("aria-modal", "true");
  dialog.setAttribute("aria-labelledby", `athena-title-${rule.id}`);
  dialog.setAttribute("aria-describedby", `athena-risk-${rule.id} athena-warning-${rule.id}`);
  dialog.tabIndex = -1;

  // Header row
  const header = document.createElement("div");
  header.className = "athena-header";

  const iconEl = document.createElement("span");
  iconEl.className = "athena-icon";
  iconEl.appendChild(createOcticon(severityIcon(rule.severity), 20));

  const titleEl = document.createElement("span");
  titleEl.className = "athena-title";
  titleEl.textContent = "ATHENA SECURITY WARNING";
  titleEl.id = `athena-title-${rule.id}`;

  const badge = document.createElement("span");
  badge.className = "athena-badge";
  badge.textContent = severityLabel(rule.severity);

  header.appendChild(iconEl);
  header.appendChild(titleEl);
  header.appendChild(badge);

  const heading = document.createElement("div"); heading.className = "athena-heading";
  titleEl.className = "athena-title";
  const subtitle = document.createElement("span"); subtitle.className = "athena-subtitle"; subtitle.textContent = "CRITICAL ACTION DETECTED";
  heading.append(titleEl, subtitle);

  const intro = document.createElement("p"); intro.className = "athena-intro"; intro.textContent = "Athena paused this action so you can review its impact before continuing.";
  const details = document.createElement("dl"); details.className = "athena-details";
  const addDetail = (label: string, value: string, technical = false) => {
    const row = document.createElement("div"); row.className = "athena-detail";
    const term = document.createElement("dt"); term.textContent = label;
    const description = document.createElement("dd"); description.textContent = value;
    if (technical) description.className = "technical";
    row.append(term, description); details.append(row);
  };
  addDetail("ACTION", rule.actionType.toUpperCase());
  addDetail("REPOSITORY", repository || "GitHub", true);
  addDetail("RISK", rule.consequence);

  const warning = document.createElement("div"); warning.className = "athena-warning"; warning.id = `athena-warning-${rule.id}`;
  warning.append(createOcticon("alert", 14), document.createTextNode("This action may cause irreversible changes."));

  // Confirmation row
  const confirmRow = document.createElement("div");
  confirmRow.className = "athena-confirm-row";

  const proceedBtn = document.createElement("button");
  proceedBtn.type = "button";
  proceedBtn.className = "athena-proceed-btn athena-danger-btn";
  proceedBtn.textContent = "CONTINUE";
  proceedBtn.id = `athena-continue-${rule.id}`;
  const cancelBtn = document.createElement("button");
  cancelBtn.type = "button";
  cancelBtn.className = "athena-cancel";
  cancelBtn.textContent = "CANCEL";

  proceedBtn.addEventListener("click", () => {
    if (proceedBtn.disabled) return;
    fadeOutAthenaHost(host, onProceed);
  });
  cancelBtn.addEventListener("click", () => fadeOutAthenaHost(host, onCancel));

  const actions = document.createElement("div"); actions.className = "athena-actions";
  actions.append(cancelBtn, proceedBtn);

  confirmRow.appendChild(actions);
  const risk = details.querySelector("dd:last-child")!; risk.id = `athena-risk-${rule.id}`;

  header.append(iconEl, heading, badge);
  dialog.append(header, intro, details, warning, confirmRow);
  backdrop.append(dialog);
  shadow.append(backdrop);

  // Keep keyboard focus inside the modal. Escape is equivalent to the safe Cancel action.
  const focusable = () => [...dialog.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled)')];
  dialog.addEventListener("keydown", (event) => {
    if (event.key === "Escape") { event.preventDefault(); cancelBtn.click(); return; }
    if (event.key !== "Tab") return;
    const items = focusable();
    if (!items.length) { event.preventDefault(); dialog.focus(); return; }
    const first = items[0]; const last = items[items.length - 1];
    if (event.shiftKey && (shadow.activeElement === first || shadow.activeElement === dialog)) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && shadow.activeElement === last) { event.preventDefault(); first.focus(); }
  });
  requestAnimationFrame(() => cancelBtn.focus());
  announceAthenaWarning();
  return host;
}
