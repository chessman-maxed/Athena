import type { OcticonName } from "../ui/icons";

/**
 * Athena – Beginner Tier: "Teach & Guide" tooltip definitions.
 *
 * Each entry maps a DOM selector (matching a GitHub UI element) to a
 * plain-English explanation that is shown in a tooltip overlay BEFORE
 * the user clicks the element.
 *
 * This is the single source of truth for all tooltip text.
 * Edit body / title here; no other files need changing.
 *
 * Fields:
 *  - id          : unique stable ID
 *  - selector    : CSS selector used by querySelectorAll to find the element
 *  - title       : short action name shown in the tooltip header
 *  - body        : ONE plain-English explanation sentence
 *  - icon        : emoji icon for the tooltip header
 *  - showPreview : when true, the UI adds a DOM-scraped "what will happen" card
 *  - learnMore   : optional URL to GitHub docs
 */

export interface TooltipDef {
  id: string;
  selector: string;
  title: string;
  body: string;
  icon: OcticonName;
  /** When true, the tooltip UI will add a live DOM-scraped "what will happen" preview. */
  showPreview?: boolean;
  learnMore?: string;
}

export const TOOLTIP_DEFS: TooltipDef[] = [
  // ── Repository-level ────────────────────────────────────────────────────────
  {
    id: "fork",
    selector: [
      'a[href$="/fork"]',
      'button[data-ga-click*="fork"]',
      ".octotree-btn-fork",
    ].join(", "),
    title: "Fork a Repository",
    icon: "branch",
    body:
      "Forking creates your own personal copy of someone else's repository under your GitHub account — " +
      "you can freely experiment without affecting the original, then propose changes back via a Pull Request.",
    learnMore:
      "https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/working-with-forks/about-forks",
  },
  {
    id: "clone",
    selector: [
      'button[data-hydro-click*="clone"]',
      "#local-panel button.btn-primary",
      'clipboard-copy[aria-label*="Clone"]',
      'a[aria-label*="clone"]',
    ].join(", "),
    title: "Clone a Repository",
    icon: "arrow",
    body:
      "Cloning downloads a full copy of the repository (including its entire history) to your local computer " +
      "so you can edit files offline and push changes back when ready.",
    learnMore:
      "https://docs.github.com/en/repositories/creating-and-managing-repositories/cloning-a-repository",
  },
  {
    id: "star",
    selector: [
      'button[aria-label*="Star this repository"]',
      ".starred button",
      "form.js-social-form button",
    ].join(", "),
    title: "Star a Repository",
    icon: "check",
    body:
      "Starring bookmarks a repository to your personal starred list and signals appreciation to its maintainers — " +
      "more stars means more community visibility.",
  },

  // ── Branch management ───────────────────────────────────────────────────────
  {
    id: "create-branch",
    selector: [
      ".branch-select-menu summary",
      ".ref-selector-class button",
      'button[aria-label*="Switch branches"]',
      'summary[aria-label*="branch"]',
    ].join(", "),
    title: "Switch / Create a Branch",
    icon: "branch",
    body:
      "Branches let you work on a feature or fix in isolation without touching the main codebase — " +
      "when your work is done, open a Pull Request to merge it back.",
    learnMore:
      "https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/about-branches",
  },
  {
    id: "delete-branch",
    selector: [
      'button[data-ga-click*="delete branch"]',
      ".post-merge-message button",
      'form[action*="/delete"] button',
      'button[data-confirm*="branch"]',
    ].join(", "),
    title: "Delete Branch",
    icon: "cancel",
    body:
      "Permanently removes this branch from the remote repository — safe to do after a PR is merged, " +
      "and GitHub lets you restore it afterwards if needed.",
    showPreview: true,
    learnMore:
      "https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-branches-in-your-repository/deleting-and-restoring-branches-in-a-pull-request",
  },

  // ── Pull Request workflow ───────────────────────────────────────────────────
  {
    id: "create-pr",
    selector: [
      'a[href*="/compare"]',
      'a[data-ga-click*="pull request"]',
      ".btn-primary[href*='pull']",
    ].join(", "),
    title: "Open a Pull Request",
    icon: "arrow",
    body:
      "A Pull Request lets you propose changes to a repo: collaborators can review, comment, and approve " +
      "before your commits are merged into the main codebase.",
    learnMore:
      "https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/proposing-changes-to-your-work-with-pull-requests/about-pull-requests",
  },
  {
    id: "merge-pr",
    selector: [
      ".js-merge-commit-button",
      'button[data-details-container*="merge"]',
      ".merge-box button.btn-primary",
    ].join(", "),
    title: "Merge Pull Request",
    icon: "merge",
    body:
      "Creates a merge commit that incorporates all PR commits into the target branch, " +
      "preserving the full branch history so you can always see where the changes came from.",
    showPreview: true,
    learnMore:
      "https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/incorporating-changes-from-a-pull-request/merging-a-pull-request",
  },
  {
    id: "squash-pr",
    selector: [
      ".js-merge-squash-button",
      'button[data-ga-click*="squash"]',
      '.merge-box button[value="squash"]',
      'button[aria-label*="Squash and merge"]',
    ].join(", "),
    title: "Squash and Merge",
    icon: "gear",
    body:
      "Collapses all commits from this PR into a single commit on the target branch, " +
      "keeping the main branch history clean and linear.",
    showPreview: true,
    learnMore:
      "https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/incorporating-changes-from-a-pull-request/about-pull-request-merges#squash-and-merge-your-commits",
  },
  {
    id: "rebase-pr",
    selector: [
      ".js-merge-rebase-button",
      'button[data-ga-click*="rebase"]',
      '.merge-box button[value="rebase"]',
      'button[aria-label*="Rebase and merge"]',
    ].join(", "),
    title: "Rebase and Merge",
    icon: "branch",
    body:
      "Replays each PR commit on top of the target branch without a merge commit, " +
      "giving a perfectly linear history — note that commit SHAs are rewritten.",
    showPreview: true,
    learnMore:
      "https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/incorporating-changes-from-a-pull-request/about-pull-request-merges#rebase-and-merge-your-commits",
  },
];
