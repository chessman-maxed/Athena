/**
 * Unit tests for src/storage/session.ts
 *
 * Tests all chrome.storage.session helpers:
 *  - Session log
 *  - LLM settings
 *  - GitHub PAT & strict api.github.com security constraint
 *  - Rule toggles & toggle cache
 *  - Dismissed warnings & dismissed cache
 */

import { describe, it, expect, beforeEach, vi } from "vitest";
import {
  loadLog,
  logConfirmedAction,
  wasAlreadyConfirmed,
  loadActivityLog,
  logActivity,
  loadSettings,
  saveSettings,
  hasLLMConsent,
  setLLMConsent,
  getGitHubAuthHeaders,
  saveToggles,
  isRuleEnabled,
  initToggleCache,
  loadDismissedWarnings,
  dismissWarning,
  isWarningDismissed,
  isWarningDismissedSync,
  clearDismissedWarnings,
  initDismissedCache,
  loadRulesConfig,
  saveRulesConfig,
  getRepoPolicySync,
  saveRepoPolicy,
  isSecretPatternEnabledForRepo,
  initRulesConfigCache,
  normalizeRepoKey,
  DEFAULT_REPO_POLICY,
} from "./session";

// ── In-memory chrome.storage.session mock ─────────────────────────────────────

let store: Record<string, unknown> = {};
let localStore: Record<string, unknown> = {};
let changeListeners: Array<(changes: Record<string, { newValue: unknown }>) => void> = [];
let localChangeListeners: Array<(changes: Record<string, { newValue: unknown }>, areaName: string) => void> = [];

function readKeys(source: Record<string, unknown>, key: string | string[]): Record<string, unknown> {
  const keys = Array.isArray(key) ? key : [key];
  return Object.fromEntries(keys.filter((name) => Object.prototype.hasOwnProperty.call(source, name)).map((name) => [name, source[name]]));
}

function setupChromeMock() {
  store = {};
  localStore = {};
  changeListeners = [];
  localChangeListeners = [];

  const mockChrome = {
    storage: {
      session: {
        get: vi.fn((key: string | string[], callback: (result: Record<string, unknown>) => void) => {
          callback(readKeys(store, key));
        }),
        set: vi.fn((data: Record<string, unknown>, callback?: () => void) => {
          const changes: Record<string, { newValue: unknown }> = {};
          for (const k in data) {
            store[k] = data[k];
            changes[k] = { newValue: data[k] };
          }
          if (callback) callback();
          for (const listener of changeListeners) {
            listener(changes);
          }
        }),
        onChanged: {
          addListener: vi.fn((listener: (changes: Record<string, { newValue: unknown }>) => void) => {
            changeListeners.push(listener);
          }),
        },
        setAccessLevel: vi.fn((_opts, callback?: () => void) => {
          if (callback) callback();
        }),
      },
      local: {
        get: vi.fn((key: string | string[], callback: (result: Record<string, unknown>) => void) => {
          callback(readKeys(localStore, key));
        }),
        set: vi.fn((data: Record<string, unknown>, callback?: () => void) => {
          Object.assign(localStore, data);
          callback?.();
          const changes: Record<string, { newValue: unknown }> = {};
          for (const k in data) changes[k] = { newValue: data[k] };
          for (const listener of localChangeListeners) listener(changes, "local");
        }),
        remove: vi.fn((keys: string | string[], callback?: () => void) => {
          for (const key of Array.isArray(keys) ? keys : [keys]) delete localStore[key];
          callback?.();
        }),
      },
      onChanged: {
        addListener: vi.fn((listener: (changes: Record<string, { newValue: unknown }>, areaName: string) => void) => {
          localChangeListeners.push(listener);
        }),
      },
    },
  };

  vi.stubGlobal("chrome", mockChrome);
}

describe("src/storage/session.ts", () => {
  beforeEach(() => {
    setupChromeMock();
  });

  // ── Session Log ─────────────────────────────────────────────────────────────

  describe("Session Log", () => {
    it("starts with empty log", async () => {
      const log = await loadLog();
      expect(log).toEqual([]);
    });

    it("logs a confirmed action and checks wasAlreadyConfirmed", async () => {
      await logConfirmedAction({
        ruleId: "delete-repository",
        actionType: "Delete Repository",
        url: "https://github.com/owner/repo/settings",
      });

      const log = await loadLog();
      expect(log.length).toBe(1);
      expect(log[0].ruleId).toBe("delete-repository");
      expect(log[0].actionType).toBe("Delete Repository");
      expect(log[0].url).toBe("https://github.com/owner/repo/settings");
      expect(typeof log[0].confirmedAt).toBe("number");

      const confirmed = await wasAlreadyConfirmed(
        "delete-repository",
        "https://github.com/owner/repo/settings"
      );
      expect(confirmed).toBe(true);

      const notConfirmed = await wasAlreadyConfirmed(
        "archive-repository",
        "https://github.com/owner/repo/settings"
      );
      expect(notConfirmed).toBe(false);
    });
  });

  describe("Activity Log", () => {
    it("stores the activity schema and deduplicates warning-shown by rule and URL", async () => {
      const event = {
        type: "warning-shown" as const,
        ruleId: "delete-branch",
        label: "Delete Branch",
        repo: "owner/repo",
      };
      const url = "https://github.com/owner/repo/pull/12";

      await Promise.all([
        logActivity(event, url),
        logActivity(event, url),
      ]);

      const log = await loadActivityLog();
      expect(log).toHaveLength(1);
      expect(Object.keys(log[0]).sort()).toEqual(["label", "repo", "ruleId", "timestamp", "type"]);
      expect(log[0]).toMatchObject(event);
      expect(typeof log[0].timestamp).toBe("number");
    });
  });

  // ── LLM Settings ────────────────────────────────────────────────────────────

  describe("LLM Settings", () => {
    it("persists the enabled preference in local storage across fresh reads", async () => {
      await setLLMConsent(true);
      expect(localStore.athena_llm_consent_acknowledged).toBe(true);
      expect(store.athena_llm_consent_acknowledged).toBeUndefined();
      expect(await hasLLMConsent()).toBe(true);

      await setLLMConsent(false);
      expect(localStore.athena_llm_consent_acknowledged).toBe(false);
      expect(await hasLLMConsent()).toBe(false);
    });

    it("migrates the legacy session preference to local storage once", async () => {
      store.athena_llm_consent_acknowledged = true;
      expect(await hasLLMConsent()).toBe(true);
      expect(localStore.athena_llm_consent_acknowledged).toBe(true);

      store.athena_llm_consent_acknowledged = false;
      expect(await hasLLMConsent()).toBe(true);
    });

    it("returns default model when empty", async () => {
      const settings = await loadSettings();
      expect(settings).toEqual({
        baseUrl: "",
        apiKey: "",
        model: "gpt-4o-mini",
        githubPat: "",
      });
    });

    it("saves credentials to local storage", async () => {
      await saveSettings({
        baseUrl: "https://api.openai.com/v1",
        apiKey: "sk-test12345",
        model: "gpt-4o",
        githubPat: "ghp_local-token",
      });

      const settings = await loadSettings();
      expect(settings).toEqual({
        baseUrl: "https://api.openai.com/v1",
        apiKey: "sk-test12345",
        model: "gpt-4o",
        githubPat: "ghp_local-token",
      });
      expect(localStore.athena_llm_api_key).toBe("sk-test12345");
      expect(localStore.athena_github_pat).toBe("ghp_local-token");
      expect(store.athena_llm_api_key).toBeUndefined();
      expect(store.athena_github_pat).toBeUndefined();
    });

    it("migrates legacy session settings only when local settings are empty", async () => {
      store = {
        athena_llm_base_url: "https://legacy.example/v1",
        athena_llm_api_key: "sk-legacy-secret",
        athena_llm_model: "legacy-model",
        athena_github_pat: "ghp_legacy-secret",
      };

      const settings = await loadSettings();
      expect(settings).toEqual({
        baseUrl: "https://legacy.example/v1",
        apiKey: "sk-legacy-secret",
        model: "legacy-model",
        githubPat: "ghp_legacy-secret",
      });
      expect(localStore.athena_llm_api_key).toBe("sk-legacy-secret");
      expect(localStore.athena_github_pat).toBe("ghp_legacy-secret");
    });

    it("does not migrate over an existing local setting", async () => {
      store.athena_llm_api_key = "sk-old-session-secret";
      localStore.athena_llm_model = "local-model";

      const settings = await loadSettings();
      expect(settings.apiKey).toBe("");
      expect(settings.model).toBe("local-model");
      expect(localStore.athena_llm_api_key).toBeUndefined();
    });
  });

  // ── GitHub PAT & Security Constraint ────────────────────────────────────────

  describe("GitHub PAT & Security Constraint", () => {
    it("starts with empty PAT", async () => {
      expect((await loadSettings()).githubPat).toBe("");
    });

    it("saves, loads, and clears GitHub PAT", async () => {
      await saveSettings({ githubPat: "ghp_secretToken1234567890abcdef" });
      expect((await loadSettings()).githubPat).toBe("ghp_secretToken1234567890abcdef");

      await saveSettings({ githubPat: undefined });
      expect((await loadSettings()).githubPat).toBe("");
      expect(localStore.athena_github_pat).toBeUndefined();
    });

    it("NEVER sends PAT to any host other than api.github.com", async () => {
      await saveSettings({ githubPat: "ghp_superSecretToken999" });

      // 1. Valid api.github.com target
      const validHeaders = await getGitHubAuthHeaders(
        "https://api.github.com/repos/octocat/hello-world/pulls/42"
      );
      expect(validHeaders).toEqual({
        Authorization: "token ghp_superSecretToken999",
      });

      // 2. OpenAI API host
      const openaiHeaders = await getGitHubAuthHeaders(
        "https://api.openai.com/v1/chat/completions"
      );
      expect(openaiHeaders).toEqual({});

      // 3. Regular github.com (non-API)
      const githubWebHeaders = await getGitHubAuthHeaders(
        "https://github.com/octocat/hello-world"
      );
      expect(githubWebHeaders).toEqual({});

      // 4. Arbitrary third-party endpoint
      const thirdPartyHeaders = await getGitHubAuthHeaders(
        "https://example.com/api/v1"
      );
      expect(thirdPartyHeaders).toEqual({});

      // 5. Malformed URL
      const malformedHeaders = await getGitHubAuthHeaders("invalid-url");
      expect(malformedHeaders).toEqual({});
    });
  });

  // ── Rule Toggles ────────────────────────────────────────────────────────────

  describe("Rule Toggles", () => {
    it("defaults to enabled for all rules", async () => {
      await initToggleCache();
      expect(isRuleEnabled("passive_delete-repository")).toBe(true);
      expect(isRuleEnabled("secret_aws-access-key")).toBe(true);
    });

    it("saves toggles and updates in-memory cache", async () => {
      await saveToggles({
        "passive_delete-repository": false,
        "secret_aws-access-key": false,
      });

      await initToggleCache();
      expect(isRuleEnabled("passive_delete-repository")).toBe(false);
      expect(isRuleEnabled("secret_aws-access-key")).toBe(false);
      expect(isRuleEnabled("passive_archive-repository")).toBe(true);
    });
  });

  // ── Dismissed Warnings ──────────────────────────────────────────────────────

  describe("Dismissed Warnings", () => {
    it("starts with empty dismissed warnings", async () => {
      const warnings = await loadDismissedWarnings();
      expect(warnings).toEqual([]);
    });

    it("dismisses warnings and updates sync and async checks", async () => {
      await initDismissedCache();
      const ruleId = "passive_delete-branch";
      const targetUrl = "https://github.com/owner/repo/branches";

      expect(await isWarningDismissed(ruleId, targetUrl)).toBe(false);
      expect(isWarningDismissedSync(ruleId, targetUrl)).toBe(false);

      await dismissWarning(ruleId, targetUrl);

      expect(await isWarningDismissed(ruleId, targetUrl)).toBe(true);
      expect(isWarningDismissedSync(ruleId, targetUrl)).toBe(true);

      // Check different targetUrl
      expect(
        await isWarningDismissed(ruleId, "https://github.com/other/repo")
      ).toBe(false);
    });

    it("clears dismissed warnings", async () => {
      await initDismissedCache();
      await dismissWarning("secret_openai-key");
      expect(await isWarningDismissed("secret_openai-key")).toBe(true);

      await clearDismissedWarnings();
      expect(await loadDismissedWarnings()).toEqual([]);
      expect(isWarningDismissedSync("secret_openai-key")).toBe(false);
    });
  });

  // ── Rules Config & Per-Repo Policies ────────────────────────────────────────

  describe("Rules Config & Per-Repo Policies", () => {
    it("starts with default rules config", async () => {
      const cfg = await loadRulesConfig();
      expect(cfg.defaultPolicy.blockMergeToMain).toBe(false);
      expect(cfg.defaultPolicy.requirePassingChecks).toBe(false);
      expect(cfg.defaultPolicy.secretToggles["aws-access-key"]).toBe(true);
      expect(cfg.repos).toEqual({});
    });

    it("normalizes repo keys to lowercase trimmed strings", () => {
      expect(normalizeRepoKey("  Owner/Repo  ")).toBe("owner/repo");
      expect(normalizeRepoKey("")).toBe("");
      expect(normalizeRepoKey(null)).toBe("");
    });

    it("saves and loads full rules config", async () => {
      await saveRulesConfig({
        defaultPolicy: {
          ...DEFAULT_REPO_POLICY,
          blockMergeToMain: true,
        },
        repos: {
          "org/payments": {
            blockMergeToMain: true,
            requirePassingChecks: true,
            secretToggles: {
              ...DEFAULT_REPO_POLICY.secretToggles,
              "stripe-key": false,
            },
          },
        },
      });

      const cfg = await loadRulesConfig();
      expect(cfg.defaultPolicy.blockMergeToMain).toBe(true);
      expect(cfg.repos["org/payments"].requirePassingChecks).toBe(true);
      expect(cfg.repos["org/payments"].secretToggles["stripe-key"]).toBe(false);
    });

    it("saves per-repo policy overrides and returns custom or default policies synchronously", async () => {
      await initRulesConfigCache();

      // Initially default applies
      const initialPolicy = getRepoPolicySync("facebook/react");
      expect(initialPolicy.blockMergeToMain).toBe(false);
      expect(initialPolicy.requirePassingChecks).toBe(false);
      expect(isSecretPatternEnabledForRepo("openai-key", "facebook/react")).toBe(true);

      // Save custom policy for facebook/react
      await saveRepoPolicy("facebook/react", {
        blockMergeToMain: true,
        requirePassingChecks: true,
        secretToggles: {
          ...DEFAULT_REPO_POLICY.secretToggles,
          "openai-key": false,
        },
      });

      await initRulesConfigCache();

      const reactPolicy = getRepoPolicySync("Facebook/React");
      expect(reactPolicy.blockMergeToMain).toBe(true);
      expect(reactPolicy.requirePassingChecks).toBe(true);
      expect(isSecretPatternEnabledForRepo("openai-key", "facebook/react")).toBe(false);
      expect(isSecretPatternEnabledForRepo("aws-access-key", "facebook/react")).toBe(true);

      // Other repos still inherit default
      const otherPolicy = getRepoPolicySync("other/repo");
      expect(otherPolicy.blockMergeToMain).toBe(false);
      expect(otherPolicy.requirePassingChecks).toBe(false);
      expect(isSecretPatternEnabledForRepo("openai-key", "other/repo")).toBe(true);
    });

    it("persists policy in local storage and keeps repository overrides separate from the global fallback", async () => {
      await saveRepoPolicy("default", { blockMergeToMain: true, secretToggles: { ...DEFAULT_REPO_POLICY.secretToggles, "stripe-key": false } });
      await saveRepoPolicy("Org/Payments", { requirePassingChecks: true });

      expect(localStore.athena_rules_config).toBeDefined();
      await initRulesConfigCache(); // Simulate the cache being rebuilt after an extension reload.
      expect(getRepoPolicySync("org/payments").blockMergeToMain).toBe(true);
      expect(getRepoPolicySync("org/payments").requirePassingChecks).toBe(true);
      expect(getRepoPolicySync("org/payments").secretToggles["stripe-key"]).toBe(false);
      expect(getRepoPolicySync("another/repo").blockMergeToMain).toBe(true);
      expect(getRepoPolicySync("another/repo").requirePassingChecks).toBe(false);
      expect(getRepoPolicySync("another/repo").secretToggles["stripe-key"]).toBe(false);
    });

    it("stores only policy fields and never persists arbitrary credential properties", async () => {
      await saveRulesConfig({
        defaultPolicy: { ...DEFAULT_REPO_POLICY, apiKey: "must-not-persist" } as any,
        repos: { "org/repo": { ...DEFAULT_REPO_POLICY, githubPat: "must-not-persist" } as any },
      });
      const serialized = JSON.stringify(localStore.athena_rules_config);
      expect(serialized).not.toContain("must-not-persist");
      expect(serialized).not.toContain("apiKey");
      expect(serialized).not.toContain("githubPat");
    });
  });
});
