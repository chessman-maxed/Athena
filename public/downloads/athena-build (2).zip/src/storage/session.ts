/**
 * Athena – canonical extension storage module.
 *
 * Session data stays in chrome.storage.session. Credentials are managed only
 * through loadSettings/saveSettings in chrome.storage.local.
 *
 * Session storage schema:
 *
 *   athena_session_log          AthenaLogEntry[]   – confirmed dangerous actions
 *   athena_rule_toggles         RuleToggles        – per-rule enabled/disabled flags
 *   athena_dismissed_warnings   DismissedWarning[] – warnings dismissed this session
 *
 * Rule policies are stored separately in chrome.storage.local so repository
 * settings survive extension reloads. The policy schema contains no credentials.
 *
 * Local settings contain the LLM endpoint/key/model and optional GitHub PAT.
 */

// ── Types ─────────────────────────────────────────────────────────────────────

export interface AthenaLogEntry {
  ruleId: string;
  actionType: string;
  url: string;
  confirmedAt: number; // Unix ms timestamp
}

export type ActivityEventType =
  | "warning-shown"
  | "cancelled"
  | "proceeded"
  | "secret-blocked"
  | "merge-warned"
  | "fix-action";

export interface AthenaActivityEntry {
  type: ActivityEventType;
  ruleId: string;
  label: string;
  repo: string;
  timestamp: number;
}

export interface LLMSettings {
  baseUrl: string;
  apiKey: string;
  model: string;
}

export interface AthenaSettings extends LLMSettings {
  githubPat: string;
}

type SettingsUpdate = {
  [K in keyof AthenaSettings]?: AthenaSettings[K] | undefined;
};

export interface DismissedWarning {
  ruleId: string;
  targetUrl?: string;
  dismissedAt: number;
}

// ── Rule IDs & Secret Pattern IDs ─────────────────────────────────────────────

export type SecretPatternId =
  | "aws-access-key"
  | "github-pat"
  | "github-fine-grained-pat"
  | "pem-private-key"
  | "slack-token"
  | "google-api-key"
  | "openai-key"
  | "stripe-key"
  | "high-entropy";

export const ALL_SECRET_PATTERNS: Array<{ id: SecretPatternId; label: string; description: string }> = [
  { id: "aws-access-key",          label: "AWS Access Key ID",         description: "AKIA... 20-character credentials" },
  { id: "github-pat",              label: "GitHub PAT (Classic/OAuth)",description: "ghp_, gho_, ghu_, ghs_ tokens" },
  { id: "github-fine-grained-pat", label: "GitHub Fine-Grained PAT",    description: "github_pat_ formatted tokens" },
  { id: "pem-private-key",         label: "PEM Private Key",            description: "-----BEGIN PRIVATE KEY----- blocks" },
  { id: "slack-token",             label: "Slack API Token",            description: "xoxb-, xoxp-, xoxa-, xoxr- tokens" },
  { id: "google-api-key",          label: "Google API Key",             description: "AIza... 39-character keys" },
  { id: "openai-key",              label: "OpenAI API Key",             description: "sk-... and sk-proj-... API keys" },
  { id: "stripe-key",              label: "Stripe Secret Key",          description: "sk_live_ and sk_test_ keys" },
  { id: "high-entropy",            label: "High-Entropy Strings",       description: "Generic high-entropy tokens (Shannon ≥ 4.5)" },
];

export interface RepoPolicy {
  /** Block merging directly to main/master from the UI warning layer */
  blockMergeToMain: boolean;
  /** Require passing CI checks before merge */
  requirePassingChecks: boolean;
  /** Per-pattern secret scanner toggles */
  secretToggles: Record<SecretPatternId, boolean>;
}

export interface RulesConfig {
  /** Fallback policy for repositories without custom overrides */
  defaultPolicy: RepoPolicy;
  /** Per-repo policies keyed by "owner/repo" in lowercase */
  repos: Record<string, RepoPolicy>;
}

export const DEFAULT_SECRET_TOGGLES: Record<SecretPatternId, boolean> = {
  "aws-access-key": true,
  "github-pat": true,
  "github-fine-grained-pat": true,
  "pem-private-key": true,
  "slack-token": true,
  "google-api-key": true,
  "openai-key": true,
  "stripe-key": true,
  "high-entropy": true,
};

export const DEFAULT_REPO_POLICY: RepoPolicy = {
  blockMergeToMain: false,
  requirePassingChecks: false,
  secretToggles: { ...DEFAULT_SECRET_TOGGLES },
};

export const DEFAULT_RULES_CONFIG: RulesConfig = {
  defaultPolicy: { ...DEFAULT_REPO_POLICY },
  repos: {},
};

/**
 * Rule IDs that can be toggled.
 * passive_* = dangerous-action interceptors
 * secret_*  = secret-scanner detectors
 */
export type RuleId =
  // Passive rules (src/content/rules.ts & conflict radar)
  | "passive_delete-repository"
  | "passive_archive-repository"
  | "passive_transfer-ownership"
  | "passive_delete-branch"
  | "passive_close-pull-request"
  | "passive_conflict-radar"
  | "passive_workflow-radar"
  | "passive_pre-merge-checklist"
  // Secret-scanner detectors (src/rules/secrets.ts)
  | "secret_aws-access-key"
  | "secret_github-pat"
  | "secret_github-fine-grained-pat"
  | "secret_pem-private-key"
  | "slack-token"
  | "secret_slack-token"
  | "secret_google-api-key"
  | "secret_openai-key"
  | "secret_stripe-key"
  | "secret_high-entropy";

/** true = enabled (default), false = user-disabled for this session */
export type RuleToggles = Partial<Record<RuleId, boolean>>;

// ── Storage keys ──────────────────────────────────────────────────────────────

const K = {
  LOG:          "athena_session_log",
  ACTIVITY_LOG: "athena_activity_log",
  ACTIVITY_DEDUPE: "athena_activity_dedupe",
  LLM_URL:      "athena_llm_base_url",
  LLM_KEY:      "athena_llm_api_key",
  LLM_MODEL:    "athena_llm_model",
  LLM_CONSENT:  "athena_llm_consent_acknowledged",
  GITHUB_PAT:   "athena_github_pat",
  TOGGLES:      "athena_rule_toggles",
  DISMISSED:    "athena_dismissed_warnings",
  RULES_CONFIG: "athena_rules_config",
} as const;

// ── Generic promise-wrapper ───────────────────────────────────────────────────

// ── Generic promise-wrapper ───────────────────────────────────────────────────

function get<T>(key: string): Promise<T | undefined> {
  return new Promise((resolve) => {
    if (typeof chrome !== "undefined" && chrome.storage?.session) {
      chrome.storage.session.get(key, (result) => resolve(result?.[key] as T));
    } else {
      resolve(undefined);
    }
  });
}

function set(data: Record<string, unknown>): Promise<void> {
  return new Promise((resolve) => {
    if (typeof chrome !== "undefined" && chrome.storage?.session) {
      chrome.storage.session.set(data, resolve);
    } else {
      resolve();
    }
  });
}

function addStorageChangeListener(callback: (changes: { [key: string]: chrome.storage.StorageChange }) => void): void {
  if (typeof chrome !== "undefined" && chrome.storage?.session?.onChanged) {
    chrome.storage.session.onChanged.addListener(callback);
  }
}

function addLocalStorageChangeListener(callback: (changes: { [key: string]: chrome.storage.StorageChange }) => void): void {
  if (typeof chrome !== "undefined" && chrome.storage?.onChanged) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === "local") callback(changes);
    });
  }
}

const LOCAL_SETTING_KEYS = [K.LLM_URL, K.LLM_KEY, K.LLM_MODEL] as const;
const SETTINGS_MIGRATION_KEY = "athena_local_settings_migrated_v1";
let githubPatMigration: Promise<void> | null = null;

function getLocalSettings(keys: readonly string[]): Promise<Record<string, unknown>> {
  return new Promise((resolve) => {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      chrome.storage.local.get([...keys], (result) => resolve(result ?? {}));
    } else {
      resolve({});
    }
  });
}

function setLocalSettings(data: Record<string, unknown>): Promise<void> {
  return new Promise((resolve) => {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      chrome.storage.local.set(data, resolve);
    } else {
      resolve();
    }
  });
}

function removeLocalSettings(keys: readonly string[]): Promise<void> {
  return new Promise((resolve) => {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      chrome.storage.local.remove([...keys], resolve);
    } else {
      resolve();
    }
  });
}

async function migrateLegacySettings(): Promise<void> {
  const local = await getLocalSettings([...LOCAL_SETTING_KEYS, SETTINGS_MIGRATION_KEY]);
  if (local[SETTINGS_MIGRATION_KEY] === true) return;

  const hasLocalSettings = LOCAL_SETTING_KEYS.some((key) => Object.prototype.hasOwnProperty.call(local, key));
  if (hasLocalSettings) {
    await setLocalSettings({ [SETTINGS_MIGRATION_KEY]: true });
    return;
  }

  const legacy = await new Promise<Record<string, unknown>>((resolve) => {
    if (typeof chrome !== "undefined" && chrome.storage?.session) {
      chrome.storage.session.get([...LOCAL_SETTING_KEYS], (result) => resolve(result ?? {}));
    } else {
      resolve({});
    }
  });

  const latestLocal = await getLocalSettings(LOCAL_SETTING_KEYS);
  if (LOCAL_SETTING_KEYS.some((key) => Object.prototype.hasOwnProperty.call(latestLocal, key))) return;

  const migrated: Record<string, unknown> = { [SETTINGS_MIGRATION_KEY]: true };
  for (const key of LOCAL_SETTING_KEYS) {
    if (Object.prototype.hasOwnProperty.call(legacy, key)) migrated[key] = legacy[key];
  }
  await setLocalSettings(migrated);
}

/** Move any PAT saved by older versions into session storage and erase the persistent copy. */
async function migrateGitHubPatToSession(): Promise<void> {
  if (githubPatMigration) return githubPatMigration;
  githubPatMigration = (async () => {
    const [local, sessionPat] = await Promise.all([
      getLocalSettings([K.GITHUB_PAT]),
      get<string>(K.GITHUB_PAT),
    ]);
    const legacyPat = typeof local[K.GITHUB_PAT] === "string" ? local[K.GITHUB_PAT] as string : "";
    if (!sessionPat && legacyPat) await set({ [K.GITHUB_PAT]: legacyPat });
    if (legacyPat) await removeLocalSettings([K.GITHUB_PAT]);
  })();
  return githubPatMigration;
}

// ── Session log ───────────────────────────────────────────────────────────────

export async function loadLog(): Promise<AthenaLogEntry[]> {
  return (await get<AthenaLogEntry[]>(K.LOG)) ?? [];
}

export async function logConfirmedAction(
  entry: Omit<AthenaLogEntry, "confirmedAt">
): Promise<void> {
  const existing = await loadLog();
  await set({ [K.LOG]: [...existing, { ...entry, confirmedAt: Date.now() }] });
}

export async function wasAlreadyConfirmed(
  ruleId: string,
  url: string
): Promise<boolean> {
  const log = await loadLog();
  return log.some((e) => e.ruleId === ruleId && e.url === url);
}

export async function loadActivityLog(): Promise<AthenaActivityEntry[]> {
  return (await get<AthenaActivityEntry[]>(K.ACTIVITY_LOG)) ?? [];
}

let activityWriteQueue: Promise<void> = Promise.resolve();

export function logActivity(
  entry: Omit<AthenaActivityEntry, "timestamp">,
  dedupeUrl?: string
): Promise<void> {
  const write = async (): Promise<void> => {
    const [existing, dedupeKeys] = await Promise.all([
      loadActivityLog(),
      get<string[]>(K.ACTIVITY_DEDUPE),
    ]);
    const key = dedupeUrl ? `${entry.ruleId}\u0000${dedupeUrl}` : undefined;
    if (key && (dedupeKeys ?? []).includes(key)) return;

    await set({
      [K.ACTIVITY_LOG]: [...existing, { ...entry, timestamp: Date.now() }],
      ...(key ? { [K.ACTIVITY_DEDUPE]: [...(dedupeKeys ?? []), key] } : {}),
    });
  };

  const nextWrite = activityWriteQueue.then(write, write);
  activityWriteQueue = nextWrite.catch(() => undefined);
  return nextWrite;
}

// ── Dismissed warnings ────────────────────────────────────────────────────────

let _dismissedCache: DismissedWarning[] = [];

export async function loadDismissedWarnings(): Promise<DismissedWarning[]> {
  return (await get<DismissedWarning[]>(K.DISMISSED)) ?? [];
}

export async function dismissWarning(
  ruleId: string,
  targetUrl?: string
): Promise<void> {
  const existing = await loadDismissedWarnings();
  const updated = [
    ...existing,
    { ruleId, targetUrl, dismissedAt: Date.now() },
  ];
  _dismissedCache = updated;
  await set({ [K.DISMISSED]: updated });
}

export async function isWarningDismissed(
  ruleId: string,
  targetUrl?: string
): Promise<boolean> {
  const warnings = await loadDismissedWarnings();
  return warnings.some(
    (w) => w.ruleId === ruleId && (!targetUrl || w.targetUrl === targetUrl)
  );
}

export function isWarningDismissedSync(
  ruleId: string,
  targetUrl?: string
): boolean {
  return _dismissedCache.some(
    (w) => w.ruleId === ruleId && (!targetUrl || w.targetUrl === targetUrl)
  );
}

export async function clearDismissedWarnings(): Promise<void> {
  _dismissedCache = [];
  await set({ [K.DISMISSED]: [] });
}

export async function initDismissedCache(): Promise<void> {
  _dismissedCache = await loadDismissedWarnings();
  addStorageChangeListener((changes) => {
    if (K.DISMISSED in changes) {
      _dismissedCache = (changes[K.DISMISSED].newValue as DismissedWarning[]) ?? [];
    }
  });
}

// ── Persistent settings ───────────────────────────────────────────────────────

export async function loadSettings(): Promise<AthenaSettings> {
  await migrateLegacySettings();
  await migrateGitHubPatToSession();
  const stored = await getLocalSettings(LOCAL_SETTING_KEYS);
  const githubPat = await get<string>(K.GITHUB_PAT);
  return {
    baseUrl: typeof stored[K.LLM_URL] === "string" ? normalizeBaseUrl(stored[K.LLM_URL] as string) : "",
    apiKey: typeof stored[K.LLM_KEY] === "string" ? stored[K.LLM_KEY] as string : "",
    model: typeof stored[K.LLM_MODEL] === "string" && stored[K.LLM_MODEL]
      ? stored[K.LLM_MODEL] as string
      : "gpt-4o-mini",
    githubPat: typeof githubPat === "string" ? githubPat : "",
  };
}

export async function saveSettings(settings: SettingsUpdate): Promise<void> {
  await migrateLegacySettings();
  await migrateGitHubPatToSession();
  const writes: Record<string, unknown> = {};
  const removes: string[] = [];
  const assign = (field: keyof AthenaSettings, key: string, value: string | undefined) => {
    if (value === undefined) {
      removes.push(key);
      return;
    }
    const trimmed = value.trim();
    writes[key] = field === "baseUrl"
      ? normalizeBaseUrl(trimmed)
      : field === "model"
        ? trimmed || "gpt-4o-mini"
        : trimmed;
  };

  if (Object.prototype.hasOwnProperty.call(settings, "baseUrl")) assign("baseUrl", K.LLM_URL, settings.baseUrl);
  if (Object.prototype.hasOwnProperty.call(settings, "apiKey")) assign("apiKey", K.LLM_KEY, settings.apiKey);
  if (Object.prototype.hasOwnProperty.call(settings, "model")) assign("model", K.LLM_MODEL, settings.model);
  if (Object.prototype.hasOwnProperty.call(settings, "githubPat")) {
    if (settings.githubPat === undefined) await new Promise<void>((resolve) => {
      if (typeof chrome !== "undefined" && chrome.storage?.session) chrome.storage.session.remove(K.GITHUB_PAT, resolve);
      else resolve();
    });
    else await set({ [K.GITHUB_PAT]: settings.githubPat.trim() });
  }

  if (Object.keys(writes).length) await setLocalSettings(writes);
  if (removes.length) await removeLocalSettings(removes);
}

export function maskCredential(value: string): string {
  if (!value) return "";
  if (value.length <= 10) return `••••${value.slice(-2)}`;
  return `${value.slice(0, 6)}••••${value.slice(-4)}`;
}

export function normalizeBaseUrl(url: string): string {
  if (!url) return "";
  return url.trim().replace(/[\s/]+$/, "");
}

export function formatLLMErrorResponse(status: number | string): string {
  return `LLM endpoint returned an error (HTTP ${status}). Check the configured endpoint and credentials.`;
}

export async function hasLLMConsent(): Promise<boolean> {
  const localConsent = await getLocalSettings([K.LLM_CONSENT]);
  if (typeof localConsent[K.LLM_CONSENT] === "boolean") {
    return localConsent[K.LLM_CONSENT] as boolean;
  }

  // Migrate a value saved by older versions, which kept this preference in
  // session storage. The local value becomes the only source of truth.
  const legacyConsent = await get<boolean>(K.LLM_CONSENT);
  if (typeof legacyConsent === "boolean") {
    await setLocalSettings({ [K.LLM_CONSENT]: legacyConsent });
    return legacyConsent;
  }
  return false;
}

export async function setLLMConsent(consented: boolean): Promise<void> {
  await setLocalSettings({ [K.LLM_CONSENT]: consented });
}

/**
 * Returns Authorization header with GitHub PAT IF AND ONLY IF targetUrl host is api.github.com.
 * NEVER sends the PAT anywhere except api.github.com.
 */
export async function getGitHubAuthHeaders(
  targetUrl: string
): Promise<Record<string, string>> {
  try {
    const parsed = new URL(targetUrl);
    if (parsed.hostname !== "api.github.com") {
      return {};
    }
    const pat = (await loadSettings()).githubPat;
    if (!pat) return {};
    return { Authorization: `token ${pat}` };
  } catch {
    return {};
  }
}

// ── Rule toggles ──────────────────────────────────────────────────────────────

export async function loadToggles(): Promise<RuleToggles> {
  return (await get<RuleToggles>(K.TOGGLES)) ?? {};
}

export async function saveToggles(toggles: RuleToggles): Promise<void> {
  await set({ [K.TOGGLES]: toggles });
}

/**
 * Returns true when the rule is enabled (default: enabled).
 * Reads synchronously from an in-memory cache populated by initToggleCache().
 */
let _toggleCache: RuleToggles = {};

export function isRuleEnabled(id: RuleId): boolean {
  return _toggleCache[id] !== false; // undefined → true (default on)
}

/** Call once at content-script init to warm the in-memory cache. */
export async function initToggleCache(): Promise<void> {
  _toggleCache = await loadToggles();

  // Keep the cache live via storage.onChanged
  addStorageChangeListener((changes) => {
    if (K.TOGGLES in changes) {
      _toggleCache = (changes[K.TOGGLES].newValue as RuleToggles) ?? {};
    }
  });
}

// ── Per-Repo Rules Config ───────────────────────────────────────────────────

let _rulesConfigCache: RulesConfig = {
  defaultPolicy: { ...DEFAULT_REPO_POLICY, secretToggles: { ...DEFAULT_SECRET_TOGGLES } },
  repos: {},
};

export function normalizeRepoKey(repoKey?: string | null): string {
  if (!repoKey) return "";
  return repoKey.trim().toLowerCase();
}

function normalizePolicy(value?: Partial<RepoPolicy> | null): RepoPolicy {
  const source = value && typeof value === "object" ? value : {};
  const toggles = source.secretToggles && typeof source.secretToggles === "object" ? source.secretToggles : {};
  const secretToggles = { ...DEFAULT_SECRET_TOGGLES };
  for (const pattern of ALL_SECRET_PATTERNS) {
    const enabled = (toggles as Record<string, unknown>)[pattern.id];
    if (typeof enabled === "boolean") secretToggles[pattern.id] = enabled;
  }
  return {
    blockMergeToMain: typeof source.blockMergeToMain === "boolean" ? source.blockMergeToMain : DEFAULT_REPO_POLICY.blockMergeToMain,
    requirePassingChecks: typeof source.requirePassingChecks === "boolean" ? source.requirePassingChecks : DEFAULT_REPO_POLICY.requirePassingChecks,
    secretToggles,
  };
}

function normalizeRulesConfig(value?: Partial<RulesConfig> | null): RulesConfig {
  const source = value && typeof value === "object" ? value : {};
  const defaultPolicy = normalizePolicy(source.defaultPolicy);
  const repos: Record<string, RepoPolicy> = {};
  if (source.repos && typeof source.repos === "object") {
    for (const [key, policy] of Object.entries(source.repos)) {
      const normalizedKey = normalizeRepoKey(key);
      if (/^[\w.-]+\/[\w.-]+$/.test(normalizedKey)) {
        const repo: Partial<RepoPolicy> = policy && typeof policy === "object" ? policy as Partial<RepoPolicy> : {};
        repos[normalizedKey] = normalizePolicy({
          ...defaultPolicy,
          ...repo,
          secretToggles: { ...defaultPolicy.secretToggles, ...(repo.secretToggles ?? {}) },
        });
      }
    }
  }
  return { defaultPolicy, repos };
}

export async function loadRulesConfig(): Promise<RulesConfig> {
  const localStored = await getLocalSettings([K.RULES_CONFIG]);
  const stored = (localStored[K.RULES_CONFIG] as RulesConfig | undefined) ?? await get<RulesConfig>(K.RULES_CONFIG);
  const normalized = normalizeRulesConfig(stored);
  if (!localStored[K.RULES_CONFIG] && stored) await setLocalSettings({ [K.RULES_CONFIG]: normalized });
  return normalized;
}

export async function saveRulesConfig(config: RulesConfig): Promise<void> {
  const normalized = normalizeRulesConfig(config);
  _rulesConfigCache = normalized;
  await setLocalSettings({ [K.RULES_CONFIG]: normalized });
}

export function getRepoPolicySync(repoKey?: string | null): RepoPolicy {
  const normKey = normalizeRepoKey(repoKey);
  const repoPolicy = normKey ? _rulesConfigCache.repos[normKey] : undefined;

  const base = repoPolicy ?? _rulesConfigCache.defaultPolicy ?? DEFAULT_REPO_POLICY;

  return {
    ...normalizePolicy(base),
  };
}

export async function saveRepoPolicy(
  repoKey: string,
  policy: Partial<RepoPolicy>
): Promise<void> {
  const normKey = normalizeRepoKey(repoKey);
  const current = await loadRulesConfig();

  if (!normKey || normKey === "default") {
    current.defaultPolicy = {
      ...normalizePolicy({ ...current.defaultPolicy, ...policy, secretToggles: { ...current.defaultPolicy.secretToggles, ...(policy.secretToggles ?? {}) } }),
    };
  } else {
    const existing = current.repos[normKey] ?? {
      ...current.defaultPolicy,
      secretToggles: { ...current.defaultPolicy.secretToggles },
    };

    current.repos[normKey] = {
      ...normalizePolicy({ ...existing, ...policy, secretToggles: { ...existing.secretToggles, ...(policy.secretToggles ?? {}) } }),
    };
  }

  await saveRulesConfig(current);
}

export function isSecretPatternEnabledForRepo(
  patternId: SecretPatternId,
  repoKey?: string | null
): boolean {
  const policy = getRepoPolicySync(repoKey);
  return policy.secretToggles[patternId] !== false;
}

export async function initRulesConfigCache(): Promise<void> {
  _rulesConfigCache = await loadRulesConfig();

  addLocalStorageChangeListener((changes) => {
    if (K.RULES_CONFIG in changes) {
      _rulesConfigCache = (changes[K.RULES_CONFIG].newValue as RulesConfig) ?? { ...DEFAULT_RULES_CONFIG };
    }
  });
}

// ── Workflow Radar cache per PR ───────────────────────────────────────────────

export interface WorkflowRadarCache {
  prKey: string;
  timestamp: number;
  changedFiles: string[];
  runningWorkflows: Array<{ name: string; filename: string; isDeploy: boolean }>;
  deployFiles: string[];
  errorMessage?: string;
  isRateLimited?: boolean;
}

export async function loadWorkflowCache(
  prKey: string
): Promise<WorkflowRadarCache | undefined> {
  return get<WorkflowRadarCache>(`athena_wf_${prKey}`);
}

export async function saveWorkflowCache(
  cache: WorkflowRadarCache
): Promise<void> {
  await set({ [`athena_wf_${cache.prKey}`]: cache });
}

// Re-export storage keys so App.tsx can reference them
export { K as STORAGE_KEYS };

