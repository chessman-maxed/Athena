import { loadSettings, loadToggles, loadRulesConfig, logActivity, type SecretPatternId } from "../storage/session";
import { scanText } from "../rules/secrets";
import { createFixPullRequest } from "./fixer";

const API = "https://api.github.com";
export interface SecretPrInput { owner: string; repo: string; pullNumber: number }
export interface SecretPrFinding { path: string; line: number; type: string; maskedPreview: "•••" }
interface PullData { head: { sha: string; ref: string; repo: { full_name: string } | null }; base: { ref: string } }
interface PullFile { filename: string; patch?: string; status?: string }
interface SecretEdit { file: string; content: string; patch: string; isNewFile: boolean; manual: boolean; secrets: string[] }
interface Result { diff?: string; summary?: string; reviewManually?: boolean; confirmPaths?: string[]; blocked?: string; id?: string; files?: string[] }

const PATTERN_BY_TYPE: Record<string, SecretPatternId> = {
  "AWS Access Key ID": "aws-access-key", "GitHub Personal Access Token": "github-pat",
  "GitHub Fine-Grained PAT": "github-fine-grained-pat", "PEM Private Key": "pem-private-key",
  "Slack Token": "slack-token", "Google API Key": "google-api-key", "OpenAI API Key": "openai-key",
  "Stripe Secret Key": "stripe-key", "Stripe Publishable Key": "stripe-key", "High-Entropy String": "high-entropy",
};
const RULE_BY_TYPE: Record<string, string> = {
  "AWS Access Key ID": "secret_aws-access-key", "GitHub Personal Access Token": "secret_github-pat",
  "GitHub Fine-Grained PAT": "secret_github-fine-grained-pat", "PEM Private Key": "secret_pem-private-key",
  "Slack Token": "secret_slack-token", "Google API Key": "secret_google-api-key", "OpenAI API Key": "secret_openai-key",
  "Stripe Secret Key": "secret_stripe-key", "Stripe Publishable Key": "secret_stripe-key", "High-Entropy String": "secret_high-entropy",
};
const NAME_BY_TYPE: Record<string, string> = {
  "AWS Access Key ID": "AWS_ACCESS_KEY_ID", "GitHub Personal Access Token": "GITHUB_TOKEN",
  "GitHub Fine-Grained PAT": "GITHUB_TOKEN", "Slack Token": "SLACK_TOKEN", "Google API Key": "GOOGLE_API_KEY",
  "OpenAI API Key": "OPENAI_API_KEY", "Stripe Secret Key": "STRIPE_SECRET_KEY", "Stripe Publishable Key": "STRIPE_SECRET_KEY",
  "PEM Private Key": "PRIVATE_KEY",
};
const REVOKE_URL_BY_TYPE: Record<string, string> = {
  "GitHub Personal Access Token": "https://github.com/settings/tokens", "GitHub Fine-Grained PAT": "https://github.com/settings/personal-access-tokens",
  "AWS Access Key ID": "https://console.aws.amazon.com/iam/home#/security_credentials", "Slack Token": "https://api.slack.com/apps",
  "Google API Key": "https://console.cloud.google.com/apis/credentials", "OpenAI API Key": "https://platform.openai.com/api-keys",
  "Stripe Secret Key": "https://dashboard.stripe.com/apikeys", "Stripe Publishable Key": "https://dashboard.stripe.com/apikeys",
};
interface GitHubError extends Error { status?: number }
function repoPath(input: SecretPrInput): string { return `/repos/${encodeURIComponent(input.owner)}/${encodeURIComponent(input.repo)}`; }
async function token(): Promise<string> {
  const value = (await loadSettings()).githubPat.trim();
  if (!value) throw new Error("Add a GitHub token with Actions read and Contents write access in Athena Settings.");
  return value;
}
async function request<T>(auth: string, path: string): Promise<T> {
  let response: Response;
  try { response = await fetch(`${API}${path}`, { headers: { Accept: "application/vnd.github+json", Authorization: `Bearer ${auth}`, "X-GitHub-Api-Version": "2022-11-28" } }); }
  catch { throw new Error("Network failure while checking PR files."); }
  if (!response.ok) {
    const error = new Error(response.status === 403 ? "GitHub denied access or the rate limit was reached. Check token permissions and try again later." : `GitHub request failed (HTTP ${response.status}).`) as GitHubError;
    error.status = response.status;
    throw error;
  }
  return await response.json() as T;
}
async function getPull(auth: string, input: SecretPrInput): Promise<PullData> { return request(auth, `${repoPath(input)}/pulls/${input.pullNumber}`); }
async function enabledSecretTypes(owner: string, repo: string): Promise<Set<string>> {
  const [toggles, config] = await Promise.all([loadToggles(), loadRulesConfig()]);
  const policy = config.repos[`${owner}/${repo}`.toLowerCase()] ?? config.defaultPolicy;
  return new Set(Object.entries(PATTERN_BY_TYPE).filter(([type, pattern]) => {
    return toggles[RULE_BY_TYPE[type] as keyof typeof toggles] !== false && policy.secretToggles[pattern] !== false;
  }).map(([type]) => type));
}
async function listPrFiles(auth: string, input: SecretPrInput): Promise<PullFile[]> {
  const all: PullFile[] = [];
  for (let page = 1; all.length < 200; page++) {
    const items = await request<PullFile[]>(auth, `${repoPath(input)}/pulls/${input.pullNumber}/files?per_page=100&page=${page}`);
    all.push(...items.slice(0, 200 - all.length));
    if (items.length < 100) break;
  }
  return all;
}
function scanAddedLines(path: string, patch: string, enabled: Set<string>): SecretPrFinding[] {
  const findings: SecretPrFinding[] = [];
  let currentLine = 0;
  for (const line of patch.split(/\r?\n/)) {
    const hunk = line.match(/^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@/);
    if (hunk) { currentLine = Number(hunk[1]); continue; }
    if (line.startsWith("+++")) continue;
    if (line.startsWith("+")) {
      const added = line.slice(1);
      for (const finding of scanText(added)) {
        if (enabled.has(finding.type)) findings.push({ path, line: currentLine, type: finding.type, maskedPreview: "•••" });
      }
      currentLine++;
    } else if (!line.startsWith("-")) {
      if (!line.startsWith("\\")) currentLine++;
    }
  }
  return findings;
}
export async function detectSecretsInPr(input: SecretPrInput): Promise<{ findings: SecretPrFinding[]; fork: boolean }> {
  const auth = await token();
  const pull = await getPull(auth, input);
  const enabled = await enabledSecretTypes(input.owner, input.repo);
  if (!enabled.size) return { findings: [], fork: !pull.head.repo || pull.head.repo.full_name.toLowerCase() !== `${input.owner}/${input.repo}`.toLowerCase() };
  const files = await listPrFiles(auth, input);
  const findings = files.filter(file => file.patch && !file.patch.includes("Binary files "))
    .flatMap(file => scanAddedLines(file.filename, file.patch!, enabled));
  return { findings, fork: !pull.head.repo || pull.head.repo.full_name.toLowerCase() !== `${input.owner}/${input.repo}`.toLowerCase() };
}

function encodePath(path: string): string { return path.split("/").map(encodeURIComponent).join("/"); }
function validateRepoPath(path: string): void {
  if (!path || path.startsWith("/") || path.includes("\\") || path.split("/").some(part => !part || part === "." || part === "..")) throw new Error("GitHub returned an unsupported file path.");
}
async function readFile(auth: string, input: SecretPrInput, path: string, sha: string): Promise<string | null> {
  validateRepoPath(path);
  let response: Response;
  try { response = await fetch(`${API}${repoPath(input)}/contents/${encodePath(path)}?ref=${encodeURIComponent(sha)}`, { headers: { Accept: "application/vnd.github+json", Authorization: `Bearer ${auth}`, "X-GitHub-Api-Version": "2022-11-28" } }); }
  catch { throw new Error("Network failure while fetching a PR file."); }
  if (response.status === 404) return null;
  if (!response.ok) throw new Error(response.status === 403 ? "GitHub denied access. The token needs Contents read/write access." : `GitHub request failed (HTTP ${response.status}).`);
  const data = await response.json() as { content?: string; encoding?: string; size?: number; truncated?: boolean };
  if (data.encoding !== "base64" || !data.content || data.truncated) throw new Error("GitHub did not provide a complete text file.");
  const binary = atob(data.content.replace(/\s/g, ""));
  return new TextDecoder("utf-8", { fatal: true }).decode(Uint8Array.from(binary, c => c.charCodeAt(0)));
}
function envLookup(path: string, name: string): string {
  const ext = path.toLowerCase().split(".").pop();
  if (["js", "ts", "jsx", "tsx"].includes(ext || "")) return `process.env.${name}`;
  if (ext === "py") return `os.environ["${name}"]`;
  if (ext === "java") return `System.getenv("${name}")`;
  if (ext === "go") return `os.Getenv("${name}")`;
  if (ext === "rb") return `ENV["${name}"]`;
  if (ext === "php") return `getenv("${name}")`;
  if (ext === "sh") return `"\${${name}}"`;
  return `"\${${name}}"`;
}
function nameFor(type: string, ordinal: number): string { return NAME_BY_TYPE[type] ?? `SECRET_${ordinal}`; }
function unifiedPatch(path: string, oldText: string, newText: string, isNew = false): string {
  const oldLines = isNew ? [] : oldText.replace(/\r\n/g, "\n").split("\n");
  const newLines = newText.replace(/\r\n/g, "\n").split("\n");
  if (oldText.endsWith("\n") && oldLines.at(-1) === "") oldLines.pop();
  if (newText.endsWith("\n") && newLines.at(-1) === "") newLines.pop();
  let prefix = 0; while (prefix < oldLines.length && prefix < newLines.length && oldLines[prefix] === newLines[prefix]) prefix++;
  let suffix = 0; while (suffix < oldLines.length - prefix && suffix < newLines.length - prefix && oldLines[oldLines.length - 1 - suffix] === newLines[newLines.length - 1 - suffix]) suffix++;
  const start = Math.max(0, prefix - 3), oldEnd = Math.min(oldLines.length, oldLines.length - suffix + 3), newEnd = Math.min(newLines.length, newLines.length - suffix + 3);
  const chunk = [...oldLines.slice(start, prefix).map(x=>` ${x}`), ...oldLines.slice(prefix, oldLines.length-suffix).map(x=>`-${x}`), ...newLines.slice(prefix, newLines.length-suffix).map(x=>`+${x}`), ...oldLines.slice(oldLines.length-suffix, oldEnd).map(x=>` ${x}`)];
  const oldCount = oldEnd - start, newCount = newEnd - start;
  const header = isNew ? `@@ -0,0 +1,${newLines.length} @@` : `@@ -${start+1},${oldCount} +${start+1},${newCount} @@`;
  return `diff --git a/${path} b/${path}\n${isNew ? "new file mode 100644\n--- /dev/null\n" : `--- a/${path}\n`}+++ b/${path}\n${header}\n${chunk.join("\n")}`;
}
function applySecretEdits(path: string, original: string, selected: SecretPrFinding[]): SecretEdit {
  let content = original, manual = false, ordinal = 0;
  const secrets: string[] = [];
  const ordered = [...selected].sort((a,b)=>b.line-a.line);
  for (const item of ordered) {
    ordinal++;
    const lines = content.split(/\r?\n/);
    const line = lines[item.line - 1];
    if (line === undefined) throw new Error("The PR file changed since detection. Refresh and try again.");
    const found = scanText(line).find(f => f.type === item.type);
    if (!found && item.type !== "PEM Private Key") throw new Error("The detected value is no longer at that line. Refresh and try again.");
    const name = NAME_BY_TYPE[item.type] ?? nameFor(item.type, ++ordinal);
    if (item.type === "PEM Private Key") {
      const re = /-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY-----/;
      const match = [...content.matchAll(new RegExp(re.source, "g"))].find(candidate => content.slice(0, candidate.index).split("\n").length === item.line);
      if (!match) throw new Error("Could not safely locate the private key block.");
      secrets.push(match[0]);
      content = content.slice(0, match.index) + envLookup(path, "PRIVATE_KEY") + content.slice(match.index! + match[0].length);
      manual = true; continue;
    }
    const secret = line.slice(found!.index, found!.index + found!.length);
    const lineStart = lines.slice(0, item.line - 1).reduce((sum, part) => sum + part.length + 1, 0);
    const start = lineStart + found!.index, end = start + found!.length;
    secrets.push(secret);
    const quote = [...line.matchAll(/(["'`])([^\r\n]*?)\1/g)].find(candidate => candidate.index !== undefined && candidate.index <= found!.index && candidate.index + candidate[0].length >= found!.index + found!.length);
    if (quote && quote[2] === secret && quote.index !== undefined) {
      const lookup = envLookup(path, name);
      content = content.slice(0, lineStart + quote.index) + lookup + content.slice(lineStart + quote.index + quote[0].length);
    } else {
      content = content.slice(0, start) + `\${${name}}` + content.slice(end);
      manual = true;
    }
  }
  if (path.toLowerCase().endsWith(".py") && !/^\s*import\s+os\b/m.test(content)) {
    const insertion = content.startsWith("#!") ? (content.indexOf("\n") + 1 || 0) : 0;
    content = content.slice(0, insertion) + "import os\n" + content.slice(insertion);
  }
  if (path.toLowerCase().endsWith(".go") && !/^\s*"os"\s*$/m.test(content) && !/^\s*import\s+"os"/m.test(content)) {
    const packageLine = /^(package\s+[\w]+\s*\r?\n)/m.exec(content);
    if (packageLine?.index !== undefined) {
      const afterPackage = packageLine.index + packageLine[0].length;
      content = content.slice(0, afterPackage) + '\nimport "os"\n' + content.slice(afterPackage);
    } else manual = true;
  }
  return { file: path, content, patch: unifiedPatch(path, original, content), isNewFile: false, manual, secrets };
}
async function prepare(auth: string, input: SecretPrInput, selected: SecretPrFinding[], confirmWorkflow: boolean): Promise<{ pull: PullData; edits: SecretEdit[]; confirmPaths?: string[] }> {
  const pull = await getPull(auth, input);
  if (!pull.head.repo || pull.head.repo.full_name.toLowerCase() !== `${input.owner}/${input.repo}`.toLowerCase()) throw new Error("I can't push to forks");
  const files = await listPrFiles(auth, input);
  const enabled = await enabledSecretTypes(input.owner, input.repo);
  const grouped = new Map<string, SecretPrFinding[]>();
  for (const item of selected) {
    if (!enabled.has(item.type)) throw new Error("This secret detector is disabled in Athena settings.");
    if (!files.some(f => f.filename === item.path && f.patch && scanAddedLines(f.filename, f.patch, enabled).some(x => x.line === item.line && x.type === item.type))) throw new Error("The finding is no longer in added PR lines. Refresh and try again.");
    grouped.set(item.path, [...(grouped.get(item.path) ?? []), item]);
  }
  if (!selected.length || grouped.size > 5) throw new Error("Select findings in up to 5 files.");
  const edits: SecretEdit[] = [];
  for (const [path, items] of grouped) {
    const original = await readFile(auth, input, path, pull.head.sha);
    if (original === null) throw new Error(`Could not fetch ${path} at the PR head.`);
    edits.push(applySecretEdits(path, original, items));
  }
  let unknownName = 0;
  const names = new Set(selected.map(f=>NAME_BY_TYPE[f.type] ?? `SECRET_${++unknownName}`));
  const envExample = await readFile(auth, input, ".env.example", pull.head.sha);
  if (envExample === null) {
    const content = [...names].map(name=>`${name}=`).join("\n") + "\n";
    edits.push({ file: ".env.example", content, patch: unifiedPatch(".env.example", "", content, true), isNewFile: true, manual: false, secrets: [] });
  } else {
    const lines = envExample.split(/\r?\n/).filter(Boolean);
    for (const name of names) if (!lines.some(line=>line.trim().startsWith(`${name}=`))) lines.push(`${name}=`);
    const content = lines.join("\n") + (envExample.endsWith("\n") || lines.length ? "\n" : "");
    if (content !== envExample) {
      const existing = edits.find(edit=>edit.file === ".env.example");
      if (existing) { existing.content = content; existing.patch = unifiedPatch(".env.example", envExample, content); }
      else edits.push({ file: ".env.example", content, patch: unifiedPatch(".env.example", envExample, content), isNewFile: false, manual: false, secrets: [] });
    }
  }
  const gitignore = await readFile(auth, input, ".gitignore", pull.head.sha);
  if (!gitignore || !/(^|\r?\n)\/?\.env(?:\s|$|\/)/m.test(gitignore)) {
    const content = `${gitignore ?? ""}${gitignore && !gitignore.endsWith("\n") ? "\n" : ""}.env\n`;
    const existing = edits.find(edit=>edit.file === ".gitignore");
    if (existing) { existing.content = content; existing.patch = unifiedPatch(".gitignore", gitignore ?? "", content, gitignore === null); existing.isNewFile = gitignore === null; }
    else edits.push({ file: ".gitignore", content, patch: unifiedPatch(".gitignore", gitignore ?? "", content, gitignore === null), isNewFile: gitignore === null, manual: false, secrets: [] });
  }
  if (edits.length > 5) throw new Error("The secret fix would change more than 5 files.");
  const protectedPaths = edits.filter(e=>e.file.toLowerCase().startsWith(".github/workflows/")).map(e=>e.file);
  if (protectedPaths.length && !confirmWorkflow) return { pull, edits: [], confirmPaths: protectedPaths };
  return { pull, edits };
}
function maskedDiff(edits: SecretEdit[]): string {
  return edits.map(edit => {
    let patch = edit.patch;
    for (const secret of edit.secrets) if (secret) patch = patch.split(secret).join("•••");
    patch = patch.replace(/-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY-----/g, "•••");
    const findings = scanText(patch).sort((a,b)=>b.index-a.index);
    for (const finding of findings) patch = patch.slice(0, finding.index) + "•••" + patch.slice(finding.index + finding.length);
    return patch;
  }).join("\n");
}
export async function previewSecretFix(input: SecretPrInput, selected: SecretPrFinding[], confirmWorkflow = false): Promise<Result> {
  const auth = await token();
  const result = await prepare(auth, input, selected, confirmWorkflow);
  if (result.confirmPaths) return { confirmPaths: result.confirmPaths };
  const id = crypto.randomUUID();
  const uniqueTypes = [...new Set(selected.map(f=>f.type))];
  const paths = result.edits.map(e=>e.file);
  const summary = `Remove hardcoded ${uniqueTypes.join(", ")}; update ${paths.join(", ")}.`;
  return { id, summary, files: paths, diff: maskedDiff(result.edits), reviewManually: result.edits.some(e=>e.manual) || selected.some(f=>f.type === "PEM Private Key") };
}
export async function createSecretFixPr(input: SecretPrInput, selected: SecretPrFinding[], confirmWorkflow = false): Promise<{ number: number; url: string }> {
  const auth = await token();
  const prepared = await prepare(auth, input, selected, confirmWorkflow);
  if (prepared.confirmPaths) throw new Error("Confirm the workflow file change before creating the PR.");
  const types = [...new Set(selected.map(f=>f.type))];
  const title = `[Athena] Remove hardcoded ${types.join(", ")}`;
  const summary = `${title.slice("[Athena] ".length)}. AI-generated by Athena. Review manually where indicated. Revoke or rotate the exposed credential.`;
  const created = await createFixPullRequest({
    ...input, pullNumber: input.pullNumber, summary,
    files: prepared.edits.map(e=>({ path: e.file, patch: e.patch.split("\n").slice(e.isNewFile ? 4 : 3).join("\n"), isNewFile: e.isNewFile })),
    sourceSha: prepared.pull.head.sha, targetBranch: prepared.pull.head.ref, secretFix: true, titleOverride: title,
  });
  for (const finding of selected) {
    try { await logActivity({ type: "fix-action", ruleId: "secret-pr-files", label: `${finding.type} in ${finding.path}`, repo: "" }); } catch { /* best-effort; never log secret contents */ }
  }
  return created;
}
export function revokeUrl(type: string): string | undefined { return REVOKE_URL_BY_TYPE[type]; }
