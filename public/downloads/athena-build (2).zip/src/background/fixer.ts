import { loadSettings, logActivity } from "../storage/session";

const API_ROOT = "https://api.github.com";
const FIX_BRANCH_RE = /^athena\/(?:fix-(?:[a-f0-9]{8}|pr\d+-[a-f0-9]{6}|secret-pr\d+-[a-f0-9]{6})|resolve-pr\d+-[a-f0-9]{6})$/;

export interface GitHubRepositoryInput {
  owner: string;
  repo: string;
}

export interface UpdateBranchInput extends GitHubRepositoryInput {
  pullNumber: number;
}

export interface FixPatchFile {
  path: string;
  patch: string;
  isNewFile: boolean;
}

export interface CreateFixPullRequestInput extends GitHubRepositoryInput {
  pullNumber: number;
  summary: string;
  files: FixPatchFile[];
  sourceSha?: string;
  targetBranch?: string;
  checkName?: string;
  secretFix?: boolean;
  titleOverride?: string;
}

export interface CreateBranchInput extends GitHubRepositoryInput {
  branchName: string;
  fromBranch: string;
}

export interface CommitFile {
  path: string;
  content: string;
}

export interface CommitFilesInput extends GitHubRepositoryInput {
  branchName: string;
  message: string;
  files: CommitFile[];
}

export interface OpenPullRequestInput extends GitHubRepositoryInput {
  headBranch: string;
  baseBranch: string;
  title: string;
  summary: string;
  changedPaths: string[];
  bodyNotice?: string;
}

export type FixerResponse =
  | { ok: true; message: string; pullNumber?: number; url?: string }
  | { ok: false; error: string };

interface GitHubError extends Error {
  status?: number;
}

function repoPath({ owner, repo }: GitHubRepositoryInput): string {
  if (!/^[\w.-]+$/.test(owner) || !/^[\w.-]+$/.test(repo)) {
    throw new Error("Invalid GitHub repository.");
  }
  return `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`;
}

function validateBranch(branch: string): void {
  if (!branch || branch.length > 240 || branch.startsWith("/") || branch.endsWith("/") || branch.includes("..") || /[\s~^:?*\\[]/.test(branch)) {
    throw new Error("Invalid branch name.");
  }
}

function refPath(branch: string): string {
  validateBranch(branch);
  return branch.split("/").map(encodeURIComponent).join("/");
}

function validateFilePath(path: string): void {
  if (
    !path || path.length > 240 || path.startsWith("/") || path.includes("\\") ||
    path.split("/").some((part) => !part || part === "." || part === "..") ||
    path.split("/").some((part) => part === ".git") || /[\u0000-\u001f`]/.test(path)
  ) {
    throw new Error("The proposed diff contains an unsupported file path.");
  }
}

function encodedFilePath(path: string): string {
  validateFilePath(path);
  return path.split("/").map(encodeURIComponent).join("/");
}

async function getToken(): Promise<string> {
  const token = (await loadSettings()).githubPat.trim();
  if (!token) {
    throw new Error("Add a GitHub Personal Access Token with repository contents and pull request write access in Athena Settings.");
  }
  return token;
}

async function requestJson<T>(token: string, path: string, method = "GET", body?: unknown): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${API_ROOT}${path}`, {
      method,
      headers: {
        Accept: "application/vnd.github+json",
        Authorization: `Bearer ${token}`,
        "X-GitHub-Api-Version": "2022-11-28",
        ...(body === undefined ? {} : { "Content-Type": "application/json" }),
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
  } catch {
    throw new Error("Could not reach the GitHub API.");
  }

  if (!response.ok) {
    const rateLimited = response.headers.get("X-RateLimit-Remaining") === "0";
    const message = rateLimited ? "GitHub rate limit reached. Try again later."
      : response.status === 403 ? "GitHub denied access. Check repository Contents and Pull requests write permissions."
      : response.status === 404 ? "GitHub could not find the PR, commit, or file. Refresh the PR and try again."
      : response.status === 409 ? "GitHub reported a conflict because the PR changed. Refresh and try again."
      : `GitHub API request failed (HTTP ${response.status}).`;
    const error = new Error(message) as GitHubError;
    error.status = response.status;
    throw error;
  }
  if (response.status === 204) return undefined as T;
  try {
    return await response.json() as T;
  } catch {
    throw new Error("GitHub returned an unreadable response.");
  }
}

async function recordFixAction(label: string, input: GitHubRepositoryInput): Promise<void> {
  try {
    await logActivity({
      type: "fix-action",
      ruleId: "fix-it",
      label,
      repo: `${input.owner}/${input.repo}`,
    });
  } catch {
    // Activity logging must never expose or interrupt a GitHub write request.
  }
}

export async function updateBranch(input: UpdateBranchInput): Promise<void> {
  try {
    const token = await getToken();
    const path = `${repoPath(input)}/pulls/${input.pullNumber}/update-branch`;
    await requestJson<unknown>(token, path, "PUT", {});
    await recordFixAction("Updated pull request branch", input);
  } catch (error) {
    await recordFixAction("Pull request branch update failed", input);
    throw error;
  }
}

async function createBranchWithToken(input: CreateBranchInput, token: string): Promise<void> {
  if (!FIX_BRANCH_RE.test(input.branchName)) throw new Error("Fix branches must use the athena/fix-<short-id> name.");
  if (/^athena\/fix-(?:pr|secret-pr)/.test(input.branchName) && /^[a-f0-9]{40}$/i.test(input.fromBranch)) {
    await requestJson<unknown>(token, `${repoPath(input)}/git/refs`, "POST", {
      ref: `refs/heads/${input.branchName}`, sha: input.fromBranch,
    });
    return;
  }
  validateBranch(input.fromBranch);
  const root = repoPath(input);
  const source = await requestJson<{ object: { sha: string } }>(
    token,
    `${root}/git/ref/heads/${refPath(input.fromBranch)}`
  );
  await requestJson<unknown>(token, `${root}/git/refs`, "POST", {
    ref: `refs/heads/${input.branchName}`,
    sha: source.object.sha,
  });
}

export async function createBranch(input: CreateBranchInput): Promise<void> {
  await createBranchWithToken(input, await getToken());
}

async function fetchFileAtBranch(
  input: GitHubRepositoryInput,
  path: string,
  branch: string,
  token: string,
  allowMissing: boolean
): Promise<string> {
  try {
    const data = await requestJson<{ content?: string; encoding?: string; size?: number; truncated?: boolean }>(
      token,
      `${repoPath(input)}/contents/${encodedFilePath(path)}?ref=${encodeURIComponent(branch)}`
    );
    if (data.encoding !== "base64" || !data.content || data.truncated) {
      throw new Error("GitHub could not provide a complete text file for the proposed fix.");
    }
    const binary = atob(data.content.replace(/\s/g, ""));
    const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
    return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch (error) {
    if (allowMissing && (error as GitHubError).status === 404) return "";
    throw error;
  }
}

function applyUnifiedDiff(original: string, patch: string): string {
  const lines = patch.replace(/\r\n/g, "\n").split("\n");
  const hunkIndexes: number[] = [];
  for (let i = 0; i < lines.length; i++) if (lines[i].startsWith("@@ ")) hunkIndexes.push(i);
  if (!hunkIndexes.length) throw new Error("The proposed diff has no valid unified-diff hunks.");

  const eol = original.includes("\r\n") ? "\r\n" : "\n";
  const finalNewline = original.endsWith("\n");
  const source = original === "" ? [] : original.replace(/\r\n/g, "\n").split("\n");
  if (finalNewline) source.pop();
  const result: string[] = [];
  let sourceIndex = 0;

  for (let h = 0; h < hunkIndexes.length; h++) {
    const startLine = hunkIndexes[h];
    const endLine = h + 1 < hunkIndexes.length ? hunkIndexes[h + 1] : lines.length;
    const header = lines[startLine].match(/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/);
    if (!header) throw new Error("The proposed diff contains an invalid hunk header.");
    const oldStart = Number(header[1]);
    const expectedOld = header[2] === undefined ? 1 : Number(header[2]);
    const expectedNew = header[4] === undefined ? 1 : Number(header[4]);
    const targetIndex = oldStart === 0 ? 0 : oldStart - 1;
    if (targetIndex < sourceIndex || targetIndex > source.length) throw new Error("The proposed diff does not match the current file.");
    result.push(...source.slice(sourceIndex, targetIndex));
    sourceIndex = targetIndex;
    let oldCount = 0;
    let newCount = 0;

    for (let i = startLine + 1; i < endLine; i++) {
      const line = lines[i];
      if (line.startsWith("\\ No newline")) continue;
      if (line.startsWith(" ")) {
        const text = line.slice(1);
        if (source[sourceIndex] !== text) throw new Error("The proposed diff no longer matches the current file. Refresh the page and ask Athena to propose it again.");
        result.push(text);
        sourceIndex++;
        oldCount++;
        newCount++;
      } else if (line.startsWith("-")) {
        if (source[sourceIndex] !== line.slice(1)) throw new Error("The proposed diff no longer matches the current file. Refresh the page and ask Athena to propose it again.");
        sourceIndex++;
        oldCount++;
      } else if (line.startsWith("+")) {
        result.push(line.slice(1));
        newCount++;
      } else if (line.length > 0) {
        throw new Error("The proposed diff contains an unsupported line.");
      }
    }
    if (oldCount !== expectedOld || newCount !== expectedNew) throw new Error("The proposed diff hunk counts are invalid.");
  }

  result.push(...source.slice(sourceIndex));
  return result.join(eol) + (finalNewline || result.length > 0 ? eol : "");
}

async function preparePatchedFiles(
  input: CreateFixPullRequestInput,
  sourceBranch: string,
  token: string
): Promise<CommitFile[]> {
  if (!input.files.length || input.files.length > 8) throw new Error("A fix preview must change between 1 and 8 files.");
  const seen = new Set<string>();
  const files: CommitFile[] = [];
  for (const proposed of input.files) {
    validateFilePath(proposed.path);
    if (seen.has(proposed.path)) throw new Error("The proposed diff repeats a file path.");
    seen.add(proposed.path);
    if (proposed.patch.length > 250_000) throw new Error("A proposed file diff is too large.");
    const original = await fetchFileAtBranch(input, proposed.path, sourceBranch, token, proposed.isNewFile);
    if (!proposed.isNewFile && !original) throw new Error("A changed file could not be read from the pull request branch.");
    const content = applyUnifiedDiff(original, proposed.patch);
    if (content.length > 500_000) throw new Error("A proposed file is too large to commit.");
    files.push({ path: proposed.path, content });
  }
  return files;
}

async function commitFilesWithToken(input: CommitFilesInput, token: string): Promise<void> {
  if (!FIX_BRANCH_RE.test(input.branchName)) throw new Error("Commits are allowed only on Athena fix branches.");
  if (!input.files.length || input.files.length > 8) throw new Error("A fix commit must contain between 1 and 8 files.");
  const root = repoPath(input);
  const ref = await requestJson<{ object: { sha: string } }>(token, `${root}/git/ref/heads/${refPath(input.branchName)}`);
  const parent = await requestJson<{ tree: { sha: string } }>(token, `${root}/git/commits/${encodeURIComponent(ref.object.sha)}`);
  const treeItems: Array<{ path: string; mode: "100644"; type: "blob"; sha: string }> = [];

  for (const file of input.files) {
    validateFilePath(file.path);
    if (file.content.length > 500_000) throw new Error("A proposed file is too large to commit.");
    const blob = await requestJson<{ sha: string }>(token, `${root}/git/blobs`, "POST", {
      content: file.content,
      encoding: "utf-8",
    });
    treeItems.push({ path: file.path, mode: "100644", type: "blob", sha: blob.sha });
  }

  const tree = await requestJson<{ sha: string }>(token, `${root}/git/trees`, "POST", {
    base_tree: parent.tree.sha,
    tree: treeItems,
  });
  const commit = await requestJson<{ sha: string }>(token, `${root}/git/commits`, "POST", {
    message: input.message,
    tree: tree.sha,
    parents: [ref.object.sha],
  });
  await requestJson<unknown>(token, `${root}/git/refs/heads/${refPath(input.branchName)}`, "PATCH", {
    sha: commit.sha,
    force: false,
  });
}

export async function commitFiles(input: CommitFilesInput): Promise<void> {
  await commitFilesWithToken(input, await getToken());
}

async function openPullRequestWithToken(input: OpenPullRequestInput, token: string): Promise<{ number: number; html_url: string }> {
  if (!FIX_BRANCH_RE.test(input.headBranch)) throw new Error("Fix pull requests must use an Athena fix branch.");
  if (input.headBranch === input.baseBranch) throw new Error("The fix branch and target branch must be different.");
  if (!input.title.startsWith("[Athena]")) throw new Error("Fix pull request titles must start with [Athena].");
  const summary = input.summary.trim().slice(0, 500) || "Changes proposed in the reviewed unified diff.";
  const changedFiles = [...new Set(input.changedPaths.map((path) => {
    validateFilePath(path);
    return path;
  }))];
  const body = [
    input.bodyNotice ?? "This pull request is AI-generated by Athena and was created from a diff you reviewed.",
    "",
    "## What changed",
    `- ${summary.replace(/[\r\n]+/g, " ")}`,
    ...changedFiles.map((path) => `- Updated \`${path}\`.`),
    "",
    "Athena did not merge this pull request.",
  ].join("\n");
  return requestJson(token, `${repoPath(input)}/pulls`, "POST", {
    title: input.title,
    body,
    head: input.headBranch,
    base: input.baseBranch,
    draft: true,
  });
}

export async function openPullRequest(input: OpenPullRequestInput): Promise<{ number: number; html_url: string }> {
  return openPullRequestWithToken(input, await getToken());
}

export interface MergeTreeEntry {
  path: string;
  mode: "100644";
  type: "blob";
  content?: string;
  sha?: string | null;
}

export interface CreateResolvedMergePullRequestInput extends GitHubRepositoryInput {
  pullNumber: number;
  expectedHeadSha: string;
  headBranch: string;
  baseBranch: string;
  baseSha: string;
  baseTreeSha: string;
  treeEntries: MergeTreeEntry[];
  title: string;
  summary: string;
  changedPaths: string[];
}

/** Build a real two-parent merge commit and open a PR from a new Athena branch. */
export async function createResolvedMergePullRequest(input: CreateResolvedMergePullRequestInput): Promise<{ number: number; url: string }> {
  const token = await getToken();
  const root = repoPath(input);
  const pull = await requestJson<{ head: { sha: string; ref: string; repo: { full_name: string } | null }; base: { sha: string; ref: string } }>(token, `${root}/pulls/${input.pullNumber}`);
  if (!pull.head.repo || pull.head.repo.full_name.toLowerCase() !== `${input.owner}/${input.repo}`.toLowerCase()) throw new Error("I can't push to forks");
  if (pull.head.sha !== input.expectedHeadSha || pull.head.ref !== input.headBranch) throw new Error("The PR head changed during conflict resolution. Refresh and try again.");
  if (pull.base.sha !== input.baseSha || pull.base.ref !== input.baseBranch) throw new Error("The PR base changed during conflict resolution. Refresh and try again.");
  if (!input.treeEntries.length) throw new Error("The merge result contains no changed files.");
  const seen = new Set<string>();
  const tree = input.treeEntries.map(entry => {
    validateFilePath(entry.path);
    if (seen.has(entry.path)) throw new Error("The merge result repeats a file path.");
    seen.add(entry.path);
    return entry;
  });
  const createdTree = await requestJson<{ sha: string }>(token, `${root}/git/trees`, "POST", {
    base_tree: input.baseTreeSha,
    tree,
  });
  const commit = await requestJson<{ sha: string }>(token, `${root}/git/commits`, "POST", {
    message: `Merge ${input.baseBranch} into ${input.headBranch} (resolved by Athena)`,
    tree: createdTree.sha,
    parents: [input.expectedHeadSha, input.baseSha],
  });
  const id = crypto.randomUUID().replace(/-/g, "").slice(0, 6).toLowerCase();
  const branchName = `athena/resolve-pr${input.pullNumber}-${id}`;
  await requestJson<unknown>(token, `${root}/git/refs`, "POST", { ref: `refs/heads/${branchName}`, sha: commit.sha });
  try {
    const pr = await openPullRequestWithToken({
      ...input,
      headBranch: branchName,
      baseBranch: input.headBranch,
      title: input.title,
      summary: input.summary,
      changedPaths: input.changedPaths,
      bodyNotice: "This merge resolution was generated by Athena's conflict resolution flow. Athena did not merge the pull request.",
    }, token);
    for (const path of input.changedPaths) {
      try { await logActivity({ type: "fix-action", ruleId: "resolve-conflicts", label: path, repo: "" }); } catch { /* best-effort path-only activity */ }
    }
    return { number: pr.number, url: pr.html_url };
  } catch (error) {
    try { await deleteBranchRef(input, branchName, token); } catch { /* Preserve the original PR creation error. */ }
    throw error;
  }
}

async function deleteBranchRef(input: GitHubRepositoryInput, branch: string, token: string): Promise<void> {
  await requestJson<unknown>(token, `${repoPath(input)}/git/refs/heads/${refPath(branch)}`, "DELETE");
}

export async function createFixPullRequest(input: CreateFixPullRequestInput): Promise<{ number: number; url: string }> {
  if (!input.secretFix) await recordFixAction("Started AI fix pull request creation", input);
  try {
    const token = await getToken();
    const root = repoPath(input);
    const pull = await requestJson<{
      base: { ref: string };
      head: { ref: string; repo: { full_name: string } | null };
    }>(token, `${root}/pulls/${input.pullNumber}`);
    if (!pull.head.repo || pull.head.repo.full_name.toLowerCase() !== `${input.owner}/${input.repo}`.toLowerCase()) {
      throw new Error("Creating an Athena fix PR is currently supported for branches in this same repository only.");
    }
    if (pull.head.ref === pull.base.ref) throw new Error("The pull request head and base branches are identical.");

    // Read and validate every proposed patch before creating any remote ref.
    const sourceRef = input.sourceSha ?? pull.head.ref;
    const files = await preparePatchedFiles(input, sourceRef, token);
    const shortId = crypto.randomUUID().replace(/-/g, "").slice(0, input.sourceSha ? 6 : 8).toLowerCase();
    const branchName = input.secretFix ? `athena/fix-secret-pr${input.pullNumber}-${shortId}` : input.sourceSha ? `athena/fix-pr${input.pullNumber}-${shortId}` : `athena/fix-${shortId}`;
    let branchCreated = false;
    try {
    await createBranchWithToken({ ...input, branchName, fromBranch: sourceRef }, token);
    branchCreated = true;
    if (!input.secretFix) await recordFixAction("Created AI fix branch", input);
    await commitFilesWithToken({
      ...input,
      branchName,
      message: "[Athena] AI-generated fix",
      files,
    }, token);
    if (!input.secretFix) await recordFixAction("Committed reviewed AI fix", input);
    const created = await openPullRequestWithToken({
      ...input,
      headBranch: branchName,
      baseBranch: input.targetBranch ?? pull.base.ref,
      title: input.titleOverride ?? (input.checkName ? `[Athena] Fix ${input.checkName}` : `[Athena] ${input.summary.trim().replace(/[\r\n]+/g, " ").slice(0, 160) || "Proposed fix"}`),
      changedPaths: files.map((file) => file.path),
    }, token);
    if (!input.secretFix) await recordFixAction(`Opened AI fix pull request #${created.number}`, input);
    return { number: created.number, url: created.html_url };
    } catch (error) {
      if (branchCreated) {
        try {
          await deleteBranchRef(input, branchName, token);
          if (!input.secretFix) await recordFixAction("Removed incomplete AI fix branch", input);
        } catch {
          // Keep the original sanitized API failure; never log credentials or patch contents.
        }
      }
      throw error;
    }
  } catch (error) {
    if (!input.secretFix) await recordFixAction("AI fix pull request failed", input);
    throw error;
  }
}
