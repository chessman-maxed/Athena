/**
 * Athena – Background Service Worker.
 *
 * Responsibilities:
 *  1. Set chrome.storage.session access level to TRUSTED_AND_UNTRUSTED_CONTEXTS
 *     so content scripts can read/write session storage directly.
 *     (Default is "trusted_contexts" only, which blocks content scripts.)
 *  2. Handle ATHENA_LLM_REQUEST messages from content scripts:
 *     - Read LLM settings (base URL, API key, model) via loadSettings.
 *     - Validate the endpoint URL.
 *     - Make the fetch request (background workers have access to optional
 *       host permissions granted by the user).
 *     - Return the explanation text or a descriptive error to the content script.
 *     The API key is NEVER echoed in error messages or logs.
 *  3. Handle ATHENA_REQUEST_LLM_PERMISSION messages from the popup:
 *     - Request optional host permission for the configured LLM endpoint.
 *  4. Log startup so the service-worker DevTools console shows activity.
 */

import { loadSettings, hasLLMConsent, normalizeBaseUrl, formatLLMErrorResponse } from "../storage/session";
import { createFixPullRequest, updateBranch, type FixPatchFile, type FixerResponse } from "./fixer";
import { gatherCiFix, proposeCiFix, createCiFixPr, cancelCiFix } from "./ci-fixer";
import { detectSecretsInPr, previewSecretFix, createSecretFixPr, type SecretPrFinding } from "./secret-pr-fixer";
import { gatherConflictResolution, previewConflictResolution, createConflictResolutionPr, type HunkResolution } from "./conflict-resolver";
import { suggestConflictResolution, type ConflictSuggestionInput } from "./conflict-suggestion";

// ── URL validation helper ─────────────────────────────────────────────────────

/**
 * Validates that a URL is a supported HTTP(S) endpoint.
 * Localhost is explicitly allowed (for local Ollama etc.).
 * Returns the validated URL origin (e.g. "https://api.openai.com") or null.
 */
function validateLLMBaseUrl(raw: string): { origin: string; baseUrl: string } | null {
  const target = raw && raw.trim() ? normalizeBaseUrl(raw) : "https://api.openai.com/v1";
  try {
    const url = new URL(target);
    if (url.protocol !== "https:" && url.protocol !== "http:") return null;
    // Allow localhost / 127.0.0.1 / ::1 without HTTPS requirement
    const isLocal =
      url.hostname === "localhost" ||
      url.hostname === "127.0.0.1" ||
      url.hostname === "::1";
    if (!isLocal && url.protocol !== "https:") return null;
    return { origin: url.origin, baseUrl: normalizeBaseUrl(url.href) };
  } catch {
    return null;
  }
}

// ── Permission helpers ────────────────────────────────────────────────────────

/**
 * Checks whether the extension already has optional host permission for the
 * given origin (e.g. "https://api.openai.com").
 */
async function hasHostPermission(origin: string): Promise<boolean> {
  return new Promise((resolve) => {
    if (typeof chrome === "undefined" || !chrome.permissions) {
      resolve(true);
      return;
    }
    chrome.permissions.contains(
      { origins: [`${origin}/*`] },
      (result) => resolve(!!result)
    );
  });
}

// ── Message handler ───────────────────────────────────────────────────────────

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

type BgResponse =
  | { ok: true; [key: string]: unknown }
  | { ok: true; explanation: string; reply: string }
  | { ok: false; error: string }
  | { ok: true; granted: boolean }
  | FixerResponse;

chrome.runtime.onMessage.addListener(
  (
    message: {
      type: string;
      text?: string;
      messages?: ChatMessage[];
      systemPrompt?: string;
      pageContext?: string;
      baseUrl?: string;
      model?: string;
      owner?: string;
      repo?: string;
      pullNumber?: number;
      summary?: string;
      files?: FixPatchFile[];
      requestId?: string;
      confirmProtected?: boolean;
      secretFindings?: SecretPrFinding[];
      confirmWorkflow?: boolean;
      resolutions?: Record<string, HunkResolution>;
      confirmProtectedOnce?: boolean;
      confirmProtectedTwice?: boolean;
      hunk?: ConflictSuggestionInput;
      allowConsent?: boolean;
    },
    sender,
    sendResponse: (r: BgResponse) => void
  ) => {
    if (message.type === "ATHENA_UPDATE_BRANCH" || message.type === "ATHENA_CREATE_FIX_PR") {
      if (sender.id !== chrome.runtime.id) {
        sendResponse({ ok: false, error: "Untrusted extension message." });
        return false;
      }
      void (async () => {
        try {
          if (!message.owner || !message.repo || !Number.isInteger(message.pullNumber) || (message.pullNumber ?? 0) < 1) {
            throw new Error("Invalid pull request details.");
          }
          if (message.type === "ATHENA_UPDATE_BRANCH") {
            await updateBranch({ owner: message.owner, repo: message.repo, pullNumber: message.pullNumber! });
            sendResponse({ ok: true, message: "GitHub accepted the branch update request." });
            return;
          }
          if (!message.summary || !Array.isArray(message.files) || message.files.length === 0) {
            throw new Error("The fix preview is empty or invalid.");
          }
          const created = await createFixPullRequest({
            owner: message.owner,
            repo: message.repo,
            pullNumber: message.pullNumber!,
            summary: message.summary,
            files: message.files,
          });
          sendResponse({ ok: true, message: `Draft pull request #${created.number} created.`, pullNumber: created.number, url: created.url });
        } catch (error) {
          sendResponse({ ok: false, error: error instanceof Error ? error.message : "GitHub action failed." });
        }
      })();
      return true;
    }

    if (message.type === "ATHENA_CI_FIX_GATHER" || message.type === "ATHENA_CI_FIX_PROPOSE" || message.type === "ATHENA_CI_FIX_CREATE_PR" || message.type === "ATHENA_CI_FIX_CANCEL") {
      if (sender.id !== chrome.runtime.id) { sendResponse({ ok: false, error: "Untrusted extension message." }); return false; }
      void (async () => {
        try {
          if (!message.owner || !message.repo || !Number.isInteger(message.pullNumber) || (message.pullNumber ?? 0) < 1) throw new Error("Invalid pull request details.");
          if (message.type === "ATHENA_CI_FIX_GATHER") {
            sendResponse({ ok: true, ...(await gatherCiFix({ owner: message.owner, repo: message.repo, pullNumber: message.pullNumber! })) }); return;
          }
          if (!message.requestId) throw new Error("Invalid CI fix request.");
          if (message.type === "ATHENA_CI_FIX_CANCEL") { await cancelCiFix(message.requestId); sendResponse({ ok: true, message: "CI fix request cancelled." }); return; }
          if (message.type === "ATHENA_CI_FIX_PROPOSE") {
            sendResponse({ ok: true, ...(await proposeCiFix(message.requestId, !!message.confirmProtected)) }); return;
          }
          if (!message.summary || !Array.isArray(message.files) || !message.files.length) throw new Error("The fix preview is empty or invalid.");
          const created = await createCiFixPr(message.requestId, message.summary, message.files);
          sendResponse({ ok: true, message: `Pull request #${created.number} created.`, pullNumber: created.number, url: created.url });
        } catch (error) { sendResponse({ ok: false, error: error instanceof Error ? error.message : "CI fix action failed." }); }
      })();
      return true;
    }

    if (["ATHENA_SECRET_PR_SCAN", "ATHENA_SECRET_PR_PREVIEW", "ATHENA_SECRET_PR_CREATE"].includes(message.type)) {
      if (sender.id !== chrome.runtime.id) { sendResponse({ ok: false, error: "Untrusted extension message." }); return false; }
      void (async () => {
        try {
          if (!message.owner || !message.repo || !Number.isInteger(message.pullNumber) || (message.pullNumber ?? 0) < 1) throw new Error("Invalid pull request details.");
          const input = { owner: message.owner, repo: message.repo, pullNumber: message.pullNumber! };
          if (message.type === "ATHENA_SECRET_PR_SCAN") { sendResponse({ ok: true, ...(await detectSecretsInPr(input)) }); return; }
          if (!Array.isArray(message.secretFindings) || !message.secretFindings.length) throw new Error("Select at least one finding.");
          if (message.type === "ATHENA_SECRET_PR_PREVIEW") { sendResponse({ ok: true, ...(await previewSecretFix(input, message.secretFindings, !!message.confirmWorkflow)) }); return; }
          const created = await createSecretFixPr(input, message.secretFindings, !!message.confirmWorkflow);
          sendResponse({ ok: true, message: `Pull request #${created.number} created.`, pullNumber: created.number, url: created.url });
        } catch (error) { sendResponse({ ok: false, error: error instanceof Error ? error.message : "Secret fix action failed." }); }
      })();
      return true;
    }

    if (["ATHENA_CONFLICT_GATHER", "ATHENA_CONFLICT_PREVIEW", "ATHENA_CONFLICT_CREATE_PR"].includes(message.type)) {
      if (sender.id !== chrome.runtime.id) { sendResponse({ ok: false, error: "Untrusted extension message." }); return false; }
      void (async () => {
        try {
          if (!message.owner || !message.repo || !Number.isInteger(message.pullNumber) || (message.pullNumber ?? 0) < 1) throw new Error("Invalid pull request details.");
          const input = { owner: message.owner, repo: message.repo, pullNumber: message.pullNumber! };
          if (message.type === "ATHENA_CONFLICT_GATHER") { sendResponse({ ok: true, ...(await gatherConflictResolution(input)) }); return; }
          const resolutions = message.resolutions ?? {};
          if (message.type === "ATHENA_CONFLICT_PREVIEW") {
            sendResponse({ ok: true, ...(await previewConflictResolution(input, resolutions, !!message.confirmProtectedOnce)) }); return;
          }
          const created = await createConflictResolutionPr(input, resolutions, !!message.confirmProtectedOnce, !!message.confirmProtectedTwice);
          sendResponse({ ok: true, message: `Pull request #${created.number} created.`, pullNumber: created.number, url: created.url });
        } catch (error) { sendResponse({ ok: false, error: error instanceof Error ? error.message : "Conflict resolution failed." }); }
      })();
      return true;
    }

    if (message.type === "ATHENA_CONFLICT_SUGGEST") {
      if (sender.id !== chrome.runtime.id) { sendResponse({ ok: false, error: "Untrusted extension message." }); return false; }
      void (async () => {
        try {
          const hunk = message.hunk as ConflictSuggestionInput | undefined;
          if (!hunk) throw new Error("Invalid conflict hunk.");
          const result = await suggestConflictResolution({ ...hunk, allowConsent: !!message.allowConsent });
          sendResponse({ ok: true, ...result });
        } catch (error) { sendResponse({ ok: false, error: error instanceof Error ? error.message : "Could not get an AI suggestion." }); }
      })();
      return true;
    }

    // ── Chat request from active panel ─────────────────────────────────────
    if (message.type === "ATHENA_CHAT_REQUEST") {
      void handleChatOrExplainRequest({
        messages: message.messages,
        systemPrompt: message.systemPrompt,
        sendResponse,
      });
      return true;
    }

    // ── LLM explain-this request ───────────────────────────────────────────
    if (message.type === "ATHENA_LLM_REQUEST") {
      if (message.messages && message.messages.length > 0) {
        void handleChatOrExplainRequest({
          messages: message.messages,
          systemPrompt: message.systemPrompt,
          sendResponse,
        });
      } else {
        void handleChatOrExplainRequest({
          text: message.text ?? "",
          sendResponse,
        });
      }
      return true;
    }

    // ── Permission request check ───────────────────────────────────────────
    if (message.type === "ATHENA_REQUEST_LLM_PERMISSION") {
      void handlePermissionRequest(normalizeBaseUrl(message.baseUrl ?? ""), sendResponse);
      return true;
    }

    return false;
  }
);

async function handleChatOrExplainRequest(params: {
  text?: string;
  messages?: ChatMessage[];
  systemPrompt?: string;
  sendResponse: (r: BgResponse) => void;
}): Promise<void> {
  const { text, messages: inputMessages, systemPrompt, sendResponse } = params;

  try {
    if (!(await hasLLMConsent())) {
      sendResponse({ ok: false, error: "LLM analysis is disabled. Enable it in Athena Settings for this browser session." });
      return;
    }
    const settings = await loadSettings();
    const rawBaseUrl = settings.baseUrl.trim();
    const apiKey = settings.apiKey.trim();
    const model = settings.model.trim() || "gpt-4o-mini";

    if (!apiKey) {
      sendResponse({
        ok: false,
        error: "LLM API key is not configured. Please add your API key in Athena Settings.",
      });
      return;
    }

    const validated = validateLLMBaseUrl(rawBaseUrl || "https://api.openai.com/v1");
    if (!validated) {
      sendResponse({
        ok: false,
        error:
          "Invalid LLM endpoint URL. Please enter a valid HTTPS URL in Athena Settings " +
          "(e.g. https://api.openai.com/v1 or http://localhost:11434/v1 for Ollama).",
      });
      return;
    }

    // Check optional host permission for this origin
    const hasPermission = await hasHostPermission(validated.origin);
    if (!hasPermission) {
      sendResponse({
        ok: false,
        error:
          `Permission missing for ${validated.origin}. ` +
          "Open Athena Settings in the extension popup, re-save your endpoint URL, and grant access when prompted.",
      });
      return;
    }

    // Assemble payload messages
    let requestMessages: ChatMessage[] = [];

    if (inputMessages && inputMessages.length > 0) {
      requestMessages = inputMessages.map((m) => ({
        role: m.role,
        content: m.content,
      }));
    } else if (text && text.trim()) {
      requestMessages = [
        {
          role: "system",
          content:
            systemPrompt ||
            "You are an expert developer and code reviewer. Explain the selected git diff, commit changes, or error log snippet in clear, plain English. Highlight key changes, potential side-effects or risks, and what caused any errors.",
        },
        {
          role: "user",
          content: text.trim(),
        },
      ];
    } else {
      sendResponse({ ok: false, error: "Empty request – no messages or text provided." });
      return;
    }

    const endpoint = `${validated.baseUrl}/chat/completions`;

    let res: Response;
    try {
      res = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model,
          messages: requestMessages,
          max_tokens: 600,
          temperature: 0.2,
        }),
      });
    } catch (networkErr) {
      sendResponse({
        ok: false,
          error: `Network error reaching the configured LLM endpoint (${validated.origin}).`,
      });
      return;
    }

    if (!res.ok) {
      sendResponse({
        ok: false,
        error: formatLLMErrorResponse(res.status),
      });
      return;
    }

    const rawText = await res.text().catch(() => "");
    if (rawText.trim().startsWith("<")) {
      sendResponse({
        ok: false,
        error: formatLLMErrorResponse(res.status),
      });
      return;
    }

    let data: { choices?: Array<{ message?: { content?: string } }> };
    try {
      data = JSON.parse(rawText);
    } catch {
      sendResponse({
        ok: false,
        error: "LLM returned an invalid response.",
      });
      return;
    }

    const reply = data.choices?.[0]?.message?.content?.trim();
    if (!reply) {
      sendResponse({ ok: false, error: "LLM returned an empty response." });
      return;
    }

    const safeReply = apiKey ? reply.split(apiKey).join("[REDACTED]") : reply;
    sendResponse({ ok: true, explanation: safeReply, reply: safeReply });
  } catch {
    sendResponse({
      ok: false,
      error: "Unexpected error in Athena background worker. Please check your settings and try again.",
    });
  }
}

async function handlePermissionRequest(
  baseUrl: string,
  sendResponse: (r: BgResponse) => void
): Promise<void> {
  const validated = validateLLMBaseUrl(baseUrl);
  if (!validated) {
    sendResponse({ ok: false, error: "Invalid endpoint URL." });
    return;
  }

  const hasPerm = await hasHostPermission(validated.origin);
  sendResponse({ ok: true, granted: hasPerm });
}

// ── Startup log ───────────────────────────────────────────────────────────────
console.log("[Athena] Background service worker initialized.");
