import { diff3Merge, type MergeRegion } from "node-diff3";
import { loadSettings } from "../storage/session";
import { createResolvedMergePullRequest, type MergeTreeEntry } from "./fixer";

const API = "https://api.github.com";
export interface ResolveConflictInput { owner: string; repo: string; pullNumber: number }
export interface ConflictHunk { id: string; path: string; mine: string[]; theirs: string[]; ancestor: string[]; context: string[] }
export interface HunkResolution { choice: "mine" | "theirs" | "both" | "edit"; text?: string }
interface Pull { head: { sha: string; ref: string; repo: { full_name: string } | null }; base: { sha: string; ref: string } }
interface ChangedFile { filename: string; status: string; sha?: string; previous_filename?: string; patch?: string }
interface Compare { merge_base_commit?: { sha: string }; files?: ChangedFile[]; truncated?: boolean; total_files?: number; commits?: unknown[] }
interface Snapshot { pull: Pull; headTreeSha: string; ancestorSha: string; headFiles: ChangedFile[]; baseFiles: ChangedFile[]; hunks: ConflictHunk[]; candidateResults: Map<string, MergeRegion<string>[]>; protectedPaths: string[]; baseOnly: ChangedFile[]; candidatePaths: string[] }
interface ContentFile { content?: string; encoding?: string; size?: number; truncated?: boolean; sha?: string }
interface MergeBuild { treeEntries: MergeTreeEntry[]; changedPaths: string[]; diff: string; hunks: ConflictHunk[]; protectedPaths: string[]; pull: Pull; baseTreeSha: string }

function root(input: ResolveConflictInput): string {
  if (!/^[\w.-]+$/.test(input.owner) || !/^[\w.-]+$/.test(input.repo)) throw new Error("Invalid GitHub repository.");
  return `/repos/${encodeURIComponent(input.owner)}/${encodeURIComponent(input.repo)}`;
}
async function getToken(): Promise<string> {
  const token = (await loadSettings()).githubPat.trim();
  if (!token) throw new Error("Add a GitHub token with Contents read/write and Pull requests write access in Athena Settings.");
  return token;
}
async function getJson<T>(token: string, path: string): Promise<T> {
  let response: Response;
  try { response = await fetch(`${API}${path}`, { headers: { Accept: "application/vnd.github+json", Authorization: `Bearer ${token}`, "X-GitHub-Api-Version": "2022-11-28" } }); }
  catch { throw new Error("Network failure while reading the pull request conflict data."); }
  if (!response.ok) {
    if ((response.status === 403 || response.status === 429) && response.headers.get("X-RateLimit-Remaining") === "0") throw new Error("GitHub rate limit reached. Try again later.");
    if (response.status === 403) throw new Error("GitHub denied access. Check Contents read access and try again.");
    if (response.status === 404) throw new Error("GitHub could not find this PR, commit, or file. Refresh and try again.");
    if (response.status === 409) throw new Error("GitHub reported that the PR changed during conflict resolution. Refresh and try again.");
    throw new Error(`GitHub request failed (HTTP ${response.status}).`);
  }
  try { return await response.json() as T; } catch { throw new Error("GitHub returned an unreadable compare response."); }
}
async function getContents(token: string, apiRoot: string, path: string, sha: string, allowMissing = false): Promise<{ content: string; size: number } | null> {
  const safe = path.split("/").map(segment => {
    if (!segment || segment === "." || segment === ".." || segment.includes("\\")) throw new Error("GitHub returned an unsupported path.");
    return encodeURIComponent(segment);
  }).join("/");
  let response: Response;
  try { response = await fetch(`${API}${apiRoot}/contents/${safe}?ref=${encodeURIComponent(sha)}`, { headers: { Accept: "application/vnd.github+json", Authorization: `Bearer ${token}`, "X-GitHub-Api-Version": "2022-11-28" } }); }
  catch { throw new Error("Network failure while fetching a conflict file."); }
  if (response.status === 404 && allowMissing) return null;
  if (!response.ok) {
    if ((response.status === 403 || response.status === 429) && response.headers.get("X-RateLimit-Remaining") === "0") throw new Error("GitHub rate limit reached. Try again later.");
    if (response.status === 403) throw new Error("GitHub denied Contents read access. Check the saved GitHub token.");
    if (response.status === 404) return null;
    if (response.status === 409) throw new Error("GitHub reported a conflict while reading the PR head. Refresh and try again.");
    throw new Error(`GitHub request failed (HTTP ${response.status}).`);
  }
  const data = await response.json() as ContentFile;
  if (data.encoding !== "base64" || !data.content || data.truncated) throw new Error("This file is binary or GitHub could not provide a complete text file.");
  const binary = atob(data.content.replace(/\s/g, ""));
  const bytes = Uint8Array.from(binary, c => c.charCodeAt(0));
  return { content: new TextDecoder("utf-8", { fatal: true }).decode(bytes), size: data.size ?? bytes.byteLength };
}
function isTruncated(compare: Compare): boolean { return compare.truncated === true || (compare.files?.length ?? 0) >= 300 || (compare.total_files !== undefined && compare.total_files > (compare.files?.length ?? 0)); }
function tooComplex(input: ResolveConflictInput, reason: string): Error {
  const head = `pr-${input.pullNumber}`;
  return new Error(`This conflict set is too complex to resolve automatically (${reason}). Use the git commands below:\n\ngit fetch origin\ngit checkout <${head}-head-branch>\ngit merge origin/<base-branch>\n# resolve each conflict, then commit and push your PR branch.`);
}
function protectedPath(path: string): boolean {
  return /^\.github\/workflows\//i.test(path) || /(^|\/)(package-lock\.json|npm-shrinkwrap\.json|pnpm-lock\.yaml|yarn\.lock|bun\.lockb?|Cargo\.lock|Gemfile\.lock|Pipfile\.lock|poetry\.lock|uv\.lock|composer\.lock|go\.sum)$/i.test(path);
}
function lines(text: string): string[] {
  const result = text.replace(/\r\n/g, "\n").split("\n");
  if (text.endsWith("\n")) result.pop();
  return result;
}
function lineEnding(...texts: string[]): string { return texts.some(text => text.endsWith("\n")) ? "\n" : ""; }
function hasConflictMarkers(text: string): boolean { return /^(?:<<<<<<<|=======|>>>>>>>)(?:\s|$)/m.test(text); }
function mergeForFile(mine: string, ancestor: string, theirs: string): MergeRegion<string>[] {
  const result = diff3Merge(lines(mine), lines(ancestor), lines(theirs), { excludeFalseConflicts: true });
  return result as MergeRegion<string>[];
}
function collectHunks(path: string, mine: string, regions: MergeRegion<string>[]): ConflictHunk[] {
  let number = 0;
  let mineCursor = 0;
  const mineLines = lines(mine);
  return regions.flatMap(region => {
    if (!region.conflict) { mineCursor += region.ok?.length ?? 0; return []; }
    number++;
    const snippet = region.conflict.a;
    let at = -1;
    for (let i = mineCursor; i <= mineLines.length - snippet.length; i++) {
      if (snippet.every((line, offset) => mineLines[i + offset] === line)) { at = i; break; }
    }
    if (at < 0) at = Math.min(mineCursor, mineLines.length);
    const context = mineLines.slice(Math.max(0, at - 10), Math.min(mineLines.length, at + snippet.length + 10));
    mineCursor = at + snippet.length;
    return [{ id: `${path}::${number}`, path, mine: region.conflict.a, theirs: region.conflict.b, ancestor: region.conflict.o, context }];
  });
}
function resolutionLines(hunk: ConflictHunk, resolution: HunkResolution): string[] {
  if (resolution.choice === "mine") return hunk.mine;
  if (resolution.choice === "theirs") return hunk.theirs;
  if (resolution.choice === "both") return [...hunk.mine, ...hunk.theirs];
  if (resolution.choice === "edit") return (resolution.text ?? "").replace(/\r\n/g, "\n").split("\n");
  throw new Error("Choose a resolution for every conflict hunk.");
}
function finishRegions(regions: MergeRegion<string>[], path: string, resolutions: Record<string, HunkResolution>, startId = 1): string {
  let hunkNo = 0;
  const output: string[] = [];
  for (const region of regions) {
    if (region.conflict) {
      hunkNo++;
      const hunk: ConflictHunk = { id: `${path}::${hunkNo + startId - 1}`, path, mine: region.conflict.a, theirs: region.conflict.b, ancestor: region.conflict.o, context: [] };
      const resolution = resolutions[hunk.id];
      if (!resolution) throw new Error("Resolve every conflict hunk before creating a PR.");
      output.push(...resolutionLines(hunk, resolution));
    } else if (region.ok) output.push(...region.ok);
  }
  return output.join("\n");
}
function unifiedDiff(path: string, before: string, after: string): string {
  const a = lines(before), b = lines(after);
  let prefix = 0; while (prefix < a.length && prefix < b.length && a[prefix] === b[prefix]) prefix++;
  let suffix = 0; while (suffix < a.length - prefix && suffix < b.length - prefix && a[a.length - suffix - 1] === b[b.length - suffix - 1]) suffix++;
  const start = Math.max(0, prefix - 3), endA = Math.min(a.length, a.length - suffix + 3), endB = Math.min(b.length, b.length - suffix + 3);
  if (prefix === a.length && prefix === b.length) return "";
  const body = [...a.slice(start, prefix).map(line=>` ${line}`), ...a.slice(prefix, a.length-suffix).map(line=>`-${line}`), ...b.slice(prefix, b.length-suffix).map(line=>`+${line}`), ...a.slice(a.length-suffix, endA).map(line=>` ${line}`)];
  const oldCount = endA - start, newCount = endB - start;
  return `diff --git a/${path} b/${path}\n--- a/${path}\n+++ b/${path}\n@@ -${start+1},${oldCount} +${start+1},${newCount} @@\n${body.join("\n")}`;
}
function blobTreeEntry(path: string, sha: string): MergeTreeEntry { return { path, mode: "100644", type: "blob", sha }; }
function deletionTreeEntry(path: string): MergeTreeEntry { return { path, mode: "100644", type: "blob", sha: null }; }

async function buildSnapshot(input: ResolveConflictInput): Promise<Snapshot> {
  const token = await getToken();
  const apiRoot = root(input);
  const pull = await getJson<Pull>(token, `${apiRoot}/pulls/${input.pullNumber}`);
  if (!pull.head.repo || pull.head.repo.full_name.toLowerCase() !== `${input.owner}/${input.repo}`.toLowerCase()) throw new Error("I can't push to forks");
  const first = await getJson<Compare>(token, `${apiRoot}/compare/${encodeURIComponent(pull.base.sha)}...${encodeURIComponent(pull.head.sha)}`);
  if (isTruncated(first)) throw tooComplex(input, "GitHub truncated a compare response");
  const ancestorSha = first.merge_base_commit?.sha;
  if (!ancestorSha) throw tooComplex(input, "GitHub did not return a merge base");
  const [headCompare, baseCompare, headCommit] = await Promise.all([
    getJson<Compare>(token, `${apiRoot}/compare/${encodeURIComponent(ancestorSha)}...${encodeURIComponent(pull.head.sha)}`),
    getJson<Compare>(token, `${apiRoot}/compare/${encodeURIComponent(ancestorSha)}...${encodeURIComponent(pull.base.sha)}`),
    getJson<{ tree: { sha: string } }>(token, `${apiRoot}/git/commits/${encodeURIComponent(pull.head.sha)}`),
  ]);
  if (isTruncated(headCompare) || isTruncated(baseCompare)) throw tooComplex(input, "GitHub truncated a compare response");
  const headFiles = headCompare.files ?? [], baseFiles = baseCompare.files ?? [];
  const headByPath = new Map(headFiles.map(file=>[file.filename, file]));
  const baseByPath = new Map(baseFiles.map(file=>[file.filename, file]));
  const candidatePaths = [...headByPath.keys()].filter(path=>baseByPath.has(path));
  if (candidatePaths.length > 10) throw tooComplex(input, "more than 10 files changed on both branches");
  const candidateResults = new Map<string, MergeRegion<string>[]>();
  const hunks: ConflictHunk[] = [];
  const protectedPaths = new Set<string>();
  for (const path of candidatePaths) {
    const h = headByPath.get(path)!;
    const b = baseByPath.get(path)!;
    if (!h.patch || !b.patch || h.status === "renamed" || b.status === "renamed" || h.status === "removed" || b.status === "removed") throw tooComplex(input, `${path} is binary, renamed, or deleted on one side`);
    let ancestor: { content: string; size: number } | null, mine: { content: string; size: number } | null, theirs: { content: string; size: number } | null;
    try {
      [ancestor, mine, theirs] = await Promise.all([
        getContents(token, apiRoot, path, ancestorSha, true),
        getContents(token, apiRoot, path, pull.head.sha),
        getContents(token, apiRoot, path, pull.base.sha),
      ]);
    } catch (error) {
      if (error instanceof Error && /binary|complete text file/i.test(error.message)) throw tooComplex(input, `${path} is binary`);
      throw error;
    }
    if (!mine || !theirs) throw tooComplex(input, `${path} is missing on one side`);
    if ([ancestor?.size ?? 0, mine.size, theirs.size].some(size=>size > 100 * 1024)) throw tooComplex(input, `${path} is over 100 KB`);
    const regions = mergeForFile(mine.content, ancestor?.content ?? "", theirs.content);
    candidateResults.set(path, regions);
    hunks.push(...collectHunks(path, mine.content, regions));
    if (protectedPath(path)) protectedPaths.add(path);
  }
  const headPaths = new Set(headFiles.map(file=>file.filename));
  const baseOnly = baseFiles.filter(file=>!headPaths.has(file.filename));
  for (const file of baseOnly) {
    if (protectedPath(file.filename)) protectedPaths.add(file.filename);
    if (file.previous_filename && protectedPath(file.previous_filename)) protectedPaths.add(file.previous_filename);
  }
  return { pull, headTreeSha: headCommit.tree.sha, ancestorSha, headFiles, baseFiles, hunks, candidateResults, protectedPaths: [...protectedPaths], baseOnly, candidatePaths };
}

async function buildResolvedMerge(input: ResolveConflictInput, resolutions: Record<string, HunkResolution>): Promise<MergeBuild> {
  const snapshot = await buildSnapshot(input);
  const token = await getToken(), apiRoot = root(input);
  const treeEntries: MergeTreeEntry[] = [];
  const diffs: string[] = [];
  const changedPaths = new Set<string>();
  for (const path of snapshot.candidatePaths) {
    const regions = snapshot.candidateResults.get(path)!;
    const finalText = finishRegions(regions, path, resolutions);
    if (hasConflictMarkers(finalText)) throw new Error(`The result for ${path} still contains conflict markers. Edit the resolution and try again.`);
    const head = await getContents(token, apiRoot, path, snapshot.pull.head.sha);
    if (!head) throw tooComplex(input, `${path} is missing from the PR head`);
    const merged = finalText + lineEnding(head.content);
    if (merged !== head.content) {
      treeEntries.push({ path, mode: "100644", type: "blob", content: merged });
      changedPaths.add(path);
      diffs.push(unifiedDiff(path, head.content, merged));
    }
  }
  // Bring over every change made only on the PR base branch.
  for (const file of snapshot.baseOnly) {
    if (file.status === "renamed" && file.previous_filename) {
      treeEntries.push(deletionTreeEntry(file.previous_filename));
      changedPaths.add(file.previous_filename);
    }
    if (file.status === "removed") {
      treeEntries.push(deletionTreeEntry(file.filename));
      changedPaths.add(file.filename);
      const headContent = await getContents(token, apiRoot, file.filename, snapshot.pull.head.sha, true);
      if (headContent) diffs.push(unifiedDiff(file.filename, headContent.content, ""));
      continue;
    }
    if (file.sha) treeEntries.push(blobTreeEntry(file.filename, file.sha));
    changedPaths.add(file.filename);
    if (file.patch) {
      const [headContent, baseContent] = await Promise.all([
        getContents(token, apiRoot, file.previous_filename ?? file.filename, snapshot.pull.head.sha, true),
        getContents(token, apiRoot, file.filename, snapshot.pull.base.sha, true),
      ]);
      if (headContent && baseContent) diffs.push(unifiedDiff(file.previous_filename ?? file.filename, headContent.content, baseContent.content));
      else if (baseContent) diffs.push(unifiedDiff(file.filename, "", baseContent.content));
      else diffs.push(`diff --git a/${file.filename} b/${file.filename}\nBinary file updated from ${snapshot.pull.base.ref}\n`);
    } else {
      diffs.push(`diff --git a/${file.filename} b/${file.filename}\nBinary file updated from ${snapshot.pull.base.ref}\n`);
    }
  }
  const hunks = snapshot.hunks;
  for (const hunk of hunks) if (!resolutions[hunk.id]) throw new Error("Resolve every conflict hunk before creating a PR.");
  if (!treeEntries.length) throw new Error("The merge result is already identical to the PR head.");
  return { treeEntries, changedPaths: [...changedPaths], diff: diffs.filter(Boolean).join("\n"), hunks, protectedPaths: snapshot.protectedPaths, pull: snapshot.pull, baseTreeSha: snapshot.headTreeSha };
}

export async function gatherConflictResolution(input: ResolveConflictInput): Promise<{ request: ResolveConflictInput; headRef: string; baseRef: string; hunks: ConflictHunk[]; protectedPaths: string[]; blocked?: string }> {
  try {
    const snapshot = await buildSnapshot(input);
    return { request: input, headRef: snapshot.pull.head.ref, baseRef: snapshot.pull.base.ref, hunks: snapshot.hunks, protectedPaths: snapshot.protectedPaths };
  } catch (error) {
    if (error instanceof Error && error.message.startsWith("This conflict set is too complex")) return { request: input, headRef: "", baseRef: "", hunks: [], protectedPaths: [], blocked: error.message };
    throw error;
  }
}

export async function previewConflictResolution(input: ResolveConflictInput, resolutions: Record<string, HunkResolution>, confirmedOnce: boolean): Promise<{ diff?: string; summary?: string; changedPaths?: string[]; protectedPaths?: string[]; confirmPaths?: string[] }> {
  const built = await buildResolvedMerge(input, resolutions);
  if (built.protectedPaths.length && !confirmedOnce) return { confirmPaths: built.protectedPaths };
  return { diff: built.diff, summary: `Merge ${built.pull.base.ref} into ${built.pull.head.ref}; resolved files: ${built.changedPaths.join(", ")}.`, changedPaths: built.changedPaths, protectedPaths: built.protectedPaths };
}

export async function createConflictResolutionPr(input: ResolveConflictInput, resolutions: Record<string, HunkResolution>, confirmedOnce: boolean, confirmedTwice: boolean): Promise<{ number: number; url: string }> {
  const built = await buildResolvedMerge(input, resolutions);
  if (built.protectedPaths.length && (!confirmedOnce || !confirmedTwice)) throw new Error("Confirm the workflow or lockfile changes twice before creating the PR.");
  const created = await createResolvedMergePullRequest({
    ...input,
    expectedHeadSha: built.pull.head.sha,
    headBranch: built.pull.head.ref,
    baseBranch: built.pull.base.ref,
    baseSha: built.pull.base.sha,
    baseTreeSha: built.baseTreeSha,
    treeEntries: built.treeEntries,
    title: `[Athena] Resolve conflicts with ${built.pull.base.ref}`,
    summary: `Resolved files: ${built.changedPaths.join(", ")}. Athena-generated merge resolution.`,
    changedPaths: built.changedPaths,
  });
  return created;
}
