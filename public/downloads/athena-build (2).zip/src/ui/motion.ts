export const ATHENA_WARNING_SHOWN_EVENT = "athena-warning-shown";
const EXIT_DURATION_MS = 180;

export function announceAthenaWarning(): void {
  document.dispatchEvent(new Event(ATHENA_WARNING_SHOWN_EVENT));
}

export function fadeOutAthenaElement(element: HTMLElement, onComplete?: () => void): void {
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    onComplete?.();
    return;
  }
  element.classList.add("athena-exiting");
  window.setTimeout(() => onComplete?.(), EXIT_DURATION_MS);
}

export function fadeOutAthenaHost(host: HTMLElement, onComplete?: () => void): void {
  const content = host.shadowRoot?.querySelector<HTMLElement>(
    ".athena-banner, .radar-card, .wf-card, .chk-card, .warn-banner, .secret-banner"
  );
  if (!content) {
    host.remove();
    onComplete?.();
    return;
  }
  fadeOutAthenaElement(content, () => {
    host.remove();
    onComplete?.();
  });
}
