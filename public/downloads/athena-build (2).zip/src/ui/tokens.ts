import tokenStyles from "./tokens.css?inline";

export const primerTokenStyles = tokenStyles;