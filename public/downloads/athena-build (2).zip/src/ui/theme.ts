const ATHENA_HOST_SELECTOR = "[data-athena-theme-host]";
let themeObserver: MutationObserver | null = null;

export function getTheme(): "light" | "dark" {
  const colorMode = document.documentElement.getAttribute("data-color-mode");
  if (colorMode === "light" || colorMode === "dark") return colorMode;
  return window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
}

function updateTheme(host: Element): void {
  host.setAttribute("data-theme", getTheme());
}

function updateHosts(root: ParentNode = document): void {
  root.querySelectorAll(ATHENA_HOST_SELECTOR).forEach(updateTheme);
}

export function observeAthenaTheme(): void {
  if (themeObserver || typeof document === "undefined") return;

  updateHosts();
  const colorScheme = window.matchMedia("(prefers-color-scheme: light)");
  colorScheme.addEventListener("change", () => {
    if (document.documentElement.getAttribute("data-color-mode") === "auto" ||
        !["light", "dark"].includes(document.documentElement.getAttribute("data-color-mode") ?? "")) {
      updateHosts();
    }
  });
  themeObserver = new MutationObserver((records) => {
    for (const record of records) {
      if (record.type === "attributes") {
        updateHosts();
        continue;
      }
      record.addedNodes.forEach((node) => {
        if (!(node instanceof Element)) return;
        if (node.matches(ATHENA_HOST_SELECTOR)) updateTheme(node);
        updateHosts(node);
      });
    }
  });
  themeObserver.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ["data-color-mode"],
    childList: true,
    subtree: true,
  });
}