export type OcticonName =
  | "shield"
  | "alert"
  | "warning"
  | "info"
  | "cancel"
  | "arrow"
  | "lock"
  | "merge"
  | "branch"
  | "gear"
  | "key"
  | "search"
  | "check"
  | "copy";

const ICON_PATHS: Record<OcticonName, string[]> = {
  shield: ["M12 2.5 20 5v5.8c0 5.2-3.4 8.8-8 10.7-4.6-1.9-8-5.5-8-10.7V5z"],
  alert: ["M12 3 22 20H2L12 3z", "M12 9v4", "M12 16h.01"],
  warning: ["M12 3 22 20H2L12 3z", "M12 9v4", "M12 16h.01"],
  info: ["M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z", "M12 11v5", "M12 8h.01"],
  cancel: ["M5 5l14 14M19 5 5 19", "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z"],
  arrow: ["M4 12h15", "m13 5 7 7-7 7"],
  lock: ["M5 10h14v11H5z", "M8 10V7a4 4 0 0 1 8 0v3", "M12 14v3"],
  merge: ["M6 3v12a3 3 0 0 0 3 3h9", "m14 14 4 4-4 4", "M6 3h.01", "M6 3a2 2 0 1 0 0 .01"],
  branch: ["M6 3v12a3 3 0 0 0 3 3h9", "m14 14 4 4-4 4", "M6 3h.01"],
  gear: ["M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z", "M12 2v2m0 16v2M2 12h2m16 0h2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42m0-14.14-1.42 1.42m-11.3 11.3-1.42 1.42"],
  key: ["M14 8a5 5 0 1 1-2-4", "m11 8 10 10", "m17 14 3-3", "m19 16 3-3"],
  search: ["M10.5 3a7.5 7.5 0 1 0 0 15 7.5 7.5 0 0 0 0-15z", "m16 16 5 5"],
  check: ["m5 12 4 4L19 6"],
  copy: ["M8 8h12v13H8z", "M16 8V3H4v13h4"],
};

export function createOcticon(name: OcticonName, size = 16): SVGSVGElement {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("width", String(size));
  svg.setAttribute("height", String(size));
  svg.setAttribute("fill", "none");
  svg.setAttribute("stroke", "currentColor");
  svg.setAttribute("stroke-width", "1.8");
  svg.setAttribute("stroke-linecap", "round");
  svg.setAttribute("stroke-linejoin", "round");
  svg.setAttribute("aria-hidden", "true");
  svg.setAttribute("focusable", "false");
  for (const d of ICON_PATHS[name]) {
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", d);
    svg.appendChild(path);
  }
  return svg;
}
