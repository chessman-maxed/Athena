import { useEffect, useState, useCallback } from "react";
import "./App.css";
import {
  STORAGE_KEYS,
  loadSettings,
  saveSettings,
  maskCredential,
  normalizeBaseUrl,
  hasLLMConsent,
  setLLMConsent,
  type AthenaActivityEntry,
  type LLMSettings,
  type RuleId,
  type RuleToggles,
} from "./storage/session";

// ── Helpers ───────────────────────────────────────────────────────────────────

const SEVERITY_MAP: Record<string, "critical" | "danger" | "warning" | "low"> = {
  "delete-repository":  "critical",
  "transfer-ownership": "critical",
  "archive-repository": "danger",
  "delete-branch":      "danger",
  "close-pull-request": "danger",
  "conflict-radar":     "warning",
  "workflow-radar":     "warning",
  "pre-merge-checklist": "warning",
  "fix-it": "low",
};

function severityBadge(ruleId: string) {
  const normalizedRuleId = ruleId.replace(/^(passive_|secret_)/, "");
  const sev = ruleId.startsWith("secret_") ? "critical" : SEVERITY_MAP[ruleId] || SEVERITY_MAP[normalizedRuleId] || "warning";
  if (sev === "low") {
    return { bg: "severity-low", dot: "severity-low-dot", label: "LOW" };
  }
  if (sev === "critical") {
    return {
      bg: "severity-critical",
      dot: "severity-critical-dot",
      label: "CRITICAL",
    };
  }
  if (sev === "danger") {
    return {
      bg: "severity-danger",
      dot: "severity-danger-dot",
      label: "HIGH",
    };
  }
  return {
    bg: "severity-warning",
    dot: "severity-warning-dot",
    label: "MEDIUM",
  };
}

function decisionLabel(type: AthenaActivityEntry["type"]): string {
  if (type === "cancelled" || type === "secret-blocked") return "INTERCEPTED";
  if (type === "proceeded") return "USER PROCEEDED";
  if (type === "warning-shown" || type === "merge-warned") return "WARNING SHOWN";
  return "ATHENA ACTION";
}

function formatTime(ts: number) {
  return new Intl.DateTimeFormat(undefined, { hour: "2-digit", minute: "2-digit" }).format(ts);
}

function activityAction(entry: AthenaActivityEntry): string {
  const rule = entry.ruleId.replace(/^(passive_|secret_)/, "");
  if (entry.type === "secret-blocked") return "SECRET DETECTED";
  if (rule === "conflict-radar") return "BRANCH DRIFT";
  if (rule === "workflow-radar") return "WORKFLOW RISK";
  if (rule === "pre-merge-checklist") return "SECURITY CHECK";
  if (rule === "delete-repository") return "DELETE REPOSITORY";
  if (rule === "archive-repository") return "ARCHIVE REPOSITORY";
  if (rule === "delete-branch") return "DELETE BRANCH";
  if (rule === "transfer-ownership") return "TRANSFER OWNERSHIP";
  if (rule === "close-pull-request") return "CLOSE PULL REQUEST";
  return entry.label;
}

type IconName = "shield" | "check" | "warning" | "cancel" | "arrow" | "lock" | "merge" | "chart" | "gear" | "key" | "eye" | "eye-closed";

const ICON_PATHS: Record<IconName, string> = {
  shield: "M8 1.5 13.5 3.5v4c0 3.4-2.2 5.8-5.5 7-3.3-1.2-5.5-3.6-5.5-7v-4z",
  check: "m3 8 3.2 3.2L13 4.5",
  warning: "M8 1.75 14.5 13H1.5z M8 5.2v3.6 M8 11.1v.2",
  cancel: "M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13z M5.5 5.5l5 5 M10.5 5.5l-5 5",
  arrow: "M2 8h11 M8.5 3.5 13 8l-4.5 4.5",
  lock: "M3 7h10v7H3z M5 7V5a3 3 0 0 1 6 0v2 M8 9.5v2",
  merge: "M4 3v7a3 3 0 0 0 3 3h5 M10 10l3 3-3 3 M4 3a1.5 1.5 0 1 0 0 .1 M4 3a1.5 1.5 0 1 0 0 .1",
  chart: "M2 13.5h12 M3.5 11V7.5 M7 11V3.5 M10.5 11V5.5 M14 11V2",
  gear: "M8 1.8v1.4 M8 12.8v1.4 M1.8 8h1.4 M12.8 8h1.4 M3.6 3.6l1 1 M11.4 11.4l1 1 M12.4 3.6l-1 1 M4.6 11.4l-1 1 M8 5a3 3 0 1 0 0 6 3 3 0 0 0 0-6z",
  key: "M9 5a3.5 3.5 0 1 0-1 2.5L14 13v-2h-2V9h-2L8 7",
  eye: "M1.5 8s2.3-4.5 6.5-4.5S14.5 8 14.5 8s-2.3 4.5-6.5 4.5S1.5 8 1.5 8z M8 6a2 2 0 1 0 0 4 2 2 0 0 0 0-4z",
  "eye-closed": "M2 2l12 12 M6.2 4a7 7 0 0 1 1.8-.5c4.2 0 6.5 4.5 6.5 4.5a12 12 0 0 1-2 2.5 M4.2 4.8C2.5 6 1.5 8 1.5 8s2.3 4.5 6.5 4.5a7 7 0 0 0 2-.3 M6.5 6.5a2 2 0 0 0 3 3",
};

function Icon({ name, className = "" }: { name: IconName; className?: string }) {
  return (
    <svg className={className} aria-hidden="true" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d={ICON_PATHS[name]} />
    </svg>
  );
}

const ACTIVITY_ICONS: Record<AthenaActivityEntry["type"], IconName> = {
  "warning-shown": "warning",
  cancelled: "cancel",
  proceeded: "arrow",
  "secret-blocked": "lock",
  "merge-warned": "merge",
  "fix-action": "merge",
};

// ── Async storage helpers (popup only) ───────────────────────────────────────

function storageGet<T>(key: string): Promise<T | undefined> {
  return new Promise((resolve) =>
    chrome.storage.session.get(key, (r) => resolve(r[key] as T))
  );
}
function storageSet(data: Record<string, unknown>): Promise<void> {
  return new Promise((resolve) => chrome.storage.session.set(data, resolve));
}

// ── Rule metadata (for display in Settings) ───────────────────────────────────

interface RuleMeta {
  id: RuleId;
  label: string;
  category: "Repository protection" | "Pull request protection" | "Workflow protection" | "Secret detection";
  desc: string;
}

const RULE_META: RuleMeta[] = [
  // Passive guards
  { id: "passive_delete-repository",   label: "Delete Repository",          category: "Repository protection", desc: "Warn before deleting a repository" },
  { id: "passive_archive-repository",  label: "Archive Repository",         category: "Repository protection", desc: "Warn before archiving a repository" },
  { id: "passive_transfer-ownership",  label: "Transfer Ownership",         category: "Repository protection", desc: "Review ownership transfers" },
  { id: "passive_delete-branch",       label: "Delete Branch",              category: "Repository protection", desc: "Confirm branch deletions" },
  { id: "passive_close-pull-request",  label: "Close / Abandon PR",         category: "Pull request protection", desc: "Warn before closing a pull request" },
  { id: "passive_conflict-radar",      label: "PR Conflict Radar",          category: "Pull request protection", desc: "Detect branch drift and merge conflicts" },
  { id: "passive_pre-merge-checklist", label: "Pre-Merge Checklist & Guard", category: "Pull request protection", desc: "Review safety checks before merge" },
  { id: "passive_workflow-radar",      label: "PR Workflow & Deploy Radar", category: "Workflow protection", desc: "Monitor workflow and deployment changes" },
  // Secret scanner
  { id: "secret_aws-access-key",          label: "AWS Access Key",              category: "Secret detection", desc: "Detect AWS access key IDs" },
  { id: "secret_github-pat",              label: "GitHub PAT",                  category: "Secret detection", desc: "Detect classic and OAuth tokens" },
  { id: "secret_github-fine-grained-pat", label: "GitHub Fine-Grained PAT",     category: "Secret detection", desc: "Detect fine-grained access tokens" },
  { id: "secret_pem-private-key",         label: "PEM Private Key",             category: "Secret detection", desc: "Detect private key blocks" },
  { id: "secret_slack-token",             label: "Slack Token",                 category: "Secret detection", desc: "Detect Slack access tokens" },
  { id: "secret_google-api-key",          label: "Google API Key",              category: "Secret detection", desc: "Detect Google API credentials" },
  { id: "secret_openai-key",              label: "OpenAI API Key",              category: "Secret detection", desc: "Detect OpenAI API credentials" },
  { id: "secret_stripe-key",              label: "Stripe Key",                  category: "Secret detection", desc: "Detect Stripe secret and publishable keys" },
  { id: "secret_high-entropy",            label: "High-Entropy String",         category: "Secret detection", desc: "Detect suspicious high-entropy strings" },
];

// ── Activity Log Tab ──────────────────────────────────────────────────────────

function LogTab() {
  const [log, setLog] = useState<AthenaActivityEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const onChanged = (changes: Record<string, chrome.storage.StorageChange>, areaName: string) => {
      if (areaName === "session" && changes[STORAGE_KEYS.ACTIVITY_LOG]) {
        const next = changes[STORAGE_KEYS.ACTIVITY_LOG].newValue as AthenaActivityEntry[] | undefined;
        setLog(next ?? []);
        setLoading(false);
      }
    };
    chrome.storage.onChanged.addListener(onChanged);
    storageGet<AthenaActivityEntry[]>(STORAGE_KEYS.ACTIVITY_LOG).then((v) => {
      setLog(v ?? []);
      setLoading(false);
    });
    return () => chrome.storage.onChanged.removeListener(onChanged);
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16 text-xs text-neutral-500 animate-pulse">
        <span>Loading session activity…</span>
      </div>
    );
  }

  const newestFirst = [...log].sort((a, b) => b.timestamp - a.timestamp);
  const activityHeader = (
    <header className="activity-heading">
      <div className="activity-heading-copy">
        <h2 className="activity-count">ACTIVITY</h2>
        <span>REAL-TIME SECURITY EVENTS</span>
      </div>
      <span className="activity-event-count">{log.length.toString().padStart(2, "0")} EVENTS</span>
    </header>
  );

  if (log.length === 0) {
    return (
      <div>
        {activityHeader}
        <div className="activity-empty animate-fade-in">
          <div className="empty-shield">
            <Icon name="shield" className="empty-shield-outline" />
            <Icon name="check" className="empty-shield-check" />
          </div>
          <div className="empty-copy">
            <h2>No dangerous actions confirmed yet.</h2>
            <p>Athena is actively watching.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      {activityHeader}
      <ul className="activity-list animate-fade-in">
      {newestFirst.map((entry) => {
        const badge = severityBadge(entry.ruleId);
        return (
          <li
            key={`${entry.timestamp}-${entry.type}-${entry.ruleId}-${entry.label}`}
            className={`activity-row${badge.label === "CRITICAL" ? " activity-row-critical" : ""}`}
          >
            <div className="activity-row-top">
              <span className={`activity-severity ${badge.bg}`}>
                <span className={`severity-dot ${badge.dot}`} />{badge.label}
              </span>
              <span className="activity-time">{formatTime(entry.timestamp)}</span>
            </div>
            <div className="activity-action"><Icon name={ACTIVITY_ICONS[entry.type]} className="activity-icon" />{activityAction(entry)}</div>
            <p className="activity-repo">{entry.repo || "GitHub"}</p>
            <span className={`activity-decision decision-${entry.type}`}>{decisionLabel(entry.type)}</span>
          </li>
        );
      })}
      </ul>
    </div>
  );
}

// ── Settings Tab ──────────────────────────────────────────────────────────────

function SettingsTab() {
  // LLM settings
  const [llm, setLlm] = useState<LLMSettings>({ baseUrl: "", apiKey: "", model: "gpt-4o-mini" });
  const [llmStatus, setLlmStatus] = useState<{
    type: "idle" | "granted" | "denied" | "invalid" | "saved";
    message: string;
  }>({ type: "idle", message: "" });
  const [apiKeyDraft, setApiKeyDraft] = useState("");
  const [hasApiKey, setHasApiKey] = useState(false);
  const [maskedApiKey, setMaskedApiKey] = useState("");
  const [editingApiKey, setEditingApiKey] = useState(false);
  const [llmEnabled, setLlmEnabled] = useState(false);

  // GitHub PAT
  const [pat, setPat]           = useState("");
  const [hasPat, setHasPat] = useState(false);
  const [maskedPat, setMaskedPat] = useState("");
  const [editingPat, setEditingPat] = useState(false);
  const [patSaved, setPatSaved] = useState(false);

  // Rule toggles
  const [toggles, setToggles]       = useState<RuleToggles>({});
  const [togglesSaved, setTogglesSaved] = useState(false);

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      loadSettings(),
      storageGet<RuleToggles>(STORAGE_KEYS.TOGGLES),
      hasLLMConsent(),
    ]).then(([settings, togs, enabled]) => {
      setLlm({ baseUrl: settings.baseUrl, apiKey: "", model: settings.model });
      setHasApiKey(!!settings.apiKey);
      setHasPat(!!settings.githubPat);
      setEditingApiKey(!settings.apiKey);
      setEditingPat(!settings.githubPat);
      setMaskedApiKey(maskCredential(settings.apiKey));
      setMaskedPat(maskCredential(settings.githubPat));
      setPat("");
      setToggles(togs ?? {});
      setLlmEnabled(enabled);
      setLoading(false);
    });
  }, []);

  const saveLlm = async () => {
    const normalizedUrl = normalizeBaseUrl(llm.baseUrl);
    const rawBase = normalizedUrl || "https://api.openai.com/v1";
    let origin = "";
    try {
      const url = new URL(rawBase);
      const isLocal =
        url.hostname === "localhost" ||
        url.hostname === "127.0.0.1" ||
        url.hostname === "::1";
      if (!isLocal && url.protocol !== "https:") {
        setLlmStatus({
          type: "invalid",
          message: "Base URL must use HTTPS (or HTTP for localhost).",
        });
        return;
      }
      origin = url.origin;
    } catch {
      setLlmStatus({
        type: "invalid",
        message: "Invalid URL format. Example: https://api.openai.com/v1",
      });
      return;
    }

    await saveSettings({
      baseUrl: normalizedUrl,
      ...(apiKeyDraft.trim() ? { apiKey: apiKeyDraft.trim() } : {}),
      model: llm.model.trim() || "gpt-4o-mini",
    });
    await setLLMConsent(llmEnabled);
    setLlm((s: LLMSettings) => ({ ...s, baseUrl: normalizedUrl, apiKey: "" }));
    if (apiKeyDraft.trim()) { setHasApiKey(true); setMaskedApiKey(maskCredential(apiKeyDraft.trim())); }
    setEditingApiKey(false);
    setApiKeyDraft("");

    // Request optional host permission for this exact origin from user gesture
    if (typeof chrome !== "undefined" && chrome.permissions?.request) {
      try {
        const granted = await new Promise<boolean>((resolve) => {
          chrome.permissions.request(
            { origins: [`${origin}/*`] },
            (g) => resolve(!!g)
          );
        });

        if (granted) {
          setLlmStatus({
            type: "granted",
            message: `✓ Saved & host permission granted for ${origin}`,
          });
        } else {
          setLlmStatus({
            type: "denied",
            message: `Saved, but host permission for ${origin} was denied. Requests to this provider will fail until granted.`,
          });
        }
      } catch {
        setLlmStatus({
          type: "saved",
          message: "Saved locally in this browser.",
        });
      }
    } else {
      setLlmStatus({
        type: "saved",
        message: "Saved locally in this browser.",
      });
    }

    setTimeout(() => {
      setLlmStatus((prev) => (prev.type === "granted" || prev.type === "saved" ? { type: "idle", message: "" } : prev));
    }, 4000);
  };

  const savePat = async () => {
    if (!pat.trim()) return;
    await saveSettings({ githubPat: pat.trim() });
    setHasPat(true);
    setMaskedPat(maskCredential(pat.trim()));
    setEditingPat(false);
    setPat("");
    setPatSaved(true);
    setTimeout(() => setPatSaved(false), 2000);
  };

  const removeApiKey = async () => {
    await saveSettings({ apiKey: undefined });
    setHasApiKey(false);
    setMaskedApiKey("");
    setApiKeyDraft("");
    setEditingApiKey(true);
  };

  const removePat = async () => {
    await saveSettings({ githubPat: undefined });
    setHasPat(false);
    setMaskedPat("");
    setPat("");
    setPatSaved(false);
    setEditingPat(true);
  };

  const toggleRule = useCallback((id: RuleId) => {
    setToggles((prev: RuleToggles) => ({ ...prev, [id]: prev[id] !== false ? false : true }));
  }, []);

  const saveToggles = () => {
    storageSet({ [STORAGE_KEYS.TOGGLES]: toggles }).then(() => {
      setTogglesSaved(true);
      setTimeout(() => setTogglesSaved(false), 2000);
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16 text-xs text-neutral-500 animate-pulse">
        <span>Loading settings…</span>
      </div>
    );
  }

  const ruleCategories: RuleMeta["category"][] = [
    "Repository protection",
    "Pull request protection",
    "Workflow protection",
    "Secret detection",
  ];
  const setLlmEnabledPreference = (enabled: boolean) => {
    setLlmEnabled(enabled);
    void setLLMConsent(enabled);
  };

  const settingsInputClass = "settings-input";
  return (
    <div className="settings-content animate-fade-in">
      <section className="settings-section github-pat-section">
        <div className="settings-section-header">
          <div><span className="settings-kicker">CONNECTION</span><h2>GITHUB PAT</h2></div>
          <span className="settings-tag">OPTIONAL</span>
        </div>
        <p className="settings-description">Optional. Used only for api.github.com requests.</p>
        <p className="settings-security-note"><span aria-hidden="true">●</span> Stored in session memory only. Never sent elsewhere.</p>
        <label className="settings-label" htmlFor="github-pat">PERSONAL ACCESS TOKEN</label>
        <input
          id="github-pat"
          type="password"
          autoComplete="new-password"
          value={editingPat ? pat : maskedPat}
          readOnly={!editingPat}
          onFocus={() => { if (!editingPat) { setPat(""); setEditingPat(true); } }}
          onChange={(e) => setPat(e.target.value)}
          placeholder={hasPat && !editingPat ? "Saved token" : "github_pat_… or ghp_…"}
          className={`${settingsInputClass} settings-mono`}
        />
        <div className="settings-actions">
          <button type="button" onClick={savePat} disabled={!pat.trim()} className="settings-button settings-button-primary">{patSaved ? "✓ PAT SAVED" : "SAVE PAT"}</button>
          <button type="button" onClick={removePat} className="settings-button settings-button-danger">CLEAR</button>
        </div>
      </section>

      <section className="settings-section guardrails-section">
        <div className="settings-section-header">
          <div><span className="settings-kicker">LOCAL POLICY</span><h2>GUARDRAILS</h2></div>
          <span className="settings-tag">SESSION ONLY</span>
        </div>
        <p className="settings-description">Security rules disabled here are skipped for this browser session only.</p>
        {ruleCategories.map((category) => {
          const rules = RULE_META.filter((rule) => rule.category === category);
          return (
            <div className="settings-rule-group" key={category}>
              <h3>{category}</h3>
              <div className="settings-rule-list">
                {rules.map((rule) => {
                  const enabled = toggles[rule.id] !== false;
                  return (
                    <div className="settings-rule" key={rule.id} onClick={() => toggleRule(rule.id)}>
                      <div className="settings-rule-copy">
                        <span className={enabled ? "" : "is-disabled"}>{rule.label}</span>
                        <small>{rule.desc}</small>
                      </div>
                      <button
                        type="button"
                        role="switch"
                        aria-label={`${rule.label} ${enabled ? "enabled" : "disabled"}`}
                        aria-checked={enabled}
                        onClick={(e) => { e.stopPropagation(); toggleRule(rule.id); }}
                        className={`settings-switch${enabled ? " is-on" : ""}`}
                      ><span /></button>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
        <button type="button" onClick={saveToggles} className="settings-button settings-button-primary settings-save-rules">
          {togglesSaved ? "✓ RULES SAVED" : "SAVE GUARDRAILS"}
        </button>
      </section>

      <section className="settings-section llm-section">
        <div className="settings-section-header">
          <div><span className="settings-kicker">ASSISTED ANALYSIS</span><h2>ACTIVE MODE — LLM</h2></div>
          <span className="settings-tag">OPENAI COMPATIBLE</span>
        </div>
        <p className="settings-description">Requires an OpenAI-compatible endpoint. When enabled, selected context may be sent only to the endpoint you configure.</p>
        <label className="settings-label" htmlFor="llm-endpoint">ENDPOINT</label>
        <input id="llm-endpoint" type="url" value={llm.baseUrl} onChange={(e) => setLlm((s: LLMSettings) => ({ ...s, baseUrl: e.target.value }))} placeholder="https://api.openai.com/v1" className={`${settingsInputClass} settings-mono`} />
        <label className="settings-label" htmlFor="llm-model">MODEL</label>
        <input id="llm-model" type="text" value={llm.model} onChange={(e) => setLlm((s: LLMSettings) => ({ ...s, model: e.target.value }))} placeholder="gpt-4o-mini" className={`${settingsInputClass} settings-mono`} />
        <label className="settings-label" htmlFor="llm-api-key">API KEY</label>
        {hasApiKey && !editingApiKey ? (
          <div className="settings-saved-key"><span className="settings-mono">{maskedApiKey}</span><button type="button" onClick={() => { setApiKeyDraft(""); setEditingApiKey(true); }}>CHANGE</button><button type="button" onClick={removeApiKey}>CLEAR</button></div>
        ) : (
          <input id="llm-api-key" type="password" autoComplete="new-password" value={apiKeyDraft} onChange={(e) => setApiKeyDraft(e.target.value)} placeholder="Enter API key" className={`${settingsInputClass} settings-mono`} />
        )}
        <div className="settings-llm-toggle">
          <div><strong>Enable LLM analysis</strong><small>Preference is saved in this browser.</small></div>
          <button type="button" role="switch" aria-label={`LLM analysis ${llmEnabled ? "enabled" : "disabled"}`} aria-checked={llmEnabled} onClick={() => setLlmEnabledPreference(!llmEnabled)} className={`settings-switch${llmEnabled ? " is-on" : ""}`}><span /></button>
        </div>
        <button type="button" onClick={saveLlm} className="settings-button settings-button-primary settings-save-llm">SAVE LLM SETTINGS</button>
        {llmStatus.type !== "idle" && <div className={`settings-status settings-status-${llmStatus.type}`}>{llmStatus.message}</div>}
      </section>
    </div>
  );
}

// ── Root App ──────────────────────────────────────────────────────────────────

type Tab = "log" | "settings";

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("log");

  return (
    <div className="w-[380px] h-[580px] bg-neutral-950 text-neutral-100 font-sans flex flex-col overflow-hidden border border-neutral-800/60 select-none">
      {/* Header */}
      <header className="px-4 py-3 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="popup-shield">
            <img src="/icons/athena-32.png" alt="" className="athena-brand-logo" />
          </div>
          <div className="min-w-0">
            <h1 className="text-xs font-bold tracking-wider text-white uppercase flex items-center gap-1.5">
              Athena
            </h1>
            <p className="text-[10px] text-neutral-400 leading-tight">GitHub safety guardrail</p>
          </div>
        </div>
        <span className="active-indicator">
            <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse-live" />
          ACTIVE
        </span>
      </header>

      {/* Tabs */}
      <div className="flex p-1.5 bg-neutral-950 border-b border-neutral-800/80 gap-1 shrink-0">
        {(["log", "settings"] as Tab[]).map((tab) => {
          const isActive = activeTab === tab;
          return (
            <button
              key={tab}
              type="button"
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold tracking-wide transition-colors duration-150 cursor-pointer flex items-center justify-center gap-1.5 ${
                isActive
                  ? "bg-neutral-600/20 text-neutral-300 border border-neutral-500/40 shadow-sm"
                  : "text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900"
              }`}
            >
              <Icon name={tab === "log" ? "chart" : "gear"} className="popup-icon" />
              <span>{tab === "log" ? "ACTIVITY" : "SETTINGS"}</span>
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      <main className="flex-1 overflow-y-auto overflow-x-hidden min-h-0 bg-neutral-950/40">
        {activeTab === "log" ? <LogTab /> : <SettingsTab />}
      </main>

      {/* Footer */}
      <footer className="popup-footer">
        <span>
          Session data clears when browser closes
        </span>
        <span className="font-mono bg-neutral-900 border border-neutral-800 rounded px-1.5 py-0.5 text-neutral-300">
          Alt+A on GitHub
        </span>
      </footer>
    </div>
  );
}
