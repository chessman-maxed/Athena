/**
 * Unit tests for src/rules/secrets.ts
 *
 * Run with:  npm test
 *
 * Keys in this file are deliberately malformed/fake so secret-scanning
 * tools don't alert on the test suite itself.  Formats follow the real
 * structure closely enough to validate the detectors.
 */

import { describe, it, expect } from "vitest";
import { scanText, shannonEntropy } from "./secrets";

// ── Shannon entropy ───────────────────────────────────────────────────────────

describe("shannonEntropy", () => {
  it("returns 0 for empty string", () => {
    expect(shannonEntropy("")).toBe(0);
  });

  it("returns 0 for a single repeated character", () => {
    expect(shannonEntropy("aaaaaaaaaa")).toBe(0);
  });

  it("returns ~1 for two equally likely characters", () => {
    const h = shannonEntropy("ababababab");
    expect(h).toBeCloseTo(1, 1);
  });

  it("gives high entropy for a random-looking token", () => {
    const h = shannonEntropy("aB3xQ9zR7kP2mN5vW8yT");
    expect(h).toBeGreaterThan(4.0);
  });

  it("gives low entropy for a natural word", () => {
    const h = shannonEntropy("password");
    expect(h).toBeLessThan(3.5);
  });
});

// ── AWS Access Key ID ─────────────────────────────────────────────────────────

describe("AWS Access Key ID", () => {
  it("detects a well-formed key", () => {
    const findings = scanText("key = AKIAIOSFODNN7EXAMPLE");
    expect(findings.some((f) => f.type === "AWS Access Key ID")).toBe(true);
  });

  it("finds multiple keys in one blob", () => {
    const text = "key1=AKIAIOSFODNN7EXAMPLE\nkey2=AKIAJSIE73UJSODFGXYZ";
    const aws = scanText(text).filter((f) => f.type === "AWS Access Key ID");
    expect(aws.length).toBe(2);
  });

  it("ignores AKIA with wrong length", () => {
    const findings = scanText("AKIA1234TOOSHORT");
    expect(findings.some((f) => f.type === "AWS Access Key ID")).toBe(false);
  });

  it("records the correct index", () => {
    const text = "prefix AKIAIOSFODNN7EXAMPLE suffix";
    const [finding] = scanText(text).filter((f) => f.type === "AWS Access Key ID");
    expect(finding.index).toBe(7); // "prefix " is 7 chars
  });

  it("never exposes more than 6 chars in matchPreview", () => {
    const [finding] = scanText("AKIAIOSFODNN7EXAMPLE");
    expect(finding.matchPreview.replace(/•/g, "").length).toBeLessThanOrEqual(6);
  });
});

// ── GitHub PATs ───────────────────────────────────────────────────────────────

describe("GitHub Personal Access Token", () => {
  // Classic ghp_ token (36 alphanum chars after prefix)
  const classicPAT = "ghp_abcdefghijklmnopqrstuvwxyz0123456789AB";

  it("detects a classic ghp_ PAT", () => {
    const findings = scanText(`token=${classicPAT}`);
    expect(findings.some((f) => f.type === "GitHub Personal Access Token")).toBe(true);
  });

  it("detects a gho_ OAuth token", () => {
    const findings = scanText("gho_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghij");
    expect(findings.some((f) => f.type === "GitHub Personal Access Token")).toBe(true);
  });

  it("detects a ghs_ server-to-server token", () => {
    const findings = scanText("ghs_1234567890abcdefghijklmnopqrstuvwxyzAB");
    expect(findings.some((f) => f.type === "GitHub Personal Access Token")).toBe(true);
  });

  it("does not match ghp_ with too-short suffix", () => {
    const findings = scanText("ghp_short");
    expect(findings.some((f) => f.type === "GitHub Personal Access Token")).toBe(false);
  });
});

describe("GitHub Fine-Grained PAT", () => {
  const finePAT = "github_pat_11ABCDEF00000_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";

  it("detects a github_pat_ token", () => {
    const findings = scanText(finePAT);
    expect(findings.some((f) => f.type === "GitHub Fine-Grained PAT")).toBe(true);
  });
});

// ── PEM Private Key ───────────────────────────────────────────────────────────

describe("PEM Private Key", () => {
  it("detects a bare RSA PRIVATE KEY header", () => {
    const findings = scanText("-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEA...");
    expect(findings.some((f) => f.type === "PEM Private Key")).toBe(true);
  });

  it("detects an EC PRIVATE KEY header", () => {
    const findings = scanText("-----BEGIN EC PRIVATE KEY-----\nMHQCAQEEIA...");
    expect(findings.some((f) => f.type === "PEM Private Key")).toBe(true);
  });

  it("detects an OPENSSH PRIVATE KEY header", () => {
    const findings = scanText("-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXk...");
    expect(findings.some((f) => f.type === "PEM Private Key")).toBe(true);
  });

  it("detects a plain PRIVATE KEY header (PKCS8)", () => {
    const findings = scanText("-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgk...");
    expect(findings.some((f) => f.type === "PEM Private Key")).toBe(true);
  });
});

// ── Slack tokens ──────────────────────────────────────────────────────────────

describe("Slack Token", () => {
  it("detects an xoxb- bot token", () => {
    const findings = scanText("SLACK_TOKEN=xoxb-1234567890-9876543210-abcdefghijklmnopqr");
    expect(findings.some((f) => f.type === "Slack Token")).toBe(true);
  });

  it("detects an xoxp- user token", () => {
    const findings = scanText("xoxp-1234567890-1234567890-1234567890-abcdef1234567890ab");
    expect(findings.some((f) => f.type === "Slack Token")).toBe(true);
  });

  it("does not flag xoxb- with too short body", () => {
    const findings = scanText("xoxb-short");
    expect(findings.some((f) => f.type === "Slack Token")).toBe(false);
  });
});

// ── Google API Key ────────────────────────────────────────────────────────────

describe("Google API Key", () => {
  it("detects AIza… key", () => {
    const findings = scanText("GOOGLE_KEY=AIzaSyDKV4z7vJ6VZGiPKA3q2c4lX5oIpPLawXX");
    expect(findings.some((f) => f.type === "Google API Key")).toBe(true);
  });

  it("does not match AIza with wrong length", () => {
    const findings = scanText("AIzaShort");
    expect(findings.some((f) => f.type === "Google API Key")).toBe(false);
  });
});

// ── OpenAI keys ───────────────────────────────────────────────────────────────

describe("OpenAI API Key", () => {
  it("detects a new sk-proj- key", () => {
    const findings = scanText(
      "OPENAI_KEY=sk-proj-aBcDeFgHiJkLmNoPqRsTuVwXyZ01234567890abcdefghij"
    );
    expect(findings.some((f) => f.type === "OpenAI API Key")).toBe(true);
  });
});

// ── Stripe keys ───────────────────────────────────────────────────────────────

describe("Stripe Secret Key", () => {
  it("detects sk_live_ key", () => {
    const findings = scanText("STRIPE_KEY=sk_live_ABCDEFGHIJKLMNOPQRSTUVWXabcd");
    expect(findings.some((f) => f.type === "Stripe Secret Key")).toBe(true);
  });

  it("detects sk_test_ key (dev credential still sensitive)", () => {
    const findings = scanText("sk_test_ABCDEFGHIJKLMNOPQRSTUVWXabcd");
    expect(findings.some((f) => f.type === "Stripe Secret Key")).toBe(true);
  });
});

// ── High-entropy strings ──────────────────────────────────────────────────────

describe("High-Entropy String", () => {
  it("flags a random-looking base64 token", () => {
    // 32-char random token that doesn't match named detectors
    const findings = scanText("token=X7kQ9mR3pN8vZ2wY6bT4cL1jA5sG0hE");
    expect(findings.some((f) => f.type === "High-Entropy String")).toBe(true);
  });

  it("does NOT flag a short word (low entropy, short)", () => {
    const findings = scanText("hello world");
    expect(findings.some((f) => f.type === "High-Entropy String")).toBe(false);
  });

  it("does NOT flag a SHA-256 hex hash", () => {
    const sha256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
    const findings = scanText(sha256);
    expect(findings.some((f) => f.type === "High-Entropy String")).toBe(false);
  });

  it("does NOT flag a SHA-1 git commit hash", () => {
    const sha1 = "da39a3ee5e6b4b0d3255bfef95601890afd80709";
    const findings = scanText(sha1);
    expect(findings.some((f) => f.type === "High-Entropy String")).toBe(false);
  });

  it("does NOT flag a UUID", () => {
    const findings = scanText("id=550e8400-e29b-41d4-a716-446655440000");
    expect(findings.some((f) => f.type === "High-Entropy String")).toBe(false);
  });

  it("does NOT flag a repeated character pattern (low entropy)", () => {
    const findings = scanText("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
    expect(findings.some((f) => f.type === "High-Entropy String")).toBe(false);
  });
});

// ── Edge cases ────────────────────────────────────────────────────────────────

describe("Edge cases", () => {
  it("returns empty array for empty string", () => {
    expect(scanText("")).toHaveLength(0);
  });

  it("returns empty array for whitespace-only input", () => {
    expect(scanText("   \n\t  ")).toHaveLength(0);
  });

  it("returns empty array for normal prose", () => {
    const prose =
      "I fixed the bug by updating the dependency. See line 42 for the change.";
    expect(scanText(prose)).toHaveLength(0);
  });

  it("detects multiple distinct secret types in one blob", () => {
    const text = [
      "aws_key=AKIAIOSFODNN7EXAMPLE",
      "gh_token=ghp_abcdefghijklmnopqrstuvwxyz0123456789AB",
      "google=AIzaSyDKV4z7vJ6VZGiPKA3q2c4lX5oIpPLawXX",
    ].join("\n");
    const types = scanText(text).map((f) => f.type);
    expect(types).toContain("AWS Access Key ID");
    expect(types).toContain("GitHub Personal Access Token");
    expect(types).toContain("Google API Key");
  });

  it("deduplicates by named detector not by entropy scanner", () => {
    // An AWS key would also be caught by entropy; only one finding for it
    const text = "AKIAIOSFODNN7EXAMPLE";
    const findings = scanText(text);
    const aws = findings.filter((f) => f.type === "AWS Access Key ID");
    expect(aws.length).toBe(1);
  });
});
