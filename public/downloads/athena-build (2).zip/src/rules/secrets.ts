/**
 * Athena – Secret detection engine.
 *
 * Pure function; zero side-effects, no DOM, no logging of secret values.
 *
 * Detection catalogue
 * ───────────────────
 *  1. AWS Access Key ID             (AKIA…20-char)
 *  2. GitHub PATs                   (ghp_, github_pat_, gho_, ghu_, ghs_, ghr_)
 *  3. PEM private-key blocks        (-----BEGIN … PRIVATE KEY-----)
 *  4. Slack tokens                  (xoxb- / xoxp- / xoxs- etc.)
 *  5. Google API keys               (AIza…39-char)
 *  6. OpenAI keys                   (sk-… / sk-proj-…)
 *  7. Stripe secret keys            (sk_live_…)
 *  8. Generic high-entropy strings  (Shannon ≥ 4.5, length ≥ 20, not a hash / URL)
 *
 * The `matchPreview` in each Finding is intentionally truncated:
 *   first 6 chars + "••••••" so the caller can display WHERE without
 *   storing the full credential.
 */

// ── Types ─────────────────────────────────────────────────────────────────────

export interface Finding {
  /** Human-readable detector name (e.g. "AWS Access Key ID"). */
  type: string;
  /** Truncated preview safe to show in UI — never the full secret. */
  matchPreview: string;
  /** Character offset in the input string where the match starts. */
  index: number;
  /** Match length is safe metadata and lets callers locate the text without storing it. */
  length: number;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Build a safe preview: keep first 6 chars, mask the rest. */
function preview(raw: string): string {
  const keep = Math.min(6, raw.length);
  return raw.slice(0, keep) + "••••••";
}

/**
 * Shannon entropy of a string (bits per character).
 * Returns 0 for empty strings.
 */
export function shannonEntropy(s: string): number {
  if (s.length === 0) return 0;
  const freq = new Map<string, number>();
  for (const ch of s) freq.set(ch, (freq.get(ch) ?? 0) + 1);
  let h = 0;
  for (const count of freq.values()) {
    const p = count / s.length;
    h -= p * Math.log2(p);
  }
  return h;
}

/** True if the string looks like a hex hash (MD5/SHA-1/SHA-256/SHA-512). */
function isHexHash(s: string): boolean {
  return /^[0-9a-fA-F]+$/.test(s) &&
    [32, 40, 56, 64, 96, 128].includes(s.length);
}

/** True if the token appears to be a URL or is inside a URL path. */
function looksLikeUrl(token: string, surroundingText: string, tokenIndex: number): boolean {
  if (/^https?:\/\//i.test(token)) return true;
  // Check if it immediately follows :// or /
  const before = surroundingText.slice(Math.max(0, tokenIndex - 10), tokenIndex);
  return /[/:]{1,3}$/.test(before);
}

/** True if the token looks like a UUID (8-4-4-4-12 hex). */
function isUUID(s: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);
}

// ── Named detector patterns ───────────────────────────────────────────────────

interface Detector {
  type: string;
  // RegExp must use the `g` flag so we can find ALL occurrences.
  pattern: RegExp;
}

const DETECTORS: Detector[] = [
  {
    type: "AWS Access Key ID",
    // 20-char: AKIA + 16 uppercase alphanumeric
    pattern: /\bAKIA[0-9A-Z]{16}\b/g,
  },
  {
    type: "GitHub Personal Access Token",
    // ghp_ (classic), gho_ (OAuth), ghu_ (user-to-server), ghs_ (server-to-server), ghr_ (refresh)
    // Suffix is 36+ alphanumeric chars
    pattern: /\bgh[pousr]_[A-Za-z0-9]{36,}\b|\bghs_[A-Za-z0-9]{36,}\b/g,
  },
  {
    type: "GitHub Fine-Grained PAT",
    // github_pat_ prefix followed by a long token
    pattern: /\bgithub_pat_[A-Za-z0-9_]{20,}\b/g,
  },
  {
    type: "PEM Private Key",
    // Matches the PEM header line; captures just the BEGIN header
    pattern: /-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY-----/g,
  },
  {
    type: "Slack Token",
    // xoxb- (bot), xoxp- (user/legacy), xoxa- (app), xoxr- (refresh), xoxs- (service)
    pattern: /\bxox[baprs]-[0-9A-Za-z]{10,}(?:-[0-9A-Za-z]+)*\b/g,
  },
  {
    type: "Google API Key",
    // AIza + 35 chars of url-safe base64
    pattern: /\bAIza[0-9A-Za-z_-]{35}\b/g,
  },
  {
    type: "OpenAI API Key",
    // Legacy sk-…T3BlbkFJ… and new sk-proj-… formats
    pattern: /\bsk-[A-Za-z0-9]{20,}T3BlbkFJ[A-Za-z0-9]{20,}\b|\bsk-proj-[A-Za-z0-9_-]{40,}\b/g,
  },
  {
    type: "Stripe Secret Key",
    // Live and test secret keys (sk_live_ is critical; sk_test_ also flagged)
    pattern: /\bsk_(?:live|test)_[0-9A-Za-z]{24,}\b/g,
  },
  {
    type: "Stripe Publishable Key",
    pattern: /\bpk_(?:live|test)_[0-9A-Za-z]{24,}\b/g,
  },
];

// ── Generic high-entropy scanner ──────────────────────────────────────────────

const ENTROPY_THRESHOLD = 4.5;
const MIN_ENTROPY_LEN = 20;

// Characters that commonly make up credential tokens
const ENTROPY_TOKEN_RE = /[A-Za-z0-9+/=_\-]{20,}/g;

function findHighEntropyTokens(text: string, alreadyFoundAt: Set<number>): Finding[] {
  const results: Finding[] = [];
  ENTROPY_TOKEN_RE.lastIndex = 0;
  let m: RegExpExecArray | null;

  while ((m = ENTROPY_TOKEN_RE.exec(text)) !== null) {
    const token = m[0];
    const idx = m.index;

    // Skip positions already covered by a named detector
    if (alreadyFoundAt.has(idx)) continue;

    // Length guard
    if (token.length < MIN_ENTROPY_LEN) continue;

    // Discard obvious hex hashes (SHA-1, SHA-256, MD5, …)
    if (isHexHash(token)) continue;

    // Discard UUIDs
    if (isUUID(token)) continue;

    // Discard URL components
    if (looksLikeUrl(token, text, idx)) continue;

    // Entropy gate
    const h = shannonEntropy(token);
    if (h < ENTROPY_THRESHOLD) continue;

    results.push({
      type: "High-Entropy String",
      matchPreview: preview(token),
      index: idx,
      length: token.length,
    });
  }

  return results;
}

// ── Public API ────────────────────────────────────────────────────────────────

/**
 * Scan `text` for secrets and return all findings.
 *
 * @param text  Raw text from a textarea / editor
 * @returns     Array of findings (may be empty). Never mutates input.
 */
export function scanText(text: string): Finding[] {
  if (!text || text.trim().length === 0) return [];

  const findings: Finding[] = [];
  const coveredIndexes = new Set<number>();

  for (const detector of DETECTORS) {
    // Reset lastIndex for each run (patterns use `g` flag)
    detector.pattern.lastIndex = 0;
    let match: RegExpExecArray | null;

    while ((match = detector.pattern.exec(text)) !== null) {
      findings.push({
        type: detector.type,
        matchPreview: preview(match[0]),
        index: match.index,
        length: match[0].length,
      });
      // Mark all character positions in this match as covered
      for (let i = match.index; i < match.index + match[0].length; i++) {
        coveredIndexes.add(i);
      }
    }
  }

  // Entropy scan (skips positions already matched by named detectors)
  const entropyFindings = findHighEntropyTokens(text, coveredIndexes);
  findings.push(...entropyFindings);

  // Sort by index ascending
  findings.sort((a, b) => a.index - b.index);

  return findings;
}
